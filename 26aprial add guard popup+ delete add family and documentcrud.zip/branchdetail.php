<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/Branch.php");
require_once("businessLogic/Company.php");

$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="branch";
session_start();

$database = new Database();
$db = $database->getConnection();
$company = new Company($db);
$branch = new Branch($db);

if(isset($_SESSION["username"]))
{
  // $member->getMemberDetails($_SESSION['memberId']);
  $username = $_SESSION['username'];
}
else {
  // $memberId="Not logged in";
  header("location: ".$project->getProjectUrl()."index");
  exit;
}
if(isset($_GET['id']))
{
  $branch->getBranchByID($_GET['id']);
}
else {
  header("location:". $project->getProjectUrl()."branch");
  exit;
}

?>

<!DOCTYPE html>
<html>
<head>
   <?php include_once("htmlheader.php"); ?>
   <title><?php echo $project->getProjectFName()?> | Branch Details</title>

</head>

 <body onload="myFunction()" style="">
     <div id="loader"></div>

       <?php include_once("sidebar.php"); ?>

       <?php include_once("header.php"); ?>

       <div class="page">

      <div style="display: block;" id="content" class="animate-bottom">

      <?php
      if(isset($successmessage))
      {
      ?>
      <div class="alert alert-success alert-dismissible text-center">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo $successmessage; ?>
      </div>
    <?php } ?>
    <?php
    if(isset($errormessage))
    {
    ?>
    <div class="alert alert-danger alert-dismissible text-center">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <?php echo $errormessage; ?>
    </div>
  <?php } ?>



<section class="forms">
  <div class="container-fluid">
      <div class="row">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-header d-flex align-items-center">
                      <h4>Branch Details</h4>
                  </div>
                  <div class="card-body">
                      <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                      <form method="POST" action="branch" accept-charset="UTF-8" class="payment-form" enctype="multipart/form-data"><input name="_token" type="hidden" value="fYe3holiUMMCtMHKBwiFIIgC8If0Icvqd75v8XuD">
                      <div class="row">
                          <div class="col-md-12">
                              <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong>Branch</strong>
                                        </label>
                                        <input type="text" value="<?php echo $branch->getBranchName(); ?>" name="branchname" id="branchname" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Company</label>
                                        <div class="btn-group bootstrap-select form-control">
										                        <select name="company_id" id="company_id" required="" class="selectpicker form-control" data-live-search="true" data-live-search-style="begins" title="Select Role...">
										                                    <option class="bs-title-option" value="">Select Role...</option>
                                                        <?php
                                                        $companies  =$company->readAllCompany();
                                                        foreach ($companies as $rolevalue) {
                                                          if($branch->getCompanyId()==$rolevalue['fd_company_id'])
                                                          {
                                                            echo "<option selected value=\"".$rolevalue['fd_company_id']."\">".$rolevalue['fd_company_name']."</option>";
                                                          }
                                                          else {
                                                            echo "<option value=\"".$rolevalue['fd_company_id']."\">".$rolevalue['fd_company_name']."</option>";
                                                          }
                                                        }
                                                        ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input type="text" value="<?php echo $branch->getAddress(); ?>" name="address" id="address" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Address1</label>
                                        <input type="text" value="<?php echo $branch->getAddress1(); ?>" name="address1" id="address1" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Address2</label>
                                        <input type="text" value="<?php echo $branch->getAddress2(); ?>" name="address2" id="address2" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>City</label>
                                        <input type="text" value="<?php echo $branch->getCity(); ?>" name="city" id="city" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>State</label>
                                        <input type="text" value="<?php echo $branch->getState(); ?>" name="state" id="state" class="form-control" step="any">
                                      </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Country</label>
                                        <input type="text" value="<?php echo $branch->getCountry(); ?>" name="country" id="country" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Pincode</label>
                                        <input type="text" value="<?php echo $branch->getPincode(); ?>" name="pincode" id="pincode" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Stdcode</label>
                                        <input type="text" value="<?php echo $branch->getStdcode(); ?>" name="stdcode" id="stdcode" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Phone1</label>
                                        <input type="text" value="<?php echo $branch->getPhone1(); ?>" name="phone1" id="phone1" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Phone2</label>
                                        <input type="text" value="<?php echo $branch->getPhone2(); ?>" name="phone2" id="phone2" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Fax</label>
                                        <input type="text" value="<?php echo $branch->getFax(); ?>" name="fax" id="fax" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Contact Person Name</label>
                                        <input type="text" value="<?php echo $branch->getCPName(); ?>" name="cpname" id="cpname" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Mobile1</label>
                                        <input type="text" value="<?php echo $branch->getMobile1(); ?>" name="mobile1" id="mobile1" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Mobile2</label>
                                        <input type="text" value="<?php echo $branch->getMobile2(); ?>" name="mobile2" id="mobile2" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Email1</label>
                                        <input type="text" value="<?php echo $branch->getEmail1(); ?>" name="email1" id="email1" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Email2</label>
                                        <input type="text" value="<?php echo $branch->getEmail2(); ?>" name="email2" id="email2" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Url</label>
                                        <input type="text" value="<?php echo $branch->getUrl(); ?>" name="url" id="url" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>PAN No</label>
                                        <input type="text" value="<?php echo $branch->getPanNO(); ?>" name="panno" id="panno" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>STax No</label>
                                        <input type="text" value="<?php echo $branch->getSTaxNO(); ?>" name="staxno" id="staxno" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>PF Code</label>
                                        <input type="text" value="<?php echo $branch->getPFCode(); ?>" name="pfcode" id="pfcode" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>ESI Code</label>
                                        <input type="text" value="<?php echo $branch->getESICode(); ?>" name="esicode" id="esicode" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                                <input type="submit" value="Update Branch" class="btn btn-primary" id="submit-button">
                                <input type="hidden" name="editValue" value="success">
                                <input type="hidden" name="branch_id" value="<?php echo $_GET['id'] ?>">
                                <a href="branch" class="btn btn-warning">Cancel</a>
                            </div>
                          </div>
                      </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>

</section>

    </div>

      <?php include_once("footer.php"); ?>
    </div>


<script type="text/javascript">
       if ($(window).outerWidth() > 1199) {
           $('nav.side-navbar').removeClass('shrink');
       }

       function myFunction() {
           setTimeout(showPage, 150);
       }
       function showPage() {
         document.getElementById("loader").style.display = "none";
         document.getElementById("content").style.display = "block";
       }

       $("div.alert").delay(3000).slideUp(750);

       function confirmDelete() {
           if (confirm("Are you sure want to delete?")) {
               return true;
           }
           return false;
       }

       $("a#add-expense").click(function(e){
         e.preventDefault();
         $('#expense-modal').modal();
       });

       $("a#add-account").click(function(e){
         e.preventDefault();
         $('#account-modal').modal();
       });

       $("a#account-statement").click(function(e){
         e.preventDefault();
         $('#account-statement-modal').modal();
       });

       $("a#profitLoss-link").click(function(e){
         e.preventDefault();
         $("#profitLoss-report-form").submit();
       });

       $("a#report-link").click(function(e){
         e.preventDefault();
         $("#product-report-form").submit();
       });

       $("a#purchase-report-link").click(function(e){
         e.preventDefault();
         $("#purchase-report-form").submit();
       });

       $("a#sale-report-link").click(function(e){
         e.preventDefault();
         $("#sale-report-form").submit();
       });

       $("a#payment-report-link").click(function(e){
         e.preventDefault();
         $("#payment-report-form").submit();
       });

       $("a#warehouse-report-link").click(function(e){
         e.preventDefault();
         $('#warehouse-modal').modal();
       });

       $("a#user-report-link").click(function(e){
         e.preventDefault();
         $('#user-modal').modal();
       });

       $("a#customer-report-link").click(function(e){
         e.preventDefault();
         $('#customer-modal').modal();
       });

       $("a#supplier-report-link").click(function(e){
         e.preventDefault();
         $('#supplier-modal').modal();
       });

       $("a#due-report-link").click(function(e){
         e.preventDefault();
         $("#due-report-form").submit();
       });

       $(".daterangepicker-field").daterangepicker({
           callback: function(startDate, endDate, period){
             var start_date = startDate.format('YYYY-MM-DD');
             var end_date = endDate.format('YYYY-MM-DD');
             var title = start_date + ' To ' + end_date;
             $(this).val(title);
             $('#account-statement-modal input[name="start_date"]').val(start_date);
             $('#account-statement-modal input[name="end_date"]').val(end_date);
           }
       });

       $('.selectpicker').selectpicker({
           style: 'btn-link',
       });
     </script>

     <script type="text/javascript">

     $("#card-element").hide();
     $("#cheque").hide();

     // array data depend on warehouse
     var lims_product_array = [];
     var product_code = [];
     var product_name = [];
     var product_qty = [];
     var product_type = [];
     var product_id = [];
     var product_list = [];
     var qty_list = [];

     // array data with selection
     var product_price = [];
     var product_discount = [];
     var tax_rate = [];
     var tax_name = [];
     var tax_method = [];
     var unit_name = [];
     var unit_operator = [];
     var unit_operation_value = [];

     // temporary array
     var temp_unit_name = [];
     var temp_unit_operator = [];
     var temp_unit_operation_value = [];

     var exist_type = [];
     var exist_code = [];
     var exist_qty = [];
     var rowindex;
     var customer_group_rate;
     var row_product_price;
     var currency = {"id":1,"name":"US Dollar","code":"USD","exchange_rate":1,"created_at":"2020-10-31 19:22:58","updated_at":"2020-10-31 19:34:55"};
     var role_id = 1;

     var rownumber = $('table.order-list tbody tr:last').index();

     for(rowindex  =0; rowindex <= rownumber; rowindex++){
         product_price.push(parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.product-price').val()));
         exist_code.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(2)').text());
         exist_type.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.product-type').val());
         var total_discount = parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(5)').text());
         var quantity = parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val());
         exist_qty.push(quantity);
         product_discount.push((total_discount / quantity).toFixed(2));
         tax_rate.push(parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-rate').val()));
         tax_name.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-name').val());
         tax_method.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-method').val());
         temp_unit_name = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit').val().split(',');
         unit_name.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit').val());
         unit_operator.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit-operator').val());
         unit_operation_value.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit-operation-value').val());
         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit').val(temp_unit_name[0]);
     }

     $('.selectpicker').selectpicker({
         style: 'btn-link',
     });

     $('[data-toggle="tooltip"]').tooltip();

     //assigning value
     $('select[name="customer_id"]').val($('input[name="customer_id_hidden"]').val());
     $('select[name="warehouse_id"]').val($('input[name="warehouse_id_hidden"]').val());
     $('select[name="biller_id"]').val($('input[name="biller_id_hidden"]').val());
     $('select[name="sale_status"]').val($('input[name="sale_status_hidden"]').val());
     $('select[name="order_tax_rate"]').val($('input[name="order_tax_rate_hidden"]').val());
     $('.selectpicker').selectpicker('refresh');

     $('#item').text($('input[name="item"]').val() + '(' + $('input[name="total_qty"]').val() + ')');
     $('#subtotal').text(parseFloat($('input[name="total_price"]').val()).toFixed(2));
     $('#order_tax').text(parseFloat($('input[name="order_tax"]').val()).toFixed(2));
     if(!$('input[name="order_discount"]').val())
         $('input[name="order_discount"]').val('0.00');
     $('#order_discount').text(parseFloat($('input[name="order_discount"]').val()).toFixed(2));
     if(!$('input[name="shipping_cost"]').val())
         $('input[name="shipping_cost"]').val('0.00');
     $('#shipping_cost').text(parseFloat($('input[name="shipping_cost"]').val()).toFixed(2));
     $('#grand_total').text(parseFloat($('input[name="grand_total"]').val()).toFixed(2));

     var id = $('select[name="customer_id"]').val();
     $.get('../getcustomergroup/' + id, function(data) {
         customer_group_rate = (data / 100);
     });

     var id = $('select[name="warehouse_id"]').val();
     $.get('../getproduct/' + id, function(data) {
         lims_product_array = [];
         product_code = data[0];
         product_name = data[1];
         product_qty = data[2];
         product_type = data[3];
         product_id = data[4];
         product_list = data[5];
         qty_list = data[6];
         product_warehouse_price = data[7];

         $.each(product_code, function(index) {
             if(exist_code.includes(product_code[index])) {
                 pos = exist_code.indexOf(product_code[index]);
                 product_qty[index] = product_qty[index] + exist_qty[pos];
                 exist_code.splice(pos, 1);
                 exist_qty.splice(pos, 1);
             }
             lims_product_array.push(product_code[index] + ' (' + product_name[index] + ')');
         });
         $.each(exist_code, function(index) {
             product_type.push(exist_type[index]);
             product_code.push(exist_code[index]);
             product_qty.push(exist_qty[index]);
         });
     });

     isCashRegisterAvailable(id);

     $('select[name="customer_id"]').on('change', function() {
         var id = $(this).val();
         $.get('../getcustomergroup/' + id, function(data) {
             customer_group_rate = (data / 100);
         });
     });

     $('select[name="warehouse_id"]').on('change', function() {
         var id = $(this).val();
         $.get('../getproduct/' + id, function(data) {
             lims_product_array = [];
             product_code = data[0];
             product_name = data[1];
             product_qty = data[2];
             product_type = data[3];
             product_id = data[4];
             product_list = data[5];
             qty_list = data[6];
             product_warehouse_price = data[7];
             $.each(product_code, function(index) {
                 lims_product_array.push(product_code[index] + ' (' + product_name[index] + ')');
             });
         });
         isCashRegisterAvailable(id);
     });

     var lims_productcodeSearch = $('#lims_productcodeSearch');
     lims_productcodeSearch.autocomplete({
         source: function(request, response) {
             var matcher = new RegExp(".?" + $.ui.autocomplete.escapeRegex(request.term), "i");
             response($.grep(lims_product_array, function(item) {
                 return matcher.test(item);
             }));
         },
         response: function(event, ui) {
             if (ui.content.length == 1) {
                 var data = ui.content[0].value;
                 $(this).autocomplete( "close" );
                 productSearch(data);
             };
         },
         select: function(event, ui) {
             var data = ui.item.value;
             productSearch(data);
         }
     });

     //Change quantity
     $("#myTable").on('input', '.qty', function() {
         rowindex = $(this).closest('tr').index();
         if($(this).val() < 1 && $(this).val() != '') {
           $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ') .qty').val(1);
           alert("Quantity can't be less than 1");
         }
         checkQuantity($(this).val(), true);
     });


     //Delete product
     $("table.order-list tbody").on("click", ".ibtnDel", function(event) {
       alert("testing");
         rowindex = $(this).closest('tr').index();
         product_price.splice(rowindex, 1);
         product_discount.splice(rowindex, 1);
         tax_rate.splice(rowindex, 1);
         tax_name.splice(rowindex, 1);
         tax_method.splice(rowindex, 1);
         unit_name.splice(rowindex, 1);
         unit_operator.splice(rowindex, 1);
         unit_operation_value.splice(rowindex, 1);
         $(this).closest("tr").remove();
         // calculateTotal();
     });

     //Edit product
     $("table.order-list").on("click", ".edit-product", function() {
         rowindex = $(this).closest('tr').index();
         edit();
     });

     //Update product
     $('button[name="update_btn"]').on("click", function() {
         var edit_discount = $('input[name="edit_discount"]').val();
         var edit_qty = $('input[name="edit_qty"]').val();
         var edit_unit_price = $('input[name="edit_unit_price"]').val();

         if (parseFloat(edit_discount) > parseFloat(edit_unit_price)) {
             alert('Invalid Discount Input!');
             return;
         }

         if(edit_qty < 1) {
             $('input[name="edit_qty"]').val(1);
             edit_qty = 1;
             alert("Quantity can't be less than 1");
         }

         var tax_rate_all = [0,10,15,20];
         tax_rate[rowindex] = parseFloat(tax_rate_all[$('select[name="edit_tax_rate"]').val()]);
         tax_name[rowindex] = $('select[name="edit_tax_rate"] option:selected').text();
         if(product_type[pos] == 'standard'){
             var row_unit_operator = unit_operator[rowindex].slice(0, unit_operator[rowindex].indexOf(","));
             var row_unit_operation_value = unit_operation_value[rowindex].slice(0, unit_operation_value[rowindex].indexOf(","));
             if (row_unit_operator == '*') {
                 product_price[rowindex] = $('input[name="edit_unit_price"]').val() / row_unit_operation_value;
             } else {
                 product_price[rowindex] = $('input[name="edit_unit_price"]').val() * row_unit_operation_value;
             }
             var position = $('select[name="edit_unit"]').val();
             var temp_operator = temp_unit_operator[position];
             var temp_operation_value = temp_unit_operation_value[position];
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit').val(temp_unit_name[position]);
             temp_unit_name.splice(position, 1);
             temp_unit_operator.splice(position, 1);
             temp_unit_operation_value.splice(position, 1);

             temp_unit_name.unshift($('select[name="edit_unit"] option:selected').text());
             temp_unit_operator.unshift(temp_operator);
             temp_unit_operation_value.unshift(temp_operation_value);

             unit_name[rowindex] = temp_unit_name.toString() + ',';
             unit_operator[rowindex] = temp_unit_operator.toString() + ',';
             unit_operation_value[rowindex] = temp_unit_operation_value.toString() + ',';
         }
         product_discount[rowindex] = $('input[name="edit_discount"]').val();
         checkQuantity(edit_qty, false);
     });

     function isCashRegisterAvailable(warehouse_id) {
         $.ajax({
             url: '../../cash-register/check-availability/'+warehouse_id,
             type: "GET",
             success:function(data) {
                 if(data == 'false') {
                     $('#cash-register-modal select[name=warehouse_id]').val(warehouse_id);
                     $('.selectpicker').selectpicker('refresh');
                     if(role_id <= 2){
                         $("#cash-register-modal .warehouse-section").removeClass('d-none');
                     }
                     else {
                         $("#cash-register-modal .warehouse-section").addClass('d-none');
                     }
                     $("#cash-register-modal").modal('show');
                 }
             }
         });
     }

     function productSearch(data){
         $.ajax({
             type: 'GET',
             url: '../lims_product_search',
             data: {
                 data: data
             },
             success: function(data) {
                 var flag = 1;
                 $(".product-code").each(function(i) {
                     if ($(this).val() == data[1]) {
                         rowindex = i;
                         var qty = parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ') .qty').val()) + 1;
                         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ') .qty').val(qty);
                         checkQuantity(String(qty), true);
                         flag = 0;
                     }
                 });
                 $("input[name='product_code_name']").val('');
                 if (flag) {
                     var newRow = $("<tr>");
                     var cols = '';
                     temp_unit_name = (data[6]).split(',');
                     cols += '<td>' + data[0] + '<button type="button" class="edit-product btn btn-link" data-toggle="modal" data-target="#editModal"> <i class="dripicons-document-edit"></i></button></td>';
                     cols += '<td>' + data[1] + '</td>';
                     cols += '<td><input type="number" class="form-control qty" name="qty[]" value="1" step="any" required/></td>';
                     cols += '<td class="net_unit_price"></td>';
                     cols += '<td class="discount">0.00</td>';
                     cols += '<td class="tax"></td>';
                     cols += '<td class="sub-total"></td>';
                     cols += '<td><button type="button" class="ibtnDel btn btn-md btn-danger">Delete</button></td>';
                     cols += '<input type="hidden" class="product-code" name="product_code[]" value="' + data[1] + '"/>';
                     cols += '<input type="hidden" name="product_id[]" value="' + data[9] + '"/>';
                     cols += '<input type="hidden" name="product_variant_id[]" value="' + data[10] + '"/>';
                     cols += '<input type="hidden" class="sale-unit" name="sale_unit[]" value="' + temp_unit_name[0] + '"/>';
                     cols += '<input type="hidden" class="net_unit_price" name="net_unit_price[]" />';
                     cols += '<input type="hidden" class="discount-value" name="discount[]" />';
                     cols += '<input type="hidden" class="tax-rate" name="tax_rate[]" value="' + data[3] + '"/>';
                     cols += '<input type="hidden" class="tax-value" name="tax[]" />';
                     cols += '<input type="hidden" class="subtotal-value" name="subtotal[]" />';

                     newRow.append(cols);
                     $("table.order-list tbody").prepend(newRow);
                     rowindex = newRow.index();
                     pos = product_code.indexOf(data[1]);
                     if(!data[11] && product_warehouse_price[pos]) {
                         product_price.splice(rowindex, 0, parseFloat(product_warehouse_price[pos] * currency['exchange_rate']) + parseFloat(product_warehouse_price[pos] * currency['exchange_rate'] * customer_group_rate));
                     }
                     else {
                         product_price.splice(rowindex, 0, parseFloat(data[2] * currency['exchange_rate']) + parseFloat(data[2] * currency['exchange_rate'] * customer_group_rate));
                     }

                     product_discount.splice(rowindex, 0, '0.00');
                     tax_rate.splice(rowindex, 0, parseFloat(data[3]));
                     tax_name.splice(rowindex, 0, data[4]);
                     tax_method.splice(rowindex, 0, data[5]);
                     unit_name.splice(rowindex, 0, data[6]);
                     unit_operator.splice(rowindex, 0, data[7]);
                     unit_operation_value.splice(rowindex, 0, data[8]);
                     checkQuantity(1, true);
                 }
             }
         });
     }

     function edit(){
         var row_product_name = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(1)').text();
         var row_product_code = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(2)').text();
         $('#modal_header').text(row_product_name + '(' + row_product_code + ')');

         var qty = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val();
         $('input[name="edit_qty"]').val(qty);

         $('input[name="edit_discount"]').val(parseFloat(product_discount[rowindex]).toFixed(2));

         var tax_name_all = ["No Tax","vat@10","vat@15","vat 20"];
         pos = tax_name_all.indexOf(tax_name[rowindex]);
         $('select[name="edit_tax_rate"]').val(pos);

         pos = product_code.indexOf(row_product_code);
         if(product_type[pos] == 'standard'){
             unitConversion();
             temp_unit_name = (unit_name[rowindex]).split(',');
             temp_unit_name.pop();
             temp_unit_operator = (unit_operator[rowindex]).split(',');
             temp_unit_operator.pop();
             temp_unit_operation_value = (unit_operation_value[rowindex]).split(',');
             temp_unit_operation_value.pop();
             $('select[name="edit_unit"]').empty();
             $.each(temp_unit_name, function(key, value) {
                 $('select[name="edit_unit"]').append('<option value="' + key + '">' + value + '</option>');
             });
             $("#edit_unit").show();
         }
         else{
             row_product_price = product_price[rowindex];
             $("#edit_unit").hide();
         }
         $('input[name="edit_unit_price"]').val(row_product_price.toFixed(2));
         $('.selectpicker').selectpicker('refresh');
     }

     function checkQuantity(sale_qty, flag) {
         var row_product_code = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(2)').text();
         pos = product_code.indexOf(row_product_code);
         if(product_type[pos] == 'standard'){
             var operator = unit_operator[rowindex].split(',');
             var operation_value = unit_operation_value[rowindex].split(',');
             if(operator[0] == '*')
                 total_qty = sale_qty * operation_value[0];
             else if(operator[0] == '/')
                 total_qty = sale_qty / operation_value[0];
             if (total_qty > parseFloat(product_qty[pos])) {
                 alert('Quantity exceeds stock quantity!');
                 if (flag) {
                     sale_qty = sale_qty.substring(0, sale_qty.length - 1);
                     $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val(sale_qty);
                 }
                 else {
                     edit();
                     return;
                 }
             }
         }
         else if(product_type[pos] == 'combo'){
             child_id = product_list[pos].split(',');
             child_qty = qty_list[pos].split(',');
             $(child_id).each(function(index) {
                 var position = product_id.indexOf(parseInt(child_id[index]));
                 if( parseFloat(sale_qty * child_qty[index]) > product_qty[position] ) {
                     alert('Quantity exceeds stock quantity!');
                     if (flag) {
                         sale_qty = sale_qty.substring(0, sale_qty.length - 1);
                         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val(sale_qty);
                     }
                     else {
                         edit();
                         flag = true;
                         return false;
                     }
                 }
             });
         }

         if(!flag){
             $('#editModal').modal('hide');
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val(sale_qty);
         }

         calculateRowProductData(sale_qty);
     }

     function calculateRowProductData(quantity) {
         if(product_type[pos] == 'standard')
             unitConversion();
         else
             row_product_price = product_price[rowindex];

         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(5)').text((product_discount[rowindex] * quantity).toFixed(2));
         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.discount-value').val((product_discount[rowindex] * quantity).toFixed(2));
         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-rate').val(tax_rate[rowindex].toFixed(2));

         if (tax_method[rowindex] == 1) {
             var net_unit_price = row_product_price - product_discount[rowindex];
             var tax = net_unit_price * quantity * (tax_rate[rowindex] / 100);
             var sub_total = (net_unit_price * quantity) + tax;

             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(4)').text(net_unit_price.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.net_unit_price').val(net_unit_price.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(6)').text(tax.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-value').val(tax.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(7)').text(sub_total.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.subtotal-value').val(sub_total.toFixed(2));
         } else {
             var sub_total_unit = row_product_price - product_discount[rowindex];
             var net_unit_price = (100 / (100 + tax_rate[rowindex])) * sub_total_unit;
             var tax = (sub_total_unit - net_unit_price) * quantity;
             var sub_total = sub_total_unit * quantity;

             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(4)').text(net_unit_price.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.net_unit_price').val(net_unit_price.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(6)').text(tax.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-value').val(tax.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(7)').text(sub_total.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.subtotal-value').val(sub_total.toFixed(2));
         }

         calculateTotal();
     }

     function unitConversion() {
         var row_unit_operator = unit_operator[rowindex].slice(0, unit_operator[rowindex].indexOf(","));
         var row_unit_operation_value = unit_operation_value[rowindex].slice(0, unit_operation_value[rowindex].indexOf(","));

         if (row_unit_operator == '*') {
             row_product_price = product_price[rowindex] * row_unit_operation_value;
         } else {
             row_product_price = product_price[rowindex] / row_unit_operation_value;
         }
     }

     function calculateTotal() {
         //Sum of quantity
         var total_qty = 0;
         $(".qty").each(function() {

             if ($(this).val() == '') {
                 total_qty += 0;
             } else {
                 total_qty += parseFloat($(this).val());
             }
         });
         $("#total-qty").text(total_qty);
         $('input[name="total_qty"]').val(total_qty);

         //Sum of discount
         var total_discount = 0;
         $(".discount").each(function() {
             total_discount += parseFloat($(this).text());
         });
         $("#total-discount").text(total_discount.toFixed(2));
         $('input[name="total_discount"]').val(total_discount.toFixed(2));

         //Sum of tax
         var total_tax = 0;
         $(".tax").each(function() {
             total_tax += parseFloat($(this).text());
         });
         $("#total-tax").text(total_tax.toFixed(2));
         $('input[name="total_tax"]').val(total_tax.toFixed(2));

         //Sum of subtotal
         var total = 0;
         $(".sub-total").each(function() {
             total += parseFloat($(this).text());
         });
         $("#total").text(total.toFixed(2));
         $('input[name="total_price"]').val(total.toFixed(2));

         calculateGrandTotal();
     }

     function calculateGrandTotal() {

         var item = $('table.order-list tbody tr:last').index();

         var total_qty = parseFloat($('#total-qty').text());
         var subtotal = parseFloat($('#total').text());
         var order_tax = parseFloat($('select[name="order_tax_rate"]').val());
         var order_discount = parseFloat($('input[name="order_discount"]').val());
         var shipping_cost = parseFloat($('input[name="shipping_cost"]').val());

         if (!order_discount)
             order_discount = 0.00;
         if (!shipping_cost)
             shipping_cost = 0.00;

         item = ++item + '(' + total_qty + ')';
         order_tax = (subtotal - order_discount) * (order_tax / 100);
         var grand_total = (subtotal + order_tax + shipping_cost) - order_discount;
         $('input[name="grand_total"]').val(grand_total.toFixed(2));
         if($('input[name="coupon_active"]').val()) {
             couponDiscount();
             var coupon_discount = parseFloat($('input[name="coupon_discount"]').val());
             if (!coupon_discount)
                 coupon_discount = 0.00;
             grand_total -= coupon_discount;
         }

         $('#item').text(item);
         $('input[name="item"]').val($('table.order-list tbody tr:last').index() + 1);
         $('#subtotal').text(subtotal.toFixed(2));
         $('#order_tax').text(order_tax.toFixed(2));
         $('input[name="order_tax"]').val(order_tax.toFixed(2));
         $('#order_discount').text(order_discount.toFixed(2));
         $('#shipping_cost').text(shipping_cost.toFixed(2));
         $('#grand_total').text(grand_total.toFixed(2));
         $('input[name="grand_total"]').val(grand_total.toFixed(2));
     }

     function couponDiscount() {
         var rownumber = $('table.order-list tbody tr:last').index();
         if (rownumber < 0) {
             alert("Please insert product to order table!")
         }
         else{
             if($('input[name="coupon_type"]').val() == 'fixed'){
                 if( $('input[name="grand_total"]').val() >= $('input[name="coupon_minimum_amount"]').val() ) {
                     $('input[name="grand_total"]').val( $('input[name="grand_total"]').val() - $('input[name="coupon_amount"]').val() );
                 }
                 else
                     alert('Grand Total is not sufficient for discount! Required '+ currency['code'] + ' ' +$('input[name="coupon_minimum_amount"]').val());
             }
             else{
                 var grand_total = $('input[name="grand_total"]').val();
                 var coupon_discount = grand_total * (parseFloat($('input[name="coupon_amount"]').val()) / 100);
                 grand_total = grand_total - coupon_discount;
                 $('input[name="grand_total"]').val(grand_total);
                 $('input[name="coupon_discount"]').val(coupon_discount);
                 $('#coupon-text').text(parseFloat(coupon_discount).toFixed(2));
             }
         }
     }

     $('input[name="order_discount"]').on("input", function() {
         calculateGrandTotal();
     });

     $('input[name="shipping_cost"]').on("input", function() {
         calculateGrandTotal();
     });

     $('select[name="order_tax_rate"]').on("change", function() {
         calculateGrandTotal();
     });

     $(window).keydown(function(e){
         if (e.which == 13) {
             var $targ = $(e.target);
             if (!$targ.is("textarea") && !$targ.is(":button,:submit")) {
                 var focusNext = false;
                 $(this).find(":input:visible:not([disabled],[readonly]), a").each(function(){
                     if (this === e.target) {
                         focusNext = true;
                     }
                     else if (focusNext){
                         $(this).focus();
                         return false;
                     }
                 });
                 return false;
             }
         }
     });

     $('#payment-form').on('submit',function(e){
         var rownumber = $('table.order-list tbody tr:last').index();
         if (rownumber < 0) {
             alert("Please insert product to order table!")
             e.preventDefault();
         }
     });
     </script>




</body>
</html>
