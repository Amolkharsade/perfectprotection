<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/User.php");


$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="index";
session_start();

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

if(isset($_POST['loginmember']))
{
    $enteredCaptcha = $_POST['captcha_code'];

    if($_SESSION['CAPTCHA_CODE']==$enteredCaptcha)
    {

        $user->setEmail($_POST['inputusername']);
        $user->setPassword($_POST['inputpassword']);
        $valid = $user->checkValidEmailAddress($user->getEmail());

        if($valid==1)
        {
          $value = $user->emaillogin($user->getEmail(), $user->getPassword());
          if($value==1)
          {
            // Password is correct, so start a new session
            session_start();

            // Store data in session variables
            $_SESSION["loggedin"] = true;

            // Redirect user to welcome page
            $_SESSION["username"] = $user->getEmail();
            header("location: home");

          }
          else {
            $errormessage="Incorrect password for the account !!";
          }
        }
        else{
              $errormessage="Email Address is not valid. Please check once !!";
        }
    }
    else {

      $errormessage="Invalid Captcha Code Entered !!";
    }

}



?>

<!DOCTYPE html>
<html>
  <head>
    <?php include_once("htmlheader.php"); ?>
    <title><?php echo $project->getProjectFName()?> | Login</title>

  </head>
  <body style="">
    <div class="page login-page">
      <div class="container">
        <div class="form-outer text-center d-flex align-items-center">
          <div class="form-inner">
            <div class="form-group-material">
                <img src="images/Perfect Protection Shield.png" width="100px"/>
            </div>
            <div class="logo"><span>Perfect Protection</span></div>

            <?php
            if(isset($successmessage))
            {
            ?>
            <div class="alert alert-success alert-dismissible text-center">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <?php echo $successmessage; ?>
            </div>
          <?php } ?>
          <?php
          if(isset($errormessage))
          {
          ?>
          <div class="alert alert-danger alert-dismissible text-center">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo $errormessage; ?>
          </div>
        <?php } ?>
            <form method="POST" action="index" id="login-form">
              <input type="hidden" name="_token" value="lf0D7YTyoThOsgpldT4iBuDy1QBcEo2DsXtgc8yD">
              <div class="form-group-material">
                <input id="login-username" type="text" name="inputusername" required="" class="input-material" value="ravi@blucorsys.com">
                <label for="login-username" class="label-material">Email Address</label>
              </div>
              <div class="form-group-material">
                <input id="login-password" type="password" name="inputpassword" required="" class="input-material" value="asdasd">
                <label for="login-password" class="label-material">Password</label>
              </div>
              <div class="row">
                  <div class="col-md-6 class-right">
                      <div class="form-group has-feedback">
                          <img class="text-center" src="php-captcha-master/scripts/captcha.php" alt="Captcha">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group has-feedback class-center">
                        <input maxlength="6" name="captcha_code" type="text" class="input-material input-sm" required id="captcha_code" oninvalid="this.setCustomValidity('Enter Captcha Code Here')" oninput="this.setCustomValidity('')">
                        <label for="captcha_code" class="label-material">   Captcha Code</label>
                      </div>
                  </div>
              </div>
              <button type="submit" class="btn btn-primary btn-block">LogIn</button>
              <input name="loginmember" value="loginmember" type="hidden" />
            </form>
            <br><br>
            <a href="#" class="forgot-pass">Forgot Password?</a>
          </div>
          <div class="copyrights text-center">
            <p>Developed By <a target="_blank" href="http://blucorsys.com/" class="external">Blucorsys Pvt Lt</a></p>
          </div>
        </div>
      </div>
    </div>



<script type="text/javascript">
    $('.admin-btn').on('click', function(){
        $("input[name='name']").focus().val('admin');
        $("input[name='password']").focus().val('admin');
    });

  $('.staff-btn').on('click', function(){
      $("input[name='name']").focus().val('staff');
      $("input[name='password']").focus().val('staff');
  });
  // ------------------------------------------------------- //
    // Material Inputs
    // ------------------------------------------------------ //

    var materialInputs = $('input.input-material');

    // activate labels for prefilled values
    materialInputs.filter(function() { return $(this).val() !== ""; }).siblings('.label-material').addClass('active');

    // move label on focus
    materialInputs.on('focus', function () {
        $(this).siblings('.label-material').addClass('active');
    });

    // remove/keep label on blur
    materialInputs.on('blur', function () {
        $(this).siblings('.label-material').removeClass('active');

        if ($(this).val() !== '') {
            $(this).siblings('.label-material').addClass('active');
        } else {
            $(this).siblings('.label-material').removeClass('active');
        }
    });
</script>
</body></html>
