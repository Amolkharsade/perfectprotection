<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/Employee.php");

$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="guards";
session_start();

$database = new Database();
$db = $database->getConnection();
$employee = new Employee($db);

if(isset($_POST['addNewValue']))
{
    // $customergroup->setName($_POST['input_name']);
    // $customergroup->setSummary($_POST['input_summary']);
    // if($customergroup->create())
    // {
    //     $successmessage="Customer Group is created successfully";
    // }
    // else {
    //     $errormessage ="Customer Group cannot be added";
    // }

}

if(isset($_POST['editValue']))
{
    // $customergroup->setId($_POST['customergroup_id']);
    // $customergroup->setName($_POST['name']);
    // $customergroup->setSummary($_POST['summary']);
    // if($customergroup->update())
    // {
    //   $successmessage="Customer Group is updated successfully";
    // }
    // else {
    //   $errormessage="Customer Group Information could not be updated !!";
    // }
}

if(isset($_POST['deleteValue']))
{
  // $customergroup->setId($_POST['customer_group_id']);
  // if($customergroup->delete())
  // {
  //   $successmessage="Customer Group is deleted successfully";
  // }
  // else {
  //   $errormessage="Customer Group Information could not be deleted !!";
  // }
}

if(isset($_GET['id']))
{
  $employee->getEmployeeByID($_GET['id']);
}
else {
  header("location:". $project->getProjectUrl()."guards");
  exit;
}

?>

<!DOCTYPE html>
<html>
<head>
   <?php include_once("htmlheader.php"); ?>
   <title><?php echo $project->getProjectFName()?> | Guard Details</title>

</head>

 <body onload="myFunction()" style="">
     <div id="loader"></div>

       <?php include_once("sidebar.php"); ?>

       <?php include_once("header.php"); ?>

       <div class="page">

      <!-- account modal -->
      <div id="account-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
        <div role="document" class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="exampleModalLabel" class="modal-title">Add Staff</h5>
                    <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
                </div>
                <div class="modal-body">
                  <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                    <form method="POST" action="customers-group" accept-charset="UTF-8">
                      <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                      <input name="addNewValue" type="hidden">
                      <div class="form-group">
                          <label>Name *</label>
                          <input type="text" name="input_name" id="input_name" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>Summery *</label>
                          <!-- <input type="text" name="input_summary" id="input_summary" required="" class="form-control"> -->
                          <textarea name="input_summary" id="input_summary" rows="3" class="form-control"></textarea>
                      </div>
                      <div class="form-group">
                          <button type="submit" class="btn btn-primary">Submit</button>
                      </div>
                    </form>
                </div>
            </div>
        </div>
      </div>


      <div style="display: block;" id="content" class="animate-bottom">

      <?php
      if(isset($successmessage))
      {
      ?>
      <div class="alert alert-success alert-dismissible text-center">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo $successmessage; ?>
      </div>
    <?php } ?>
    <?php
    if(isset($errormessage))
    {
    ?>
    <div class="alert alert-danger alert-dismissible text-center">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <?php echo $errormessage; ?>
    </div>
  <?php } ?>



<section class="forms">
  <div class="container-fluid">
      <div class="row">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-header d-flex align-items-center">
                      <h4>Guard Details</h4>
                  </div>
                  <div class="card-body">
                      <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                      <form method="POST" action="guarddetails?id=<?php echo $_GET['id']; ?>" accept-charset="UTF-8" class="payment-form" enctype="multipart/form-data"><input name="_token" type="hidden" value="fYe3holiUMMCtMHKBwiFIIgC8If0Icvqd75v8XuD">
                      <div class="row">
                          <div class="col-md-12">
                              <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong>Employee Code</strong>
                                        </label>
                                        <input type="text" value="<?php echo $employee->getEmployeeCode(); ?>" name="employeecode" readonly id="employeecode" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>FirstName</label>
                                        <input type="text" value="<?php echo $employee->getFirstName(); ?>" name="first_name" id="first_name" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Middle Name</label>
                                        <input type="text" value="<?php echo $employee->getMName(); ?>" name="middle_name" id="middle_name" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>SurName</label>
                                        <input type="text" value="<?php echo $employee->getSurname(); ?>" name="sur_name" id="sur_name" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Date of Birth</label>
                                        <input type="date" value="<?php echo $employee->getBirthDate(); ?>" name="date_of_birth" id="date_of_birth" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Age</label>
                                        <input type="text" value="<?php echo $employee->getAge(); ?>" name="age" id="age" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Education</label>
                                        <input type="text" value="<?php echo $employee->getEducation(); ?>" name="education" id="education" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-12">
                                  <hr/>
                                  <label><strong>Nominee Details</strong></label>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nominee</label>
                                        <input type="text" value="<?php echo $employee->getNominee(); ?>" name="nominee" id="nominee" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nominee Age</label>
                                        <select name="nominee_age" id="nominee_age" class="form-control" step="any">
                                        <option value="">Select</option>
                                        <?php
                                        for($f=10;$f<60;$f++)
                                        {
                                          if($employee->getNomineeAge()==$f)
                                          {
                                              echo "<option selected value=\".$f.\">".$f." Years</option>";
                                          }
                                          else {
                                            echo "<option value=\".$f.\">".$f." Years</option>";
                                          }

                                        }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nominee Relation
                                        </label>
                                        <input type="text" value="<?php echo $employee->getNomineeRelation(); ?>" name="nominee_relation" id="nominee_relation" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-md-12">
                                  <hr/>
                                </div>
                              </div>
                              <div class="form-group">
                                  <input type="submit" value="Update" class="btn btn-primary" id="submit-button">
                              </div>
                          </div>
                      </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>

  <div id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
      <div role="document" class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 id="modal_header" class="modal-title"></h5>
                  <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
              </div>
              <div class="modal-body">
                  <form>
                      <div class="form-group">
                          <label>Quantity</label>
                          <input type="number" name="edit_qty" class="form-control" step="any">
                      </div>
                      <div class="form-group">
                          <label>Unit Discount</label>
                          <input type="number" name="edit_discount" class="form-control" step="any">
                      </div>
                      <div class="form-group">
                          <label>Unit Price</label>
                          <input type="number" name="edit_unit_price" class="form-control" step="any">
                      </div>
                                                  <div class="form-group">
                              <label>Tax Rate</label>
                              <div class="btn-group bootstrap-select form-control"><button type="button" class="btn dropdown-toggle btn-link" data-toggle="dropdown" role="button" title="No Tax"><span class="filter-option pull-left">No Tax</span>&nbsp;<span class="bs-caret"><span class="caret"></span></span></button><div class="dropdown-menu open" role="combobox"><div class="dropdown-menu inner" role="listbox" aria-expanded="false"><a tabindex="0" class="dropdown-item selected" data-original-index="0"><span class="dropdown-item-inner " data-tokens="null" role="option" tabindex="0" aria-disabled="false" aria-selected="true"><span class="text">No Tax</span><span class="fa fa-check check-mark"></span></span></a><a tabindex="0" class="dropdown-item" data-original-index="1"><span class="dropdown-item-inner " data-tokens="null" role="option" tabindex="0" aria-disabled="false" aria-selected="false"><span class="text">vat@10</span><span class="fa fa-check check-mark"></span></span></a><a tabindex="0" class="dropdown-item" data-original-index="2"><span class="dropdown-item-inner " data-tokens="null" role="option" tabindex="0" aria-disabled="false" aria-selected="false"><span class="text">vat@15</span><span class="fa fa-check check-mark"></span></span></a><a tabindex="0" class="dropdown-item" data-original-index="3"><span class="dropdown-item-inner " data-tokens="null" role="option" tabindex="0" aria-disabled="false" aria-selected="false"><span class="text">vat 20</span><span class="fa fa-check check-mark"></span></span></a></div></div><select name="edit_tax_rate" class="form-control selectpicker" tabindex="-98">
                                                                      <option value="0">No Tax</option>
                                                                      <option value="1">vat@10</option>
                                                                      <option value="2">vat@15</option>
                                                                      <option value="3">vat 20</option>
                                                                  </select></div>
                          </div>
                          <div id="edit_unit" class="form-group">
                              <label>Product Unit</label>
                              <div class="btn-group bootstrap-select form-control"><button type="button" class="btn dropdown-toggle bs-placeholder btn-link" data-toggle="dropdown" role="button" title="Nothing selected"><span class="filter-option pull-left">Nothing selected</span>&nbsp;<span class="bs-caret"><span class="caret"></span></span></button><div class="dropdown-menu open" role="combobox"><div class="dropdown-menu inner" role="listbox" aria-expanded="false"></div></div><select name="edit_unit" class="form-control selectpicker" tabindex="-98">
                              </select></div>
                          </div>
                          <button type="button" name="update_btn" class="btn btn-primary">Update</button>
                  </form>
              </div>
          </div>
      </div>
  </div>
</section>




    </div>

      <?php include_once("footer.php"); ?>
    </div>


<script type="text/javascript">
       if ($(window).outerWidth() > 1199) {
           $('nav.side-navbar').removeClass('shrink');
       }

       function myFunction() {
           setTimeout(showPage, 150);
       }
       function showPage() {
         document.getElementById("loader").style.display = "none";
         document.getElementById("content").style.display = "block";
       }

       $("div.alert").delay(3000).slideUp(750);

       function confirmDelete() {
           if (confirm("Are you sure want to delete?")) {
               return true;
           }
           return false;
       }

       $("a#add-expense").click(function(e){
         e.preventDefault();
         $('#expense-modal').modal();
       });

       $("a#add-account").click(function(e){
         e.preventDefault();
         $('#account-modal').modal();
       });

       $("a#account-statement").click(function(e){
         e.preventDefault();
         $('#account-statement-modal').modal();
       });

       $("a#profitLoss-link").click(function(e){
         e.preventDefault();
         $("#profitLoss-report-form").submit();
       });

       $("a#report-link").click(function(e){
         e.preventDefault();
         $("#product-report-form").submit();
       });

       $("a#purchase-report-link").click(function(e){
         e.preventDefault();
         $("#purchase-report-form").submit();
       });

       $("a#sale-report-link").click(function(e){
         e.preventDefault();
         $("#sale-report-form").submit();
       });

       $("a#payment-report-link").click(function(e){
         e.preventDefault();
         $("#payment-report-form").submit();
       });

       $("a#warehouse-report-link").click(function(e){
         e.preventDefault();
         $('#warehouse-modal').modal();
       });

       $("a#user-report-link").click(function(e){
         e.preventDefault();
         $('#user-modal').modal();
       });

       $("a#customer-report-link").click(function(e){
         e.preventDefault();
         $('#customer-modal').modal();
       });

       $("a#supplier-report-link").click(function(e){
         e.preventDefault();
         $('#supplier-modal').modal();
       });

       $("a#due-report-link").click(function(e){
         e.preventDefault();
         $("#due-report-form").submit();
       });

       $(".daterangepicker-field").daterangepicker({
           callback: function(startDate, endDate, period){
             var start_date = startDate.format('YYYY-MM-DD');
             var end_date = endDate.format('YYYY-MM-DD');
             var title = start_date + ' To ' + end_date;
             $(this).val(title);
             $('#account-statement-modal input[name="start_date"]').val(start_date);
             $('#account-statement-modal input[name="end_date"]').val(end_date);
           }
       });

       $('.selectpicker').selectpicker({
           style: 'btn-link',
       });
     </script>


</body>
</html>
