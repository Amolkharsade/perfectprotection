<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/User.php");

$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    // last request was more than 30 minutes ago
    session_unset();     // unset $_SESSION variable for the run-time
    session_destroy();   // destroy session data in storage
    echo "<script>location.reload();</script>";
}
$_SESSION['LAST_ACTIVITY'] = time(); // update last activity time stamp

// echo $_SESSION['LAST_ACTIVITY'];

// get database connection
$database = new Database();
$db = $database->getConnection();

$user = new User($db);

if(isset($_SESSION["username"]))
{
  // echo $_SESSION['username'];
  $user->getUserByEmail($_SESSION['username']);
}
else {
  header("location: ".$project->getProjectUrl()."index");
  exit;
}
 ?><!-- navbar-->
 <header class="header">
   <nav class="navbar">
     <div class="container-fluid">
       <div class="navbar-holder d-flex align-items-center justify-content-between">
         <a id="toggle-btn" href="#" class="menu-btn"><i class="fa fa-bars"> </i></a>
         <span class="brand-big">
           <img src="images/Perfect Protection Shield.png" width="50">&nbsp;&nbsp;<a href="<?php echo $project->getProjectUrl(); ?>home"><h1 class="d-inline"><?php echo $project->getProjectFName(); ?></h1></a></span>
           <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <li class="nav-item"><a id="btnFullscreen"><i class="dripicons-expand"></i></a></li>

                <!-- <li class="nav-item">
                 <a rel="nofollow" data-target="#" href="<?php echo $project->getProjectUrl(); ?>#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-item">
                   <i class="dripicons-bell"></i><span class="badge badge-danger">1</span>
                 </a>
                 <ul class="dropdown-menu edit-options dropdown-menu-right dropdown-default notifications" user="menu">
                     <li class="notifications">
                       <a href="#" class="btn btn-link"> 1 Sample Notification</a>
                     </li>
                 </ul>
               </li> -->

           <!--<li class="nav-item">
               <a class="dropdown-item" href="http://localhost/erp/read_me" target="_blank"><i class="dripicons-information"></i> Help</a>
           </li>-->
           <li class="nav-item">
             <a rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-item">
               <i class="dripicons-user"></i>
               <span><?php echo $user->getName(); ?></span> <i class="fa fa-angle-down"></i>
             </a>
             <ul class="dropdown-menu edit-options dropdown-menu-right dropdown-default" user="menu">
                 <li>
                   <a href="userprofile"><i class="dripicons-user"></i> Profile</a>
                 </li>
                 <!-- <li>
                   <a href="#"><i class="dripicons-gear"></i> Settings</a>
                 </li> -->

                 <li>
                   <a href="logout" onclick="event.preventDefault();
                                    document.getElementById(&#39;logout-form&#39;).submit();"><i class="dripicons-power"></i>
                       Logout
                   </a>
                   <form id="logout-form" action="logout" method="POST" style="display: none;">
                       <input type="hidden" name="_token" value="Xt6DcvPxsnWjvof7wzfPPxRdJCMelG5nVmqwnOpy">                        </form>
                 </li>
             </ul>
           </li>
         </ul>
       </div>
     </div>
   </nav>
 </header>
