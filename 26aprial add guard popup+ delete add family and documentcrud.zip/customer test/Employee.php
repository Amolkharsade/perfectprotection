<?php
require_once("Database.php");

class Employee
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_employee";

    // property declaration
    private $fd_employee_id;
    private $fd_employee_code;
    private $fd_employee_type;
    private $fd_surname;
    private $fd_firstname;
    private $fd_mname;
    private $fd_birthdate;
    private $fd_age;
    private $fd_education;
    private $fd_nominee;
    private $fd_nominee_age;
    private $fd_nominee_relation;
    private $fd_leftdate;

    private $fd_reason_of_leaving;
    private $fd_name_in_bank;
    private $fd_pf_name;
    private $fd_pf_memberId;
    private $fd_joining_date;
    private $fd_confirmation_date;
    private $fd_icard_issue_date;
    private $fd_renewal_date;
    private $fd_tr_deposit;
    private $fd_esi;
    private $fd_pf;
    private $fd_pf_number;
    private $fd_pf_withdrawal;
    private $fd_pf_withdrawal_date;
    private $fd_submission_date;
    private $fd_settlement_date;
    private $fd_cheque_number;
    private $fd_p_tax;
    private $fd_aadhar_name_mismatch;
    private $fd_aadhar_birthdate_yearonly;
    private $fd_status;
    private $fd_createtime;
    private $fd_updatetime;

    // method declaration
    public function getEmployeeId()
    {
        return $this->fd_employee_id;
    }
    public function setEmployeeId($employeeid)
    {
        $this->fd_employee_id = $employeeid;
    }
    public function getEmployeeCode()
    {
        return $this->fd_employee_code;
    }
    public function setEmployeeCode($employeecode)
    {
        $this->fd_employee_code = $employeecode;
    }
    public function getEmployeeType()
    {
        return $this->fd_employee_type;
    }
    public function setEmployeeType($employee_type)
    {
        $this->fd_employee_type = $employee_type;
    }
    public function getSurname()
    {
        return $this->fd_surname;
    }
    public function setSurname($surname)
    {
        $this->fd_surname = $surname;
    }
    public function getFirstName()
    {
        return $this->fd_firstname;
    }
    public function setFirstName($firstname)
    {
        $this->fd_firstname = $firstname;
    }
    public function getMName()
    {
        return $this->fd_mname;
    }
    public function setMName($mname)
    {
        $this->fd_mname = $mname;
    }
    public function getBirthDate()
    {
        return $this->fd_birthdate;
    }
    public function setBirthDate($birthdate)
    {
        $this->fd_birthdate = $birthdate;
    }
    public function getAge()
    {
        return $this->fd_age;
    }
    public function setAge($age)
    {
        $this->fd_age = $age;
    }
    public function getEducation()
    {
        return $this->fd_education;
    }
    public function setEducation($education)
    {
        $this->fd_education = $education;
    }
    public function getNominee()
    {
        return $this->fd_nominee;
    }
    public function setNominee($nominee)
    {
        $this->fd_nominee = $nominee;
    }
    public function getNomineeAge()
    {
        return $this->fd_nominee_age;
    }
    public function setNomineeAge($nomineeage)
    {
        $this->fd_nominee_age = $nomineeage;
    }
    public function getNomineeRelation()
    {
        return $this->fd_nominee_relation;
    }
    public function setNomineeRelation($nomineerelation)
    {
        $this->fd_nominee_relation = $nomineerelation;
    }
    public function getLeftDate()
    {
        return $this->fd_leftdate;
    }
    public function setLeftDate($leftDate)
    {
        $this->fd_leftdate = $leftDate;
    }

    public function getReasonofLeaving()
    {
        return $this->fd_reason_of_leaving;
    }
    public function setReasonofLeaving($reasonOfLeaving)
    {
        $this->fd_reason_of_leaving = $reasonOfLeaving;
    }
    public function getNameInBank()
    {
        return $this->fd_name_in_bank;
    }
    public function setNameInBank($nameInBank)
    {
        $this->fd_name_in_bank = $nameInBank;
    }
    public function getPFName()
    {
        return $this->fd_pf_name;
    }
    public function setPFName($pfname)
    {
        $this->fd_pf_name = $pfname;
    }
    public function getPFMemberId()
    {
        return $this->fd_pf_memberId;
    }
    public function setPFMemberId($memberId)
    {
        $this->fd_pf_memberId = $memberId;
    }
    public function getJoiningDate()
    {
        return $this->fd_joining_date;
    }
    public function setJoiningDate($joiningdate)
    {
        $this->fd_joining_date = $joiningdate;
    }
    public function getConfirmationDate()
    {
        return $this->fd_confirmation_date;
    }
    public function setConfirmationDate($confirmationdate)
    {
        $this->fd_confirmation_date = $confirmationdate;
    }
    public function getIcardIssueDate()
    {
        return $this->fd_icard_issue_date;
    }
    public function setIcardIssueDate($issuedate)
    {
        $this->fd_icard_issue_date = $issuedate;
    }

    public function getRenewalDate()
    {
        return $this->fd_renewal_date;
    }
    public function setRenewalDate($renewal_date)
    {
        $this->fd_renewal_date = $renewal_date;
    }
    public function getTRDeposit()
    {
        return $this->fd_tr_deposit;
    }
    public function setTRDeposit($tr_deposit)
    {
        $this->fd_tr_deposit = $tr_deposit;
    }

    public function getESI()
    {
        return $this->fd_esi;
    }
    public function setESI($esi)
    {
        $this->fd_esi = $esi;
    }

    public function getESINumber()
    {
        return $this->fd_esi_number;
    }
    public function setESINumber($esiNumber)
    {
        $this->fd_esi_number = $esiNumber;
    }
    public function getSmartcardIssued()
    {
        return $this->fd_smartcard_issued;
    }
    public function setSmartcardIssued($smartcard_issued)
    {
        $this->fd_smartcard_issued = $smartcard_issued;
    }
    public function getUidNo()
    {
        return $this->fd_uid_no;
    }
    public function setUidNo($uid_no)
    {
        $this->fd_uid_no = $uid_no;
    }
    public function getSex()
    {
        return $this->fd_sex;
    }
    public function setSex($sex)
    {
        $this->fd_sex = $sex;
    }
    public function getRejoining()
    {
        return $this->fd_rejoining;
    }
    public function setRejoining($rejoining)
    {
        $this->fd_rejoining = $rejoining;
    }
    public function getBankACClosed()
    {
        return $this->fd_bank_ac_closed;
    }
    public function setBankACClosed($bankacclosed)
    {
        $this->fd_bank_ac_closed = $bankacclosed;
    }
    public function getMLWF()
    {
        return $this->fd_mlwf;
    }
    public function setMLWF($mlwf)
    {
        $this->fd_mlwf = $mlwf;
    }
    public function getPF()
    {
        return $this->fd_pf;
    }
    public function setPF($pf)
    {
        $this->fd_pf = $pf;
    }

    public function getPFNumber()
    {
            return $this->fd_pf_number;
    }
    public function setPFNumber($pf_number)
    {
            $this->fd_pf_number = $pf_number;
    }
    public function getPFWithdrawal()
    {
            return $this->fd_pf_withdrawal;
    }
    public function setPFWithdrawal($withdrawal)
    {
            $this->fd_pf_withdrawal = $withdrawal;
    }
    public function getPFWithdrawalDate()
    {
            return $this->fd_pf_withdrawal_date;
    }
    public function setPFWithdrawalDate($withdrawal_date)
    {
            $this->fd_pf_withdrawal_date = $withdrawal_date;
    }
    public function getSubmissionDate()
    {
            return $this->fd_submission_date;
    }
    public function setSubmissionDate($submission_date)
    {
            $this->fd_submission_date = $submission_date;
    }
    public function getSettlementDate()
    {
            return $this->fd_settlement_date;
    }
    public function setSettlementDate($settlement_date)
    {
            $this->fd_settlement_date = $settlement_date;
    }
    public function getChequeNumber()
    {
            return $this->fd_cheque_number;
    }
    public function setChequeNumber($cheque_number)
    {
            $this->fd_cheque_number = $cheque_number;
    }
    public function getPTax()
    {
            return $this->fd_p_tax;
    }
    public function setPTax($ptax)
    {
            $this->fd_p_tax = $ptax;
    }
    public function getAadharNameMismatch()
    {
            return $this->fd_aadhar_name_mismatch;
    }
    public function setAadharNameMismatch($aadharnamemismatch)
    {
            $this->fd_aadhar_name_mismatch = $aadharnamemismatch;
    }
    public function getAadharBirthdateYearOnly()
    {
            return $this->fd_aadhar_birthdate_yearonly;
    }
    public function setAadharBirthdateYearOnly($aadharbirthdateyearonly)
    {
            $this->fd_aadhar_birthdate_yearonly = $aadharbirthdateyearonly;
    }
    public function getUpdateTime()
    {
            return $this->fd_updatetime;
    }
    public function setUpdateTime($updatetime)
    {
            $this->fd_updatetime = $updatetime;
    }
    public function getCreateTime()
    {
            return $this->fd_createtime;
    }
    public function setCreateTime($createtime)
    {
            $this->fd_createtime = $createtime;
    }
    public function getStatus()
    {
            return $this->fd_status;
    }
    public function setStatus($status)
    {
            $this->fd_status = $status;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getEmployeeByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE fd_employee_id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setEmployeeId($row['fd_employee_id']);
        $this->setEmployeeCode($row['fd_employee_code']);
        $this->setSurname($row['fd_surname']);
        $this->setFirstName($row['fd_firstname']);
        $this->setMName($row['fd_mname']);
        $this->setBirthDate($row['fd_birthdate']);
        $this->setAge($row['fd_age']);
        $this->setEducation($row['fd_education']);
        $this->setNominee($row['fd_nominee']);
        $this->setNomineeAge($row['fd_nominee_age']);
        $this->setNomineeRelation($row['fd_nominee_relation']);
        $this->setLeftDate($row['fd_leftdate']);
        $this->setReasonofLeaving($row['fd_reason_of_leaving']);
        $this->setNameInBank($row['fd_leftdate']);
        $this->setPFName($row['fd_pf_name']);
        $this->setPFMemberId($row['fd_pf_memberId']);
        $this->setJoiningDate($row['fd_joining_date']);
        $this->setConfirmationDate($row['fd_confirmation_date']);
        $this->setIcardIssueDate($row['fd_icard_issue_date']);
        $this->setRenewalDate($row['fd_renewal_date']);
        $this->setTRDeposit($row['fd_leftdate']);
        $this->setESI($row['fd_leftdate']);
        $this->setESINumber($row['fd_leftdate']);
        $this->setSmartcardIssued($row['fd_leftdate']);
        $this->setUidNo($row['fd_leftdate']);
        $this->setSex($row['fd_leftdate']);
        $this->setRejoining($row['fd_rejoining']);
        $this->setBankACClosed($row['fd_bank_ac_closed']);
        $this->setMLWF($row['fd_mlwf']);
        $this->setPF($row['fd_pf']);
        $this->setPFNumber($row['fd_pf_number']);
        $this->setPFWithdrawal($row['fd_pf_withdrawal']);
        $this->setPFWithdrawalDate($row['fd_pf_withdrawal_date']);
        $this->setSubmissionDate($row['fd_submission_date']);
        $this->setSettlementDate($row['fd_settlement_date']);
        $this->setChequeNumber($row['fd_cheque_number']);
        $this->setPTax($row['fd_p_tax']);
        $this->setStatus($row['fd_status']);
        $this->setCreateTime($row['fd_createtime']);
        $this->setUpdateTime($row['fd_updatetime']);

    }

	function readAllGuards()
	{
		  $query = "SELECT * FROM " . $this->table_name . " where fd_employee_type='guard' ORDER BY fd_employee_id DESC";
      $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}
  function readAllStaff()
	{
		  $query = "SELECT * FROM " . $this->table_name . " where fd_employee_type='staff' ORDER BY fd_employee_id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}
  function readAllCleaners()
	{
		  $query = "SELECT * FROM " . $this->table_name . " where fd_employee_type='cleaners' ORDER BY fd_employee_id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      name = :name,
					            summary  = :summary
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->name=htmlspecialchars(strip_tags($this->getName()));
        $this->summary=htmlspecialchars(strip_tags($this->getSummary()));

        // bind parameters
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':summary', $this->summary);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      name=:name,
                      summary=:summary,
                      updated_at =:updateTimeStamp
                WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->name=htmlspecialchars(strip_tags($this->getName()));
          $this->summary=htmlspecialchars(strip_tags($this->getSummary()));

          // bind parameters
          $stmt->bindParam(':name', $this->name);
          $stmt->bindParam(':summary', $this->summary);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the user
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE fd_employee_id = ?";

  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->fd_employee_id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}

}
?>
