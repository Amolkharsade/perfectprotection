-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2021 at 12:11 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pperp`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initial_balance` double DEFAULT NULL,
  `total_balance` double NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `account_no`, `name`, `initial_balance`, `total_balance`, `note`, `is_default`, `created_at`, `updated_at`) VALUES
(1, '11111', 'Sales Account', 1000, 1000, 'this is first account', 1, '2018-12-18 02:58:02', '2020-12-06 13:06:53'),
(3, '21211', 'Sample Account', 20000, 20000, 'this is the sample account', 0, '2018-12-18 02:58:56', '2021-04-04 10:06:20');

-- --------------------------------------------------------

--
-- Table structure for table `adjustments`
--

CREATE TABLE `adjustments` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_qty` double NOT NULL,
  `item` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attendances`
--

CREATE TABLE `attendances` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `employee_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `checkin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkout` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attendances`
--

INSERT INTO `attendances` (`id`, `date`, `employee_id`, `user_id`, `checkin`, `checkout`, `status`, `note`, `created_at`, `updated_at`) VALUES
(1, '2019-01-02', 1, 1, '10:00am', '6:30pm', 1, NULL, '2019-01-02 03:30:50', '2019-01-02 03:30:50'),
(3, '2019-01-02', 3, 1, '10:15am', '6:30pm', 0, NULL, '2019-01-02 03:57:12', '2019-01-02 03:57:12'),
(6, '2020-02-03', 1, 1, '11:30am', '6:00pm', 0, NULL, '2020-02-03 09:57:30', '2020-02-03 09:57:30');

-- --------------------------------------------------------

--
-- Table structure for table `billers`
--

CREATE TABLE `billers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vat_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `billers`
--

INSERT INTO `billers` (`id`, `name`, `image`, `company_name`, `vat_number`, `email`, `phone_number`, `address`, `city`, `state`, `postal_code`, `country`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'yousuf', 'aks.jpg', 'aks', '31123', 'yousuf@kds.com', '442343324', 'halishahar', 'chittagong', NULL, NULL, 'sdgs', 1, '2018-05-12 21:49:30', '2019-03-02 05:20:38'),
(2, 'tariq', NULL, 'big tree', NULL, 'tariq@bigtree.com', '321312', 'khulshi', 'chittagong', NULL, NULL, NULL, 1, '2018-05-12 21:57:54', '2018-06-15 00:07:11'),
(3, 'test', NULL, 'test', NULL, 'test@test.com', '3211', 'erewrwqre', 'afsf', NULL, NULL, NULL, 0, '2018-05-30 02:38:58', '2018-05-30 02:39:57'),
(5, 'modon', 'mogaTel.jpg', 'mogaTel', '', 'modon@gmail.com', '32321', 'nasirabad', 'chittagong', '', '', 'bd', 1, '2018-09-01 03:59:54', '2018-10-07 02:35:51'),
(6, 'a', NULL, 'a', NULL, 'a@a.com', 'q', 'q', 'q', NULL, NULL, NULL, 0, '2018-10-07 02:33:39', '2018-10-07 02:34:18'),
(7, 'a', NULL, 'a', NULL, 'a@a.com', 'a', 'a', 'a', NULL, NULL, NULL, 0, '2018-10-07 02:34:36', '2018-10-07 02:36:07'),
(8, 'x', 'x.png', 'x', NULL, 'x@x.com', 'x', 'x', 'x', NULL, NULL, NULL, 1, '2019-03-18 11:02:42', '2019-12-21 11:01:24');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `title`, `image`, `is_active`, `created_at`, `updated_at`) VALUES
(3, 'Sample', 'HP.jpg', 1, '2018-05-12 09:06:14', '2019-03-02 05:32:21'),
(4, 'Sample1', 'samsung.jpg', 0, '2018-05-12 09:08:41', '2021-03-12 08:43:27'),
(5, 'Sample2', 'Apple.jpg', 0, '2018-08-31 23:34:49', '2021-03-12 08:43:20');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'CONSUMABLE ITEMS', '2018-05-12 03:27:25', '2021-03-18 10:43:46'),
(2, 'SEASONAL ITEMS', '2018-05-12 03:35:57', '2021-03-18 10:43:55'),
(3, 'UNIFORM ITEMS', '2018-05-12 03:36:08', '2021-03-18 10:43:30');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `minimum_amount` double DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `used` int(11) NOT NULL,
  `expired_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `type`, `amount`, `minimum_amount`, `quantity`, `used`, `expired_date`, `user_id`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'sonar bangla', 'percentage', 20, 0, 100, 3, '2020-03-31', 1, 1, '2018-10-25 22:38:50', '2020-03-11 10:46:41'),
(2, 'i love bangladesh', 'fixed', 200, 1000, 50, 1, '2018-12-31', 1, 1, '2018-10-27 02:59:26', '2019-03-02 05:46:48');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customer_group_id`, `name`, `company_name`, `email`, `phone_number`, `address`, `city`, `state`, `postal_code`, `country`, `created_at`, `updated_at`) VALUES
(15, 1, 'Sample', '1', 'ravi@gmail.com', '9890890809', 'Testing address', 'pune', 'Maharashtra', '412125', 'India', '2018-11-05 04:00:39', '2021-03-15 11:23:47'),
(17, 1, 'Sample Testing', '2', 'Ravi123@gfmail.com', '8989887787', 'testing', 'aasdas', 'asdas', '2341234', 'asdasd', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_groups`
--

CREATE TABLE `customer_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_groups`
--

INSERT INTO `customer_groups` (`id`, `name`, `summary`, `created_at`, `updated_at`) VALUES
(2, 'distributor', 'Testing ', '2018-05-12 08:12:14', '2021-03-15 09:06:13'),
(3, 'reseller', 'Testing', '2018-05-12 08:12:26', '2021-03-15 09:06:23'),
(4, 'test', 'Testing Summary', '2018-05-30 01:17:16', '2021-03-15 09:06:03'),
(8, 'S Balan', 'S Balan Group of Company', '2021-04-04 11:26:32', '2021-04-04 11:26:32');

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

CREATE TABLE `deliveries` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale_id` int(11) NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivered_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recieved_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`id`, `reference_no`, `sale_id`, `address`, `delivered_by`, `recieved_by`, `file`, `note`, `status`, `created_at`, `updated_at`) VALUES
(1, 'dr-20180808-044431', 1, 'kajir deuri chittagong bd', 'abul', 'dhiman', NULL, NULL, '3', '2018-08-08 10:44:55', '2018-11-06 04:59:06'),
(2, 'dr-20181106-105936', 88, 'mohammadpur dhaka', NULL, NULL, NULL, NULL, '2', '2018-11-06 04:59:43', '2018-11-06 05:10:38'),
(3, 'dr-20181106-111321', 79, 'mohammadpur dhaka', NULL, NULL, NULL, NULL, '3', '2018-11-06 05:13:25', '2018-11-06 05:13:25');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Guards', 1, '2018-12-27 05:16:47', '2021-03-12 08:46:41'),
(2, 'Supervisior', 1, '2018-12-27 10:28:47', '2021-03-12 08:46:59'),
(3, 'Cleaner', 1, '2021-03-12 08:47:06', '2021-03-12 08:47:06'),
(4, 'Office', 1, '2021-03-12 08:52:18', '2021-03-12 08:52:18');

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(10) UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`id`, `amount`, `customer_id`, `user_id`, `note`, `created_at`, `updated_at`) VALUES
(1, 90, 1, 1, 'first deposit', '2018-08-25 22:48:23', '2018-08-26 01:18:55'),
(3, 100, 2, 1, NULL, '2018-08-26 00:53:16', '2018-08-26 21:42:39'),
(4, 50, 1, 1, NULL, '2018-09-04 22:56:19', '2018-09-04 22:56:19'),
(5, 50, 1, 1, NULL, '2018-09-10 00:08:40', '2018-09-10 00:08:40');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `email`, `phone_number`, `department_id`, `user_id`, `image`, `address`, `city`, `country`, `is_active`, `created_at`, `updated_at`) VALUES
(6, 'Ravi Jadhav', 'ravi@gmail.com', '9981923981', 4, 20, NULL, 'Testing', 'Pune', 'India', 1, '2021-03-12 08:57:33', '2021-03-12 08:57:33');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `reference_no`, `expense_category_id`, `account_id`, `user_id`, `amount`, `note`, `created_at`, `updated_at`) VALUES
(25, 'er-20200406-075239', 4, 3, 19, 750, 'This is the testing expense', '2020-04-06 13:52:39', '2021-04-04 09:13:22'),
(29, 'ex-20210404-623804', 2, 3, 19, 2100, 'asdasd', '2021-04-04 09:07:43', '2021-04-04 09:10:06');

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

CREATE TABLE `expense_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expense_categories`
--

INSERT INTO `expense_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'washing', '2018-08-16 00:32:48', '2019-03-02 07:02:07'),
(2, 'electric bill', '2018-08-16 00:39:18', '2018-08-16 00:39:18'),
(4, 'snacks', '2018-09-01 02:40:04', '2018-09-01 02:40:04');

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `site_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_access` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `currency_position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`id`, `site_title`, `site_logo`, `currency`, `staff_access`, `date_format`, `theme`, `created_at`, `updated_at`, `currency_position`) VALUES
(1, 'Perfect Protection', 'Perfect Protection Shield.png', 'USD', 'own', 'd/m/Y', 'default.css', '2018-07-06 06:13:11', '2020-12-02 14:28:15', 'prefix');

-- --------------------------------------------------------

--
-- Table structure for table `gift_cards`
--

CREATE TABLE `gift_cards` (
  `id` int(10) UNSIGNED NOT NULL,
  `card_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `expense` double NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expired_date` date DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gift_cards`
--

INSERT INTO `gift_cards` (`id`, `card_no`, `amount`, `expense`, `customer_id`, `user_id`, `expired_date`, `created_by`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '3571097513020486', 1400, 400, 1, NULL, '2020-12-31', 1, 1, '2018-08-18 01:57:40', '2019-11-10 13:06:01'),
(2, '0452297501931931', 370, 100, 2, NULL, '2020-12-31', 1, 1, '2018-08-18 02:46:43', '2019-11-10 12:56:28'),
(3, '123', 13123, 0, 1, NULL, '2018-08-19', 1, 0, '2018-08-18 22:38:21', '2018-08-18 22:38:28'),
(4, '1862381252690499', 100, 0, NULL, 1, '2018-10-04', 1, 0, '2018-09-30 00:16:28', '2018-09-30 00:17:21'),
(5, '2300813717254199', 143, 0, NULL, 1, '2018-10-04', 1, 0, '2018-09-30 00:18:49', '2018-09-30 00:20:20'),
(6, '8327019475026421', 1, 0, 1, NULL, '2018-10-07', 1, 0, '2018-10-07 03:12:41', '2018-10-07 03:12:55'),
(7, '2063379780590151', 1, 0, 1, NULL, '2018-10-23', 1, 0, '2018-10-23 00:23:22', '2018-10-23 00:23:39');

-- --------------------------------------------------------

--
-- Table structure for table `gift_card_recharges`
--

CREATE TABLE `gift_card_recharges` (
  `id` int(10) UNSIGNED NOT NULL,
  `gift_card_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gift_card_recharges`
--

INSERT INTO `gift_card_recharges` (`id`, `gift_card_id`, `amount`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 2, 100, 1, '2018-08-24 23:08:29', '2018-08-24 23:08:29'),
(2, 1, 200, 1, '2018-08-24 23:08:50', '2018-08-24 23:08:50'),
(3, 1, 100, 1, '2018-09-04 23:50:41', '2018-09-04 23:50:41'),
(4, 1, 50, 1, '2018-09-04 23:51:38', '2018-09-04 23:51:38'),
(5, 1, 50, 1, '2018-09-04 23:53:36', '2018-09-04 23:53:36'),
(6, 2, 50, 1, '2018-09-04 23:54:34', '2018-09-04 23:54:34'),
(7, 5, 10, 1, '2018-09-30 00:19:48', '2018-09-30 00:19:48'),
(8, 5, 10, 1, '2018-09-30 00:20:04', '2018-09-30 00:20:04'),
(9, 2, 100, 1, '2018-10-07 03:13:05', '2018-10-07 03:13:05'),
(10, 1, 200, 1, '2018-10-07 03:13:39', '2018-10-07 03:13:39'),
(11, 1, 300, 1, '2018-10-23 00:22:49', '2018-10-23 00:22:49');

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`id`, `user_id`, `from_date`, `to_date`, `note`, `is_approved`, `created_at`, `updated_at`) VALUES
(12, 18, '2021-04-02', '2021-04-02', 'Good Friday', 1, '2021-03-12 08:59:11', '2021-03-12 08:59:11'),
(13, 18, '2021-03-29', '2021-03-29', 'Testing', 1, '2021-03-12 08:59:40', '2021-03-12 08:59:40');

-- --------------------------------------------------------

--
-- Table structure for table `hrm_settings`
--

CREATE TABLE `hrm_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `checkin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkout` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `hrm_settings`
--

INSERT INTO `hrm_settings` (`id`, `checkin`, `checkout`, `created_at`, `updated_at`) VALUES
(1, '10:00am', '6:00pm', '2019-01-02 02:20:08', '2019-01-02 04:20:53');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `code`, `created_at`, `updated_at`) VALUES
(1, 'en', '2018-07-07 22:59:17', '2019-12-24 17:34:20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_02_17_060412_create_categories_table', 1),
(4, '2018_02_20_035727_create_brands_table', 1),
(5, '2018_02_25_100635_create_suppliers_table', 1),
(6, '2018_02_27_101619_create_warehouse_table', 1),
(7, '2018_03_03_040448_create_units_table', 1),
(8, '2018_03_04_041317_create_taxes_table', 1),
(9, '2018_03_10_061915_create_customer_groups_table', 1),
(10, '2018_03_10_090534_create_customers_table', 1),
(11, '2018_03_11_095547_create_billers_table', 1),
(12, '2018_04_05_054401_create_products_table', 1),
(13, '2018_04_06_133606_create_purchases_table', 1),
(14, '2018_04_06_154600_create_product_purchases_table', 1),
(15, '2018_04_06_154915_create_product_warhouse_table', 1),
(16, '2018_04_10_085927_create_sales_table', 1),
(17, '2018_04_10_090133_create_product_sales_table', 1),
(18, '2018_04_10_090254_create_payments_table', 1),
(19, '2018_04_10_090341_create_payment_with_cheque_table', 1),
(20, '2018_04_10_090509_create_payment_with_credit_card_table', 1),
(21, '2018_04_13_121436_create_quotation_table', 1),
(22, '2018_04_13_122324_create_product_quotation_table', 1),
(23, '2018_04_14_121802_create_transfers_table', 1),
(24, '2018_04_14_121913_create_product_transfer_table', 1),
(25, '2018_05_13_082847_add_payment_id_and_change_sale_id_to_payments_table', 2),
(26, '2018_05_13_090906_change_customer_id_to_payment_with_credit_card_table', 3),
(27, '2018_05_20_054532_create_adjustments_table', 4),
(28, '2018_05_20_054859_create_product_adjustments_table', 4),
(29, '2018_05_21_163419_create_returns_table', 5),
(30, '2018_05_21_163443_create_product_returns_table', 5),
(31, '2018_06_02_050905_create_roles_table', 6),
(32, '2018_06_02_073430_add_columns_to_users_table', 7),
(33, '2018_06_03_053738_create_permission_tables', 8),
(36, '2018_06_21_063736_create_pos_setting_table', 9),
(37, '2018_06_21_094155_add_user_id_to_sales_table', 10),
(38, '2018_06_21_101529_add_user_id_to_purchases_table', 11),
(39, '2018_06_21_103512_add_user_id_to_transfers_table', 12),
(40, '2018_06_23_061058_add_user_id_to_quotations_table', 13),
(41, '2018_06_23_082427_add_is_deleted_to_users_table', 14),
(42, '2018_06_25_043308_change_email_to_users_table', 15),
(43, '2018_07_06_115449_create_general_settings_table', 16),
(44, '2018_07_08_043944_create_languages_table', 17),
(45, '2018_07_11_102144_add_user_id_to_returns_table', 18),
(46, '2018_07_11_102334_add_user_id_to_payments_table', 18),
(47, '2018_07_22_130541_add_digital_to_products_table', 19),
(49, '2018_07_24_154250_create_deliveries_table', 20),
(50, '2018_08_16_053336_create_expense_categories_table', 21),
(51, '2018_08_17_115415_create_expenses_table', 22),
(55, '2018_08_18_050418_create_gift_cards_table', 23),
(56, '2018_08_19_063119_create_payment_with_gift_card_table', 24),
(57, '2018_08_25_042333_create_gift_card_recharges_table', 25),
(58, '2018_08_25_101354_add_deposit_expense_to_customers_table', 26),
(59, '2018_08_26_043801_create_deposits_table', 27),
(60, '2018_09_02_044042_add_keybord_active_to_pos_setting_table', 28),
(61, '2018_09_09_092713_create_payment_with_paypal_table', 29),
(62, '2018_09_10_051254_add_currency_to_general_settings_table', 30),
(63, '2018_10_22_084118_add_biller_and_store_id_to_users_table', 31),
(65, '2018_10_26_034927_create_coupons_table', 32),
(66, '2018_10_27_090857_add_coupon_to_sales_table', 33),
(67, '2018_11_07_070155_add_currency_position_to_general_settings_table', 34),
(68, '2018_11_19_094650_add_combo_to_products_table', 35),
(69, '2018_12_09_043712_create_accounts_table', 36),
(70, '2018_12_17_112253_add_is_default_to_accounts_table', 37),
(71, '2018_12_19_103941_add_account_id_to_payments_table', 38),
(72, '2018_12_20_065900_add_account_id_to_expenses_table', 39),
(73, '2018_12_20_082753_add_account_id_to_returns_table', 40),
(74, '2018_12_26_064330_create_return_purchases_table', 41),
(75, '2018_12_26_144210_create_purchase_product_return_table', 42),
(76, '2018_12_26_144708_create_purchase_product_return_table', 43),
(77, '2018_12_27_110018_create_departments_table', 44),
(78, '2018_12_30_054844_create_employees_table', 45),
(79, '2018_12_31_125210_create_payrolls_table', 46),
(80, '2018_12_31_150446_add_department_id_to_employees_table', 47),
(81, '2019_01_01_062708_add_user_id_to_expenses_table', 48),
(82, '2019_01_02_075644_create_hrm_settings_table', 49),
(83, '2019_01_02_090334_create_attendances_table', 50),
(84, '2019_01_27_160956_add_three_columns_to_general_settings_table', 51),
(85, '2019_02_15_183303_create_stock_counts_table', 52),
(86, '2019_02_17_101604_add_is_adjusted_to_stock_counts_table', 53),
(87, '2019_04_13_101707_add_tax_no_to_customers_table', 54),
(89, '2019_10_14_111455_create_holidays_table', 55),
(90, '2019_11_13_145619_add_is_variant_to_products_table', 56),
(91, '2019_11_13_150206_create_product_variants_table', 57),
(92, '2019_11_13_153828_create_variants_table', 57),
(93, '2019_11_25_134041_add_qty_to_product_variants_table', 58),
(94, '2019_11_25_134922_add_variant_id_to_product_purchases_table', 58),
(95, '2019_11_25_145341_add_variant_id_to_product_warehouse_table', 58),
(96, '2019_11_29_182201_add_variant_id_to_product_sales_table', 59),
(97, '2019_12_04_121311_add_variant_id_to_product_quotation_table', 60),
(98, '2019_12_05_123802_add_variant_id_to_product_transfer_table', 61),
(100, '2019_12_08_114954_add_variant_id_to_product_returns_table', 62),
(101, '2019_12_08_203146_add_variant_id_to_purchase_product_return_table', 63),
(102, '2020_02_28_103340_create_money_transfers_table', 64);

-- --------------------------------------------------------

--
-- Table structure for table `money_transfers`
--

CREATE TABLE `money_transfers` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_account_id` int(11) NOT NULL,
  `to_account_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `money_transfers`
--

INSERT INTO `money_transfers` (`id`, `reference_no`, `from_account_id`, `to_account_id`, `amount`, `created_at`, `updated_at`) VALUES
(2, 'mtr-20200228-071852', 1, 3, 100, '2020-02-28 13:18:52', '2020-02-28 13:18:52');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('ravi.d.jadhav@gmail.com', '$2y$10$Ag3IwEQ//MkecM1MuOdWWeQB3sNv4UCMp2xkYzHW1tdM0SUskx7hO', '2020-12-01 04:41:18');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `payment_reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `account_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `change` double NOT NULL,
  `paying_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `payment_reference`, `user_id`, `purchase_id`, `sale_id`, `account_id`, `amount`, `change`, `paying_method`, `payment_note`, `created_at`, `updated_at`) VALUES
(33, 'spr-20180809-055453', 1, NULL, 2, 1, 1000, 0, 'Cash', NULL, '2018-08-08 23:54:53', '2018-08-08 23:54:53'),
(34, 'spr-20180809-055553', 1, NULL, 2, 1, 1200, 0, 'Cheque', NULL, '2018-08-08 23:55:53', '2018-08-08 23:56:36'),
(35, 'spr-20180809-063214', 1, NULL, 3, 1, 897, 0, 'Cheque', NULL, '2018-08-09 00:32:14', '2018-08-09 00:32:14'),
(36, 'spr-20180825-034836', 1, NULL, 4, 1, 100, 0, 'Gift Card', '100 bucks paid...', '2018-08-24 21:48:36', '2018-08-25 00:57:35'),
(39, 'spr-20180825-083634', 1, NULL, 4, 1, 200, 0, 'Gift Card', NULL, '2018-08-25 02:36:34', '2018-08-25 02:36:34'),
(41, 'spr-20180826-094836', 1, NULL, 6, 1, 20, 0, 'Deposit', '20 bucks paid', '2018-08-26 03:48:36', '2018-08-26 21:42:13'),
(42, 'spr-20180827-073545', 1, NULL, 7, 1, 880, 0, 'Cash', NULL, '2018-08-27 01:35:45', '2018-08-27 01:35:45'),
(43, 'ppr-20180830-071637', 1, 13, NULL, 1, 100, 0, 'Cash', '100 bucks paid...', '2018-08-30 01:16:37', '2018-08-30 01:16:37'),
(44, 'ppr-20180830-090718', 1, 13, NULL, 1, 200, 0, 'Cheque', NULL, '2018-08-30 03:07:18', '2018-08-30 03:07:18'),
(46, 'spr-20180902-053954', 1, NULL, 8, 1, 3529.8, 0, 'Cash', 'fully paid', '2018-09-01 23:39:54', '2018-09-01 23:39:54'),
(49, 'spr-20180903-033314', 1, NULL, 9, 1, 20, 0, 'Deposit', 'fully paid', '2018-09-02 21:33:14', '2018-09-02 21:33:14'),
(50, 'spr-20180903-050138', 1, NULL, 10, 1, 200, 0, 'Gift Card', '50 bucks due...', '2018-09-02 23:01:38', '2018-09-09 21:40:28'),
(51, 'spr-20180903-100821', 1, NULL, 11, 1, 5500, 0, 'Cheque', NULL, '2018-09-03 04:08:21', '2018-09-03 04:08:21'),
(53, 'ppr-20180903-101524', 1, 16, NULL, 1, 1750, 0, 'Cheque', NULL, '2018-09-03 04:15:24', '2018-10-06 01:09:20'),
(78, 'spr-20180926-092105', 1, NULL, 31, 1, 560, 0, 'Cash', NULL, '2018-09-26 03:21:05', '2018-09-26 03:21:05'),
(79, 'spr-20181006-065017', 1, NULL, 30, 1, 100, 0, 'Cheque', NULL, '2018-10-06 00:50:17', '2018-10-06 00:51:55'),
(80, 'spr-20181006-065222', 1, NULL, 30, 1, 20, 0, 'Cash', NULL, '2018-10-06 00:52:22', '2018-10-06 00:52:22'),
(82, 'ppr-20181006-070935', 1, 16, NULL, 1, 1600, 0, 'Cash', NULL, '2018-10-06 01:09:35', '2018-10-06 01:09:35'),
(83, 'spr-20181010-041636', 1, NULL, 41, 1, 461, 0, 'Cash', NULL, '2018-10-09 22:16:36', '2018-10-09 22:16:36'),
(84, 'spr-20181010-053456', 1, NULL, 42, 1, 440, 0, 'Cash', NULL, '2018-10-09 23:34:56', '2018-10-09 23:34:56'),
(91, 'spr-20181021-065338', 1, NULL, 55, 1, 250, 0, 'Cash', NULL, '2018-10-21 00:53:38', '2018-10-21 00:53:38'),
(92, 'spr-20181021-082618', 1, NULL, 57, 1, 575.2, 0, 'Cash', NULL, '2018-10-21 02:26:18', '2018-10-21 02:26:18'),
(93, 'spr-20181022-032730', 1, NULL, 58, 1, 1220, 0, 'Cash', NULL, '2018-10-22 09:27:30', '2018-10-22 09:27:30'),
(104, 'spr-20181023-071548', 11, NULL, 73, 1, 5500, 0, 'Cash', NULL, '2018-10-23 01:15:48', '2018-10-23 01:15:48'),
(105, 'spr-20181023-071648', 1, NULL, 74, 1, 2320, 0, 'Cash', NULL, '2018-10-23 01:16:48', '2018-10-23 01:16:48'),
(126, 'spr-20181101-050033', 1, NULL, 75, 1, 7678, 0, 'Cash', NULL, '2018-10-31 23:00:33', '2018-10-31 23:00:33'),
(127, 'spr-20181101-050130', 1, NULL, 76, 1, 1424, 0, 'Cash', NULL, '2018-10-31 23:01:30', '2018-11-08 03:44:51'),
(129, 'spr-20181105-091523', 1, NULL, 79, 1, 14454, 0, 'Cash', NULL, '2018-11-05 03:15:23', '2018-11-05 03:15:23'),
(130, 'spr-20181105-092002', 1, NULL, 80, 1, 2500, 0, 'Cash', NULL, '2018-11-05 03:20:02', '2018-11-05 03:20:02'),
(131, 'ppr-20181105-092128', 1, 24, NULL, 1, 15950, 0, 'Cash', NULL, '2018-11-05 03:21:28', '2018-11-05 03:21:28'),
(137, 'spr-20181105-095952', 1, NULL, 86, 1, 1100, 0, 'Cash', NULL, '2018-11-05 03:59:52', '2018-11-05 03:59:52'),
(138, 'spr-20181105-100310', 1, NULL, 88, 1, 1100, 0, 'Cash', NULL, '2018-11-05 04:03:10', '2018-11-05 04:03:10'),
(139, 'spr-20181126-020534', 1, NULL, 94, 1, 120, 0, 'Cash', NULL, '2018-11-26 08:05:34', '2018-11-26 08:05:34'),
(140, 'spr-20181128-071515', 1, NULL, 96, 1, 132, 0, 'Cash', NULL, '2018-11-28 01:15:15', '2018-11-28 01:15:15'),
(141, 'spr-20181201-060524', 1, NULL, 97, 1, 200, 300, 'Cash', NULL, '2018-12-01 00:05:24', '2018-12-04 00:21:05'),
(148, 'ppr-20181204-065932', 1, 23, NULL, 1, 500, 500, 'Cash', NULL, '2018-12-04 00:59:32', '2018-12-04 00:59:44'),
(149, 'ppr-20181205-053443', 1, 25, NULL, 1, 4450, 550, 'Cash', NULL, '2018-12-04 23:34:43', '2018-12-04 23:34:43'),
(150, 'spr-20181205-053608', 1, NULL, 98, 1, 800, 200, 'Cash', NULL, '2018-12-04 23:36:08', '2018-12-04 23:36:08'),
(151, 'spr-20181205-053724', 1, NULL, 99, 1, 800, 0, 'Cash', NULL, '2018-12-04 23:37:24', '2018-12-04 23:37:24'),
(152, 'spr-20181208-062032', 1, NULL, 101, 1, 100, 400, 'Cash', NULL, '2018-12-08 00:20:32', '2018-12-11 03:19:39'),
(157, 'ppr-20181220-063439', 1, 27, NULL, 1, 10, 0, 'Cash', NULL, '2018-12-20 00:34:39', '2018-12-20 00:35:01'),
(159, 'spr-20181224-045832', 1, NULL, 103, 1, 120, 0, 'Cash', NULL, '2018-12-23 22:58:32', '2018-12-23 22:58:32'),
(160, 'spr-20190101-054544', 1, NULL, 105, 1, 21, 0, 'Cash', NULL, '2018-12-31 23:45:44', '2018-12-31 23:45:44'),
(161, 'spr-20190101-091040', 1, NULL, 106, 1, 860, 0, 'Cash', NULL, '2019-01-01 03:10:40', '2019-01-01 03:10:40'),
(162, 'spr-20190103-065627', 1, NULL, 107, 1, 5040, 960, 'Cash', NULL, '2019-01-03 00:56:27', '2019-01-03 00:56:27'),
(163, 'spr-20190120-035824', 1, NULL, 108, 1, 120, 0, 'Cash', NULL, '2019-01-20 09:58:24', '2019-01-20 09:58:24'),
(164, 'ppr-20190129-100302', 9, 36, NULL, 1, 650, 350, 'Cash', NULL, '2019-01-29 04:03:02', '2019-01-29 04:03:02'),
(165, 'ppr-20190129-100324', 9, 34, NULL, 1, 2860, 140, 'Cash', NULL, '2019-01-29 04:03:24', '2019-01-29 04:03:24'),
(166, 'spr-20190129-101451', 9, NULL, 109, 1, 540, 460, 'Cash', NULL, '2019-01-29 04:14:51', '2019-01-29 04:14:51'),
(167, 'spr-20190129-115048', 9, NULL, 110, 1, 1700, 300, 'Cash', NULL, '2019-01-29 05:50:48', '2019-01-29 05:50:48'),
(168, 'spr-20190131-110839', 9, NULL, 111, 1, 271, 0, 'Cash', NULL, '2019-01-31 05:08:39', '2019-01-31 05:08:39'),
(169, 'spr-20190202-104045', 1, NULL, 112, 1, 440, 0, 'Cash', NULL, '2019-02-02 04:40:45', '2019-02-02 04:40:45'),
(170, 'spr-20190202-114117', 1, NULL, 113, 1, 350, 0, 'Cash', NULL, '2019-02-02 05:41:17', '2019-02-02 05:41:17'),
(171, 'spr-20190205-030454', 1, NULL, 114, 1, 440, 0, 'Cash', NULL, '2019-02-05 09:04:54', '2019-02-05 09:04:54'),
(176, 'ppr-20190207-125418', 1, 35, NULL, 1, 50, 50, 'Cash', NULL, '2019-02-07 06:54:18', '2019-02-07 07:05:23'),
(178, 'ppr-20190207-010640', 1, 35, NULL, 1, 50, 50, 'Cheque', NULL, '2019-02-07 07:06:40', '2019-02-07 07:07:04'),
(179, 'spr-20190207-010915', 1, NULL, 120, 1, 50, 50, 'Cash', NULL, '2019-02-07 07:09:15', '2019-02-07 07:09:15'),
(180, 'spr-20190209-104816', 1, NULL, 121, 1, 1272, 728, 'Cash', NULL, '2019-02-09 04:48:16', '2019-02-09 04:48:16'),
(181, 'ppr-20190209-104940', 1, 38, NULL, 1, 1660, 0, 'Cash', NULL, '2019-02-09 04:49:40', '2019-02-09 04:49:40'),
(182, 'ppr-20190209-104959', 1, 39, NULL, 1, 973.5, 0, 'Cash', NULL, '2019-02-09 04:49:59', '2019-02-09 04:49:59'),
(183, 'spr-20190219-023214', 1, NULL, 123, 1, 440, 0, 'Cash', NULL, '2019-02-19 08:32:14', '2019-02-19 08:32:14'),
(189, 'spr-20190303-104010', 1, NULL, 127, 1, 2500, 0, 'Cash', NULL, '2019-03-03 04:40:10', '2019-03-03 04:40:10'),
(190, 'ppr-20190303-104046', 1, 40, NULL, 1, 100, 0, 'Cash', NULL, '2019-03-03 04:40:46', '2019-03-03 04:40:46'),
(191, 'ppr-20190303-104222', 1, 37, NULL, 1, 4000, 0, 'Cash', NULL, '2019-03-03 04:42:22', '2019-03-03 04:42:22'),
(192, 'ppr-20190303-104414', 1, 41, NULL, 1, 1000, 0, 'Cash', NULL, '2019-03-03 04:44:14', '2019-03-03 04:44:14'),
(193, 'spr-20190404-095555', 1, NULL, 128, 1, 560, 0, 'Cash', NULL, '2019-04-04 03:55:55', '2019-04-04 03:55:55'),
(194, 'ppr-20190404-095910', 1, 42, NULL, 1, 300, 200, 'Cash', NULL, '2019-04-04 03:59:10', '2019-04-13 10:52:38'),
(195, 'spr-20190404-095937', 1, NULL, 129, 1, 120, 0, 'Cash', NULL, '2019-04-04 03:59:37', '2019-04-04 03:59:37'),
(196, 'spr-20190421-122124', 1, NULL, 130, 1, 586, 0, 'Cash', NULL, '2019-04-21 06:21:24', '2019-04-21 06:21:24'),
(197, 'spr-20190528-103229', 1, NULL, 131, 1, 2890, 0, 'Cash', NULL, '2019-05-28 04:32:29', '2019-05-28 04:32:29'),
(198, 'ppr-20190613-101351', 1, 37, NULL, 1, 2390, 0, 'Cash', NULL, '2019-06-13 04:13:51', '2019-06-13 04:13:51'),
(199, 'spr-20190613-101637', 1, NULL, 132, 1, 840, 0, 'Cash', NULL, '2019-06-13 04:16:37', '2019-06-13 04:16:37'),
(200, 'ppr-20190613-101713', 1, 43, NULL, 1, 1000, 0, 'Cash', NULL, '2019-06-13 04:17:13', '2019-06-13 04:17:13'),
(201, 'spr-20190613-101752', 1, NULL, 133, 1, 2700, 0, 'Cash', NULL, '2019-06-13 04:17:52', '2019-06-13 04:17:52'),
(202, 'ppr-20191019-032925', 1, 43, NULL, 1, 3290, 710, 'Cash', NULL, '2019-10-19 09:29:25', '2019-10-19 09:29:25'),
(203, 'spr-20191019-033028', 1, NULL, 134, 1, 2940, 60, 'Cash', NULL, '2019-10-19 09:30:28', '2019-10-19 09:30:28'),
(205, 'spr-20191103-114044', 1, NULL, 139, 1, 488, 12, 'Cash', NULL, '2019-11-03 05:40:44', '2019-11-03 05:40:44'),
(206, 'ppr-20191103-114222', 1, 46, NULL, 1, 200, 0, 'Cash', NULL, '2019-11-03 05:42:22', '2019-11-03 05:42:22'),
(211, 'spr-20191109-074131', 1, NULL, 144, 1, 1220, 0, 'Cash', NULL, '2019-11-09 13:41:31', '2019-11-09 13:41:31'),
(217, 'spr-20191111-104008', 1, NULL, 147, 1, 2220, 780, 'Cash', NULL, '2019-11-11 04:40:08', '2019-11-11 04:40:08'),
(222, 'spr-20191203-115128', 1, NULL, 163, 1, 3, 0, 'Cash', NULL, '2019-12-03 05:51:28', '2019-12-03 05:51:28'),
(227, 'ppr-20191204-111124', 1, 57, NULL, 1, 220, 280, 'Cash', NULL, '2019-12-04 17:11:24', '2019-12-04 17:11:24'),
(228, 'spr-20191205-092712', 1, NULL, 173, 1, 621, 0, 'Cash', NULL, '2019-12-05 03:27:12', '2019-12-05 03:27:12'),
(239, 'spr-20191222-104058', 1, NULL, 187, 1, 288, 212, 'Cash', NULL, '2019-12-22 04:40:58', '2019-12-22 04:40:58'),
(241, 'spr-20191223-125946', 1, NULL, 190, 1, 1100, 400, 'Cash', NULL, '2019-12-23 06:59:46', '2019-12-23 06:59:46'),
(244, 'ppr-20200101-010750', 1, 61, NULL, 1, 60, 0, 'Cash', NULL, '2020-01-01 07:07:50', '2020-01-01 07:07:50'),
(246, 'spr-20200101-022028', 1, NULL, 193, 1, 1100, 400, 'Cash', NULL, '2020-01-01 08:20:28', '2020-01-01 08:20:28'),
(247, 'ppr-20200101-022131', 1, 59, NULL, 1, 6, 0, 'Cash', NULL, '2020-01-01 08:21:31', '2020-01-01 08:21:31'),
(248, 'ppr-20200101-022137', 1, 58, NULL, 1, 4, 0, 'Cash', NULL, '2020-01-01 08:21:37', '2020-01-01 08:21:37'),
(249, 'ppr-20200101-022144', 1, 56, NULL, 1, 2, 0, 'Cash', NULL, '2020-01-01 08:21:44', '2020-01-01 08:21:44'),
(252, 'spr-20200102-043947', 1, NULL, 194, 1, 892, 108, 'Cash', NULL, '2020-01-02 10:39:47', '2020-01-02 10:39:47'),
(258, 'spr-20200203-035256', 1, NULL, 201, 1, 120, 880, 'Cash', NULL, '2020-02-03 09:52:56', '2020-02-03 09:52:56'),
(259, 'spr-20200204-105853', 1, NULL, 202, 1, 1400, 100, 'Cash', NULL, '2020-02-04 16:58:53', '2020-02-04 16:58:53'),
(260, 'ppr-20200204-110050', 1, 67, NULL, 1, 300, 0, 'Cash', NULL, '2020-02-04 17:00:50', '2020-02-04 17:00:50'),
(261, 'spr-20200302-115414', 1, NULL, 203, 1, 350, 150, 'Cash', NULL, '2020-03-02 05:54:14', '2020-03-02 05:54:14'),
(262, 'spr-20200302-115741', 1, NULL, 204, 1, 40, 10, 'Cash', NULL, '2020-03-02 05:57:41', '2020-03-02 05:57:41'),
(263, 'ppr-20200302-115811', 1, 70, NULL, 1, 50, 0, 'Cash', NULL, '2020-03-02 05:58:11', '2020-03-02 05:58:11'),
(264, 'ppr-20200302-115820', 1, 69, NULL, 1, 50, 0, 'Cash', NULL, '2020-03-02 05:58:20', '2020-03-02 05:58:20'),
(265, 'spr-20200311-044642', 1, NULL, 205, 1, 352, 148, 'Cash', NULL, '2020-03-11 10:46:42', '2020-03-11 10:46:42'),
(267, 'spr-20200406-074024', 1, NULL, 207, 1, 500, 500, 'Cash', NULL, '2020-04-06 13:40:24', '2020-04-06 13:40:24'),
(268, 'spr-20200406-074201', 1, NULL, 207, 1, 144, 56, 'Cash', NULL, '2020-04-06 13:42:01', '2020-04-06 13:42:01'),
(269, 'ppr-20201206-062315', 18, 12, NULL, 1, 5000, 5200, 'Cash', 'recieving partly payment', '2020-12-06 12:53:15', '2020-12-06 12:53:15');

-- --------------------------------------------------------

--
-- Table structure for table `payment_with_cheque`
--

CREATE TABLE `payment_with_cheque` (
  `id` int(10) UNSIGNED NOT NULL,
  `payment_id` int(11) NOT NULL,
  `cheque_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_with_cheque`
--

INSERT INTO `payment_with_cheque` (`id`, `payment_id`, `cheque_no`, `created_at`, `updated_at`) VALUES
(1, 19, '23425235235', '2018-07-01 03:09:48', '2018-07-01 03:09:48'),
(2, 24, '3123123123', '2018-07-10 01:21:32', '2018-07-10 01:21:32'),
(3, 31, '767867678', '2018-08-08 10:36:22', '2018-08-08 10:36:22'),
(4, 34, '3123412', '2018-08-08 23:55:54', '2018-08-08 23:55:54'),
(5, 35, '7765', '2018-08-09 00:32:14', '2018-08-09 00:32:14'),
(6, 44, '3124142412', '2018-08-30 03:07:18', '2018-08-30 03:07:18'),
(7, 51, '6576764646', '2018-09-03 04:08:21', '2018-09-03 04:08:21'),
(8, 53, '111111111', '2018-09-03 04:15:24', '2018-09-03 04:15:24'),
(9, 79, '1111', '2018-10-06 00:51:55', '2018-10-06 00:51:55'),
(10, 147, '221133', '2018-12-04 00:58:35', '2018-12-04 00:58:35'),
(11, 175, '1111', '2019-02-07 06:38:23', '2019-02-07 06:38:23'),
(12, 176, '1111', '2019-02-07 06:54:59', '2019-02-07 06:54:59'),
(13, 178, '420', '2019-02-07 07:07:04', '2019-02-07 07:07:04');

-- --------------------------------------------------------

--
-- Table structure for table `payment_with_credit_card`
--

CREATE TABLE `payment_with_credit_card` (
  `id` int(10) UNSIGNED NOT NULL,
  `payment_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `customer_stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_with_gift_card`
--

CREATE TABLE `payment_with_gift_card` (
  `id` int(10) UNSIGNED NOT NULL,
  `payment_id` int(11) NOT NULL,
  `gift_card_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_with_gift_card`
--

INSERT INTO `payment_with_gift_card` (`id`, `payment_id`, `gift_card_id`, `created_at`, `updated_at`) VALUES
(1, 36, 2, '2018-08-24 21:48:36', '2018-08-25 00:57:35'),
(4, 39, 1, '2018-08-25 02:36:34', '2018-08-25 02:36:34'),
(6, 50, 1, '2018-09-02 23:01:38', '2018-09-02 23:01:38');

-- --------------------------------------------------------

--
-- Table structure for table `payment_with_paypal`
--

CREATE TABLE `payment_with_paypal` (
  `id` int(10) UNSIGNED NOT NULL,
  `payment_id` int(11) NOT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payrolls`
--

CREATE TABLE `payrolls` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `paying_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payrolls`
--

INSERT INTO `payrolls` (`id`, `reference_no`, `employee_id`, `account_id`, `user_id`, `amount`, `paying_method`, `note`, `created_at`, `updated_at`) VALUES
(8, 'payroll-20190101-055231', 1, 1, 1, 100, '0', NULL, '2018-12-31 23:52:31', '2018-12-31 23:52:31'),
(9, 'payroll-20191204-113802', 1, 1, 1, 10000, '0', NULL, '2019-12-04 17:38:02', '2019-12-04 17:38:02'),
(10, 'payroll-20201130-114505', 1, 1, 1, 10000, '0', NULL, '2020-11-30 18:15:05', '2020-11-30 18:15:05');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(4, 'products-edit', 'web', '2018-06-03 01:00:09', '2018-06-03 01:00:09'),
(5, 'products-delete', 'web', '2018-06-03 22:54:22', '2018-06-03 22:54:22'),
(6, 'products-add', 'web', '2018-06-04 00:34:14', '2018-06-04 00:34:14'),
(7, 'products-index', 'web', '2018-06-04 03:34:27', '2018-06-04 03:34:27'),
(8, 'purchases-index', 'web', '2018-06-04 08:03:19', '2018-06-04 08:03:19'),
(9, 'purchases-add', 'web', '2018-06-04 08:12:25', '2018-06-04 08:12:25'),
(10, 'purchases-edit', 'web', '2018-06-04 09:47:36', '2018-06-04 09:47:36'),
(11, 'purchases-delete', 'web', '2018-06-04 09:47:36', '2018-06-04 09:47:36'),
(12, 'sales-index', 'web', '2018-06-04 10:49:08', '2018-06-04 10:49:08'),
(13, 'sales-add', 'web', '2018-06-04 10:49:52', '2018-06-04 10:49:52'),
(14, 'sales-edit', 'web', '2018-06-04 10:49:52', '2018-06-04 10:49:52'),
(15, 'sales-delete', 'web', '2018-06-04 10:49:53', '2018-06-04 10:49:53'),
(16, 'quotes-index', 'web', '2018-06-04 22:05:10', '2018-06-04 22:05:10'),
(17, 'quotes-add', 'web', '2018-06-04 22:05:10', '2018-06-04 22:05:10'),
(18, 'quotes-edit', 'web', '2018-06-04 22:05:10', '2018-06-04 22:05:10'),
(19, 'quotes-delete', 'web', '2018-06-04 22:05:10', '2018-06-04 22:05:10'),
(20, 'transfers-index', 'web', '2018-06-04 22:30:03', '2018-06-04 22:30:03'),
(21, 'transfers-add', 'web', '2018-06-04 22:30:03', '2018-06-04 22:30:03'),
(22, 'transfers-edit', 'web', '2018-06-04 22:30:03', '2018-06-04 22:30:03'),
(23, 'transfers-delete', 'web', '2018-06-04 22:30:03', '2018-06-04 22:30:03'),
(24, 'returns-index', 'web', '2018-06-04 22:50:24', '2018-06-04 22:50:24'),
(25, 'returns-add', 'web', '2018-06-04 22:50:24', '2018-06-04 22:50:24'),
(26, 'returns-edit', 'web', '2018-06-04 22:50:25', '2018-06-04 22:50:25'),
(27, 'returns-delete', 'web', '2018-06-04 22:50:25', '2018-06-04 22:50:25'),
(28, 'customers-index', 'web', '2018-06-04 23:15:54', '2018-06-04 23:15:54'),
(29, 'customers-add', 'web', '2018-06-04 23:15:55', '2018-06-04 23:15:55'),
(30, 'customers-edit', 'web', '2018-06-04 23:15:55', '2018-06-04 23:15:55'),
(31, 'customers-delete', 'web', '2018-06-04 23:15:55', '2018-06-04 23:15:55'),
(32, 'suppliers-index', 'web', '2018-06-04 23:40:12', '2018-06-04 23:40:12'),
(33, 'suppliers-add', 'web', '2018-06-04 23:40:12', '2018-06-04 23:40:12'),
(34, 'suppliers-edit', 'web', '2018-06-04 23:40:12', '2018-06-04 23:40:12'),
(35, 'suppliers-delete', 'web', '2018-06-04 23:40:12', '2018-06-04 23:40:12'),
(36, 'product-report', 'web', '2018-06-24 23:05:33', '2018-06-24 23:05:33'),
(37, 'purchase-report', 'web', '2018-06-24 23:24:56', '2018-06-24 23:24:56'),
(38, 'sale-report', 'web', '2018-06-24 23:33:13', '2018-06-24 23:33:13'),
(39, 'customer-report', 'web', '2018-06-24 23:36:51', '2018-06-24 23:36:51'),
(40, 'due-report', 'web', '2018-06-24 23:39:52', '2018-06-24 23:39:52'),
(41, 'users-index', 'web', '2018-06-25 00:00:10', '2018-06-25 00:00:10'),
(42, 'users-add', 'web', '2018-06-25 00:00:10', '2018-06-25 00:00:10'),
(43, 'users-edit', 'web', '2018-06-25 00:01:30', '2018-06-25 00:01:30'),
(44, 'users-delete', 'web', '2018-06-25 00:01:30', '2018-06-25 00:01:30'),
(45, 'profit-loss', 'web', '2018-07-14 21:50:05', '2018-07-14 21:50:05'),
(46, 'best-seller', 'web', '2018-07-14 22:01:38', '2018-07-14 22:01:38'),
(47, 'daily-sale', 'web', '2018-07-14 22:24:21', '2018-07-14 22:24:21'),
(48, 'monthly-sale', 'web', '2018-07-14 22:30:41', '2018-07-14 22:30:41'),
(49, 'daily-purchase', 'web', '2018-07-14 22:36:46', '2018-07-14 22:36:46'),
(50, 'monthly-purchase', 'web', '2018-07-14 22:48:17', '2018-07-14 22:48:17'),
(51, 'payment-report', 'web', '2018-07-14 23:10:41', '2018-07-14 23:10:41'),
(52, 'warehouse-stock-report', 'web', '2018-07-14 23:16:55', '2018-07-14 23:16:55'),
(53, 'product-qty-alert', 'web', '2018-07-14 23:33:21', '2018-07-14 23:33:21'),
(54, 'supplier-report', 'web', '2018-07-30 03:00:01', '2018-07-30 03:00:01'),
(55, 'expenses-index', 'web', '2018-09-05 01:07:10', '2018-09-05 01:07:10'),
(56, 'expenses-add', 'web', '2018-09-05 01:07:10', '2018-09-05 01:07:10'),
(57, 'expenses-edit', 'web', '2018-09-05 01:07:10', '2018-09-05 01:07:10'),
(58, 'expenses-delete', 'web', '2018-09-05 01:07:11', '2018-09-05 01:07:11'),
(59, 'general_setting', 'web', '2018-10-19 23:10:04', '2018-10-19 23:10:04'),
(60, 'mail_setting', 'web', '2018-10-19 23:10:04', '2018-10-19 23:10:04'),
(61, 'pos_setting', 'web', '2018-10-19 23:10:04', '2018-10-19 23:10:04'),
(62, 'hrm_setting', 'web', '2019-01-02 10:30:23', '2019-01-02 10:30:23'),
(63, 'purchase-return-index', 'web', '2019-01-02 21:45:14', '2019-01-02 21:45:14'),
(64, 'purchase-return-add', 'web', '2019-01-02 21:45:14', '2019-01-02 21:45:14'),
(65, 'purchase-return-edit', 'web', '2019-01-02 21:45:14', '2019-01-02 21:45:14'),
(66, 'purchase-return-delete', 'web', '2019-01-02 21:45:14', '2019-01-02 21:45:14'),
(67, 'account-index', 'web', '2019-01-02 22:06:13', '2019-01-02 22:06:13'),
(68, 'balance-sheet', 'web', '2019-01-02 22:06:14', '2019-01-02 22:06:14'),
(69, 'account-statement', 'web', '2019-01-02 22:06:14', '2019-01-02 22:06:14'),
(70, 'department', 'web', '2019-01-02 22:30:01', '2019-01-02 22:30:01'),
(71, 'attendance', 'web', '2019-01-02 22:30:01', '2019-01-02 22:30:01'),
(72, 'payroll', 'web', '2019-01-02 22:30:01', '2019-01-02 22:30:01'),
(73, 'employees-index', 'web', '2019-01-02 22:52:19', '2019-01-02 22:52:19'),
(74, 'employees-add', 'web', '2019-01-02 22:52:19', '2019-01-02 22:52:19'),
(75, 'employees-edit', 'web', '2019-01-02 22:52:19', '2019-01-02 22:52:19'),
(76, 'employees-delete', 'web', '2019-01-02 22:52:19', '2019-01-02 22:52:19'),
(77, 'user-report', 'web', '2019-01-16 06:48:18', '2019-01-16 06:48:18'),
(78, 'stock_count', 'web', '2019-02-17 10:32:01', '2019-02-17 10:32:01'),
(79, 'adjustment', 'web', '2019-02-17 10:32:02', '2019-02-17 10:32:02'),
(80, 'sms_setting', 'web', '2019-02-22 05:18:03', '2019-02-22 05:18:03'),
(81, 'create_sms', 'web', '2019-02-22 05:18:03', '2019-02-22 05:18:03'),
(82, 'print_barcode', 'web', '2019-03-07 05:02:19', '2019-03-07 05:02:19'),
(83, 'empty_database', 'web', '2019-03-07 05:02:19', '2019-03-07 05:02:19'),
(84, 'customer_group', 'web', '2019-03-07 05:37:15', '2019-03-07 05:37:15'),
(85, 'unit', 'web', '2019-03-07 05:37:15', '2019-03-07 05:37:15'),
(86, 'tax', 'web', '2019-03-07 05:37:15', '2019-03-07 05:37:15'),
(87, 'gift_card', 'web', '2019-03-07 06:29:38', '2019-03-07 06:29:38'),
(88, 'coupon', 'web', '2019-03-07 06:29:38', '2019-03-07 06:29:38'),
(89, 'holiday', 'web', '2019-10-19 08:57:15', '2019-10-19 08:57:15'),
(90, 'warehouse-report', 'web', '2019-10-22 06:00:23', '2019-10-22 06:00:23'),
(91, 'warehouse', 'web', '2020-02-26 06:47:32', '2020-02-26 06:47:32'),
(92, 'brand', 'web', '2020-02-26 06:59:59', '2020-02-26 06:59:59'),
(93, 'billers-index', 'web', '2020-02-26 07:11:15', '2020-02-26 07:11:15'),
(94, 'billers-add', 'web', '2020-02-26 07:11:15', '2020-02-26 07:11:15'),
(95, 'billers-edit', 'web', '2020-02-26 07:11:15', '2020-02-26 07:11:15'),
(96, 'billers-delete', 'web', '2020-02-26 07:11:15', '2020-02-26 07:11:15'),
(97, 'money-transfer', 'web', '2020-03-02 05:41:48', '2020-03-02 05:41:48');

-- --------------------------------------------------------

--
-- Table structure for table `pos_setting`
--

CREATE TABLE `pos_setting` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) NOT NULL,
  `product_number` int(11) NOT NULL,
  `keybord_active` tinyint(1) NOT NULL,
  `stripe_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pos_setting`
--

INSERT INTO `pos_setting` (`id`, `customer_id`, `warehouse_id`, `biller_id`, `product_number`, `keybord_active`, `stripe_public_key`, `stripe_secret_key`, `created_at`, `updated_at`) VALUES
(1, 11, 2, 1, 4, 1, 'pk_test_ITN7KOYiIsHSCQ0UMRcgaYUB', 'sk_test_TtQQaawhEYRwa3mU9CzttrEy', '2018-09-02 03:17:04', '2020-04-04 16:40:33');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` double DEFAULT NULL,
  `image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `code`, `category_id`, `unit_id`, `price`, `qty`, `image`, `product_details`, `is_active`, `created_at`, `updated_at`) VALUES
(60, 'Cap', '61354774', 1, 1, '200', 0, 'zummXD2dvAtI.png', '', 1, '2021-03-11 16:59:46', '2021-03-11 16:59:46'),
(61, 'Belt', '81436263', 2, 1, '250', 0, 'zummXD2dvAtI.png', 'Testing product', 1, '2021-03-11 17:09:22', '2021-04-04 08:39:43'),
(63, 'Testing', '123123', 1, 1, '200', NULL, NULL, 'asdasd', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_adjustments`
--

CREATE TABLE `product_adjustments` (
  `id` int(10) UNSIGNED NOT NULL,
  `adjustment_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` double NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_purchases`
--

CREATE TABLE `product_purchases` (
  `id` int(10) UNSIGNED NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `recieved` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_purchases`
--

INSERT INTO `product_purchases` (`id`, `purchase_id`, `product_id`, `variant_id`, `qty`, `recieved`, `purchase_unit_id`, `net_unit_cost`, `discount`, `tax_rate`, `tax`, `total`, `created_at`, `updated_at`) VALUES
(59, 12, 4, NULL, 200, 200, 1, 1, 0, 0, 0, 200, '2018-08-08 23:48:36', '2018-08-08 23:48:36'),
(60, 12, 5, NULL, 100, 100, 1, 100, 0, 0, 0, 10000, '2018-08-08 23:48:36', '2018-08-08 23:48:36'),
(66, 13, 2, NULL, 100, 100, 3, 166.96, 0, 15, 2504.35, 19200, '2018-08-08 23:49:55', '2018-08-08 23:49:55'),
(67, 13, 3, NULL, 100, 100, 1, 200, 0, 0, 0, 20000, '2018-08-08 23:49:55', '2018-08-08 23:49:55'),
(68, 13, 1, NULL, 150, 150, 1, 320, 0, 10, 4800, 52800, '2018-08-08 23:49:55', '2018-08-08 23:49:55'),
(69, 13, 10, NULL, 60, 60, 7, 10, 0, 0, 0, 600, '2018-08-08 23:49:55', '2018-08-08 23:49:55'),
(70, 14, 1, NULL, 100, 100, 1, 320, 0, 10, 3200, 35200, '2018-08-09 07:23:48', '2018-08-09 07:23:48'),
(71, 14, 2, NULL, 50, 50, 3, 166.96, 0, 15, 1252.17, 9600, '2018-08-09 07:23:48', '2018-08-09 07:23:48'),
(72, 14, 3, NULL, 100, 100, 1, 200, 0, 0, 0, 20000, '2018-08-09 07:23:49', '2018-08-09 07:23:49'),
(73, 14, 5, NULL, 100, 100, 1, 100, 0, 0, 0, 10000, '2018-08-09 07:23:49', '2018-08-09 07:23:49'),
(74, 14, 10, NULL, 50, 50, 7, 10, 0, 0, 0, 500, '2018-08-09 07:23:49', '2018-08-09 07:23:49'),
(76, 15, 22, NULL, 20, 20, 1, 800, 0, 10, 1600, 17600, '2018-09-03 04:06:46', '2018-09-03 04:06:46'),
(87, 16, 22, NULL, 20, 20, 1, 800, 0, 10, 1600, 17600, '2018-09-20 09:09:12', '2018-09-20 09:09:12'),
(89, 18, 4, NULL, 50, 50, 1, 1, 0, 0, 0, 50, '2018-10-22 10:26:25', '2018-10-22 10:26:25'),
(90, 19, 4, NULL, 50, 50, 1, 1, 0, 0, 0, 50, '2018-10-22 10:26:52', '2018-10-22 10:26:52'),
(91, 20, 25, NULL, 15, 15, 1, 500, 0, 10, 750, 8250, '2018-10-23 01:14:21', '2018-10-23 01:14:21'),
(93, 21, 25, NULL, 15, 15, 1, 500, 0, 10, 750, 8250, '2018-10-23 01:14:58', '2018-10-23 01:14:58'),
(94, 22, 22, NULL, 5, 5, 1, 800, 0, 10, 400, 4400, '2018-10-31 22:59:03', '2018-10-31 22:59:03'),
(96, 23, 22, NULL, 5, 5, 1, 800, 0, 10, 400, 4400, '2018-11-03 03:23:52', '2018-11-03 03:23:52'),
(97, 24, 22, NULL, 15, 15, 1, 800, 0, 10, 1200, 13200, '2018-11-05 03:18:19', '2018-11-05 03:18:19'),
(98, 24, 25, NULL, 5, 5, 1, 500, 0, 10, 250, 2750, '2018-11-05 03:18:19', '2018-11-05 03:18:19'),
(99, 25, 31, NULL, 15, 15, 1, 250, 0, 0, 0, 3750, '2018-12-04 23:34:30', '2018-12-04 23:34:30'),
(100, 25, 30, NULL, 15, 15, 1, 50, 0, 0, 0, 750, '2018-12-04 23:34:30', '2018-12-04 23:34:30'),
(101, 26, 31, NULL, 15, 15, 1, 250, 0, 0, 0, 3750, '2018-12-04 23:35:08', '2018-12-04 23:35:08'),
(102, 26, 30, NULL, 15, 15, 1, 50, 0, 0, 0, 750, '2018-12-04 23:35:08', '2018-12-04 23:35:08'),
(104, 27, 32, NULL, 10, 10, 1, 1, 0, 0, 0, 10, '2018-12-18 23:57:41', '2018-12-18 23:57:41'),
(112, 33, 33, NULL, 10, 10, 1, 1, 0, 0, 0, 10, '2018-12-24 03:04:21', '2018-12-24 03:04:21'),
(113, 34, 25, NULL, 2, 2, 1, 500, 0, 10, 100, 1100, '2019-01-03 01:01:24', '2019-01-03 01:01:24'),
(114, 34, 22, NULL, 2, 2, 1, 800, 0, 10, 160, 1760, '2019-01-03 01:01:24', '2019-01-03 01:01:24'),
(115, 35, 31, NULL, 2, 2, 1, 250, 0, 0, 0, 500, '2019-01-29 03:54:48', '2019-01-29 03:54:48'),
(116, 35, 30, NULL, 2, 2, 1, 50, 0, 0, 0, 100, '2019-01-29 03:54:48', '2019-01-29 03:54:48'),
(117, 36, 30, NULL, 3, 3, 1, 50, 0, 0, 0, 150, '2019-01-29 03:55:58', '2019-01-29 03:55:58'),
(118, 36, 31, NULL, 2, 2, 1, 250, 0, 0, 0, 500, '2019-01-29 03:55:58', '2019-01-29 03:55:58'),
(121, 39, 1, NULL, 2, 2, 1, 315, 10, 10, 63, 693, '2019-02-09 04:44:13', '2019-02-09 04:44:13'),
(122, 39, 2, NULL, 1, 1, 3, 192, 0, 0, 0, 192, '2019-02-09 04:44:13', '2019-02-09 04:44:13'),
(123, 38, 32, NULL, 10, 10, 1, 1, 0, 0, 0, 10, '2019-02-09 04:45:24', '2019-02-09 04:45:24'),
(124, 38, 25, NULL, 3, 3, 1, 500, 0, 10, 150, 1650, '2019-02-09 04:45:24', '2019-02-09 04:45:24'),
(125, 37, 33, NULL, 10, 10, 1, 1, 0, 0, 0, 10, '2019-02-09 04:46:22', '2019-02-09 04:46:22'),
(126, 37, 25, NULL, 2, 2, 1, 500, 0, 10, 100, 1100, '2019-02-09 04:46:23', '2019-02-09 04:46:23'),
(127, 37, 22, NULL, 6, 6, 1, 800, 0, 10, 480, 5280, '2019-02-09 04:46:23', '2019-02-09 04:46:23'),
(128, 40, 33, NULL, 10, 10, 1, 10, 0, 0, 0, 100, '2019-03-03 04:39:17', '2019-03-03 04:39:17'),
(129, 41, 33, NULL, 5, 5, 1, 10, 0, 0, 0, 50, '2019-03-03 04:43:58', '2019-03-03 04:43:58'),
(130, 41, 1, NULL, 10, 10, 1, 320, 0, 10, 320, 3520, '2019-03-03 04:43:59', '2019-03-03 04:43:59'),
(133, 42, 30, NULL, 1, 1, 1, 50, 0, 0, 0, 50, '2019-04-13 13:50:08', '2019-04-13 13:50:08'),
(134, 42, 31, NULL, 1, 1, 1, 250, 0, 0, 0, 250, '2019-04-13 13:50:08', '2019-04-13 13:50:08'),
(135, 43, 25, NULL, 3, 3, 1, 500, 0, 10, 150, 1650, '2019-06-13 04:16:00', '2019-06-13 04:16:00'),
(136, 43, 22, NULL, 3, 3, 1, 800, 0, 10, 240, 2640, '2019-06-13 04:16:01', '2019-06-13 04:16:01'),
(137, 44, 25, NULL, 1, 1, 1, 500, 0, 10, 50, 550, '2019-10-19 09:31:19', '2019-10-19 09:31:19'),
(138, 44, 22, NULL, 1, 1, 1, 800, 0, 10, 80, 880, '2019-10-19 09:31:20', '2019-10-19 09:31:20'),
(140, 46, 33, NULL, 10, 10, 1, 10, 0, 0, 0, 100, '2019-11-03 05:39:49', '2019-11-03 05:39:49'),
(141, 46, 32, NULL, 10, 10, 1, 5, 0, 0, 0, 50, '2019-11-03 05:39:49', '2019-11-03 05:39:49'),
(142, 47, 1, NULL, 2, 2, 1, 315, 10, 10, 63, 693, '2019-11-09 05:25:10', '2019-11-09 05:25:10'),
(143, 47, 2, NULL, 1, 1, 3, 192, 0, 0, 0, 192, '2019-11-09 05:25:10', '2019-11-09 05:25:10'),
(161, 57, 3, NULL, 1, 1, 1, 200, 0, 0, 0, 200, '2019-12-04 17:07:49', '2019-12-04 17:07:49'),
(162, 58, 48, 2, 1, 1, 1, 2, 0, 0, 0, 2, '2019-12-05 04:21:10', '2019-12-05 04:21:10'),
(163, 58, 48, 3, 1, 1, 1, 2, 0, 0, 0, 2, '2019-12-05 04:21:10', '2019-12-05 04:21:10'),
(169, 59, 48, 3, 1, 1, 1, 2, 0, 0, 0, 2, '2019-12-21 10:22:29', '2019-12-21 10:22:29'),
(170, 59, 48, 2, 1, 1, 1, 2, 0, 0, 0, 2, '2019-12-21 10:22:29', '2019-12-21 10:22:29'),
(171, 59, 48, 5, 1, 1, 1, 2, 0, 0, 0, 2, '2019-12-21 10:22:29', '2019-12-21 10:22:29'),
(174, 56, 48, 2, 1, 1, 1, 2, 0, 0, 0, 2, '2019-12-21 13:27:16', '2019-12-21 13:27:16'),
(178, 61, 48, 3, 10, 10, 1, 2, 0, 0, 0, 20, '2020-01-01 07:06:31', '2020-01-01 07:06:31'),
(179, 61, 48, 2, 10, 10, 1, 2, 0, 0, 0, 20, '2020-01-01 07:06:31', '2020-01-01 07:06:31'),
(180, 61, 48, 5, 10, 10, 1, 2, 0, 0, 0, 20, '2020-01-01 07:06:31', '2020-01-01 07:06:31'),
(181, 62, 25, NULL, 3, 3, 1, 500, 0, 10, 150, 1650, '2020-01-01 08:24:02', '2020-01-01 08:24:02'),
(209, 67, 31, NULL, 1, 1, 1, 250, 0, 0, 0, 250, '2020-02-04 17:00:41', '2020-02-04 17:00:41'),
(210, 67, 30, NULL, 1, 1, 1, 50, 0, 0, 0, 50, '2020-02-04 17:00:41', '2020-02-04 17:00:41'),
(212, 69, 4, NULL, 50, 50, 1, 1, 0, 0, 0, 50, '2020-03-02 05:55:10', '2020-03-02 05:55:10'),
(213, 70, 4, NULL, 50, 50, 1, 1, 0, 0, 0, 50, '2020-03-02 05:56:03', '2020-03-02 05:56:03');

-- --------------------------------------------------------

--
-- Table structure for table `product_quotation`
--

CREATE TABLE `product_quotation` (
  `id` int(10) UNSIGNED NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_quotation`
--

INSERT INTO `product_quotation` (`id`, `quotation_id`, `product_id`, `variant_id`, `qty`, `sale_unit_id`, `net_unit_price`, `discount`, `tax_rate`, `tax`, `total`, `created_at`, `updated_at`) VALUES
(2, 1, 1, NULL, 1, 2, 5030, 10, 15, 754.5, 5784.5, '2018-08-08 23:52:50', '2018-08-28 00:09:57'),
(3, 1, 4, NULL, 50, 1, 1.5, 25, 10, 7.5, 82.5, '2018-08-08 23:53:25', '2018-08-28 00:34:36'),
(4, 1, 2, NULL, 6, 1, 9.55, 0, 10, 5.73, 63, '2018-08-28 01:03:48', '2018-08-28 01:07:07'),
(5, 2, 10, NULL, 2.5, 7, 22, 0, 0, 0, 55, '2018-09-03 22:02:58', '2018-09-20 10:37:41'),
(6, 2, 13, NULL, 1, 0, 21, 0, 0, 0, 21, '2018-09-03 22:02:58', '2018-09-03 22:02:58'),
(7, 3, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-23 00:12:49', '2019-12-21 06:41:37'),
(19, 3, 48, 2, 1, 1, 13, 0, 0, 0, 13, '2019-12-07 08:50:02', '2019-12-21 06:41:37');

-- --------------------------------------------------------

--
-- Table structure for table `product_returns`
--

CREATE TABLE `product_returns` (
  `id` int(10) UNSIGNED NOT NULL,
  `return_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_returns`
--

INSERT INTO `product_returns` (`id`, `return_id`, `product_id`, `variant_id`, `qty`, `sale_unit_id`, `net_unit_price`, `discount`, `tax_rate`, `tax`, `total`, `created_at`, `updated_at`) VALUES
(3, 2, 4, NULL, 20, 1, 2, 0, 0, 0, 40, NULL, NULL),
(4, 3, 10, NULL, 2, 7, 22, 0, 0, 0, 44, NULL, '2018-10-07 02:19:40'),
(6, 5, 3, NULL, 1, 1, 250, 0, 0, 0, 250, NULL, '2018-12-25 22:16:08'),
(12, 6, 1, NULL, 1, 1, 400, 0, 10, 40, 440, NULL, NULL),
(23, 11, 13, NULL, 1, 0, 21, 0, 0, 0, 21, '2019-12-24 05:20:29', '2019-12-24 05:20:29');

-- --------------------------------------------------------

--
-- Table structure for table `product_sales`
--

CREATE TABLE `product_sales` (
  `id` int(10) UNSIGNED NOT NULL,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_sales`
--

INSERT INTO `product_sales` (`id`, `sale_id`, `product_id`, `variant_id`, `qty`, `sale_unit_id`, `net_unit_price`, `discount`, `tax_rate`, `tax`, `total`, `created_at`, `updated_at`) VALUES
(1, 1, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2018-08-08 10:36:23', '2018-08-08 11:13:27'),
(3, 1, 5, NULL, 2, 1, 115, 10, 0, 0, 230, '2018-08-08 11:13:28', '2018-08-08 11:13:28'),
(4, 2, 1, NULL, 10, 1, 420, 0, 10, 420, 4620, '2018-08-08 23:54:53', '2018-08-08 23:54:53'),
(5, 2, 4, NULL, 50, 1, 2.1, 0, 0, 0, 105, '2018-08-08 23:54:53', '2018-08-08 23:54:53'),
(6, 2, 2, NULL, 3, 2, 109.57, 0, 15, 49.3, 378, '2018-08-08 23:54:53', '2018-08-08 23:54:53'),
(7, 3, 4, NULL, 20, 1, 2.1, 0, 0, 0, 42, '2018-08-09 00:32:15', '2018-08-09 00:32:15'),
(8, 3, 5, NULL, 5, 1, 126, 0, 0, 0, 630, '2018-08-09 00:32:15', '2018-08-09 00:32:15'),
(9, 3, 3, NULL, 1, 1, 225, 0, 0, 0, 225, '2018-08-09 00:32:15', '2018-08-09 00:32:15'),
(10, 4, 1, NULL, 2, 1, 400, 0, 10, 80, 880, '2018-08-24 21:48:37', '2018-08-24 21:48:37'),
(12, 6, 13, NULL, 1, 0, 18.9, 0, 0, 0, 18.9, '2018-08-26 03:48:36', '2018-08-26 05:48:05'),
(13, 7, 1, NULL, 2, 1, 400, 0, 10, 80, 880, '2018-08-27 01:35:45', '2018-08-27 01:35:45'),
(14, 8, 5, NULL, 2, 2, 1440, 0, 10, 288, 3168, '2018-09-01 23:39:54', '2018-09-01 23:39:54'),
(15, 9, 4, NULL, 10, 1, 2, 0, 0, 0, 20, '2018-09-02 21:33:14', '2018-09-02 21:33:14'),
(16, 10, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2018-09-02 23:01:39', '2018-09-02 23:01:39'),
(17, 11, 22, NULL, 5, 1, 1000, 0, 10, 500, 5500, '2018-09-03 04:08:21', '2018-09-03 04:08:21'),
(18, 12, 22, NULL, 10, 1, 1050, 0, 10, 1050, 11550, '2018-09-03 04:10:33', '2018-09-03 04:10:33'),
(46, 29, 5, NULL, 1, 1, 120, 0, 0, 0, 120, '2018-09-09 03:38:41', '2018-09-09 03:38:41'),
(47, 30, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-09-09 22:57:06', '2018-09-20 09:12:38'),
(48, 31, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-09-26 03:20:59', '2018-09-26 03:21:25'),
(49, 31, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2018-09-26 03:20:59', '2018-09-26 03:21:25'),
(50, 32, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-04 03:55:48', '2018-10-04 03:55:48'),
(51, 33, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-04 04:00:23', '2018-10-04 04:00:23'),
(57, 37, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2018-10-07 00:46:05', '2018-10-07 00:46:05'),
(58, 38, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-07 00:47:19', '2018-10-07 00:47:19'),
(61, 40, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-07 01:13:12', '2018-10-07 01:13:12'),
(62, 41, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-09 22:16:21', '2018-10-09 22:16:21'),
(63, 41, 13, NULL, 1, 0, 21, 0, 0, 0, 21, '2018-10-09 22:16:21', '2018-10-09 22:16:21'),
(64, 42, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-09 23:34:51', '2018-10-09 23:34:51'),
(65, 43, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-15 21:34:35', '2018-10-15 21:34:35'),
(78, 55, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2018-10-21 00:53:34', '2018-10-21 00:53:34'),
(80, 57, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2018-10-21 02:26:12', '2018-10-21 02:26:12'),
(81, 57, 13, NULL, 2, 0, 21, 0, 0, 0, 42, '2018-10-21 02:26:13', '2018-10-21 02:26:13'),
(82, 58, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2018-10-22 09:27:24', '2018-10-22 09:27:24'),
(83, 58, 5, NULL, 1, 1, 120, 0, 0, 0, 120, '2018-10-22 09:27:24', '2018-10-22 09:27:24'),
(101, 73, 25, NULL, 3, 1, 1000, 0, 10, 300, 3300, '2018-10-23 01:15:43', '2018-10-23 01:15:43'),
(102, 73, 22, NULL, 2, 1, 1000, 0, 10, 200, 2200, '2018-10-23 01:15:44', '2018-10-23 01:15:44'),
(103, 74, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2018-10-23 01:16:44', '2018-10-23 01:16:44'),
(104, 74, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2018-10-23 01:16:44', '2018-10-23 01:16:44'),
(105, 74, 5, NULL, 1, 1, 120, 0, 0, 0, 120, '2018-10-23 01:16:44', '2018-10-23 01:16:44'),
(106, 75, 2, NULL, 3, 2, 104.35, 0, 15, 46.96, 360, '2018-10-31 23:00:27', '2018-10-31 23:00:27'),
(107, 75, 22, NULL, 2, 1, 1000, 0, 10, 200, 2200, '2018-10-31 23:00:27', '2018-10-31 23:00:27'),
(108, 75, 25, NULL, 3, 1, 1000, 0, 10, 300, 3300, '2018-10-31 23:00:27', '2018-10-31 23:00:27'),
(109, 75, 1, NULL, 2, 1, 400, 0, 10, 80, 880, '2018-10-31 23:00:27', '2018-10-31 23:00:27'),
(110, 75, 5, NULL, 2, 1, 120, 0, 0, 0, 240, '2018-10-31 23:00:27', '2018-10-31 23:00:27'),
(111, 76, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2018-10-31 23:01:26', '2018-11-03 03:28:56'),
(112, 76, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2018-10-31 23:01:27', '2018-11-03 03:28:56'),
(113, 76, 13, NULL, 4, 0, 21, 0, 0, 0, 84, '2018-10-31 23:01:27', '2018-11-03 03:28:56'),
(117, 79, 1, NULL, 4, 1, 400, 0, 10, 160, 1760, '2018-11-05 03:15:17', '2018-11-05 03:15:17'),
(118, 79, 2, NULL, 7, 2, 104.35, 0, 15, 109.57, 840, '2018-11-05 03:15:17', '2018-11-05 03:15:17'),
(119, 79, 3, NULL, 7, 1, 250, 0, 0, 0, 1750, '2018-11-05 03:15:17', '2018-11-05 03:15:17'),
(120, 79, 4, NULL, 7, 1, 2, 0, 0, 0, 14, '2018-11-05 03:15:17', '2018-11-05 03:15:17'),
(121, 79, 22, NULL, 8, 1, 1000, 0, 10, 800, 8800, '2018-11-05 03:15:17', '2018-11-05 03:15:17'),
(122, 79, 13, NULL, 10, 0, 21, 0, 0, 0, 210, '2018-11-05 03:15:17', '2018-11-05 03:15:17'),
(123, 79, 5, NULL, 9, 1, 120, 0, 0, 0, 1080, '2018-11-05 03:15:17', '2018-11-05 03:15:17'),
(124, 80, 2, NULL, 2, 2, 104.35, 0, 15, 31.3, 240, '2018-11-05 03:19:58', '2018-11-05 03:19:58'),
(125, 80, 3, NULL, 2, 1, 250, 0, 0, 0, 500, '2018-11-05 03:19:58', '2018-11-05 03:19:58'),
(126, 80, 1, NULL, 4, 1, 400, 0, 10, 160, 1760, '2018-11-05 03:19:58', '2018-11-05 03:19:58'),
(132, 86, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2018-11-05 03:59:48', '2018-11-05 03:59:48'),
(134, 88, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2018-11-05 04:02:58', '2018-11-05 04:02:58'),
(142, 94, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2018-11-26 08:05:34', '2018-11-26 08:05:34'),
(143, 95, 5, NULL, 3, 1, 120, 0, 0, 0, 360, '2018-11-27 03:36:08', '2018-11-27 03:36:08'),
(144, 95, 5, NULL, 3, 1, 120, 0, 0, 0, 360, '2018-11-27 03:36:08', '2018-11-27 03:36:08'),
(145, 96, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2018-11-28 01:15:09', '2018-11-28 01:15:09'),
(146, 97, 2, NULL, 2, 2, 104.35, 0, 15, 31.3, 240, '2018-12-01 00:05:18', '2018-12-01 00:05:18'),
(147, 97, 10, NULL, 1, 7, 22, 0, 0, 0, 22, '2018-12-01 00:05:18', '2018-12-01 00:05:18'),
(148, 98, 30, NULL, 2, 1, 100, 0, 0, 0, 200, '2018-12-04 23:35:58', '2018-12-04 23:35:58'),
(149, 98, 31, NULL, 2, 1, 300, 0, 0, 0, 600, '2018-12-04 23:35:58', '2018-12-04 23:35:58'),
(150, 99, 30, NULL, 2, 1, 100, 0, 0, 0, 200, '2018-12-04 23:37:19', '2018-12-04 23:37:19'),
(151, 99, 31, NULL, 2, 1, 300, 0, 0, 0, 600, '2018-12-04 23:37:20', '2018-12-04 23:37:20'),
(153, 101, 30, NULL, 1, 1, 100, 0, 0, 0, 100, '2018-12-08 00:20:26', '2018-12-08 00:20:26'),
(155, 103, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2018-12-23 22:58:32', '2018-12-23 22:58:32'),
(156, 104, 33, NULL, 4, 1, 2, 0, 0, 0, 8, '2018-12-24 03:15:27', '2018-12-24 21:55:23'),
(157, 104, 26, NULL, 2, 0, 1250, 0, 0, 0, 2500, '2018-12-24 21:47:54', '2018-12-24 21:55:23'),
(158, 105, 13, NULL, 1, 0, 21, 0, 0, 0, 21, '2018-12-31 23:45:38', '2018-12-31 23:45:38'),
(159, 106, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2019-01-01 03:10:40', '2019-01-01 03:10:40'),
(160, 106, 3, NULL, 2, 1, 250, 0, 0, 0, 500, '2019-01-01 03:10:40', '2019-01-01 03:10:40'),
(161, 106, 5, NULL, 2, 1, 120, 0, 0, 0, 240, '2019-01-01 03:10:40', '2019-01-01 03:10:40'),
(162, 107, 3, NULL, 2, 1, 250, 0, 0, 0, 500, '2019-01-03 00:56:27', '2019-01-03 00:56:27'),
(163, 107, 5, NULL, 2, 1, 120, 0, 0, 0, 240, '2019-01-03 00:56:27', '2019-01-03 00:56:27'),
(164, 107, 22, NULL, 2, 1, 1000, 0, 10, 200, 2200, '2019-01-03 00:56:27', '2019-01-03 00:56:27'),
(165, 107, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-01-03 00:56:27', '2019-01-03 00:56:27'),
(166, 107, 1, NULL, 2, 1, 400, 0, 10, 80, 880, '2019-01-03 00:56:27', '2019-01-03 00:56:27'),
(167, 107, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2019-01-03 00:56:27', '2019-01-03 00:56:27'),
(168, 108, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2019-01-20 09:58:24', '2019-01-20 09:58:24'),
(169, 109, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-01-29 04:14:43', '2019-01-29 04:14:43'),
(170, 109, 30, NULL, 1, 1, 100, 0, 0, 0, 100, '2019-01-29 04:14:43', '2019-01-29 04:14:43'),
(171, 110, 31, NULL, 2, 1, 300, 0, 0, 0, 600, '2019-01-29 05:50:41', '2019-01-29 05:50:41'),
(172, 110, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-01-29 05:50:41', '2019-01-29 05:50:41'),
(173, 111, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2019-01-31 05:08:39', '2019-01-31 05:08:39'),
(174, 111, 13, NULL, 1, 0, 21, 0, 0, 0, 21, '2019-01-31 05:08:39', '2019-01-31 05:08:39'),
(175, 112, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-02-02 04:40:45', '2019-02-02 04:40:45'),
(176, 113, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2019-02-02 05:41:17', '2019-02-02 05:41:17'),
(177, 113, 30, NULL, 1, 1, 100, 0, 0, 0, 100, '2019-02-02 05:41:17', '2019-02-02 05:41:17'),
(178, 114, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-02-05 09:04:45', '2019-02-05 09:04:45'),
(183, 118, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-02-07 05:15:42', '2019-02-07 05:15:42'),
(185, 120, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-02-07 05:40:37', '2019-02-07 05:40:37'),
(186, 121, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2019-02-09 04:48:14', '2019-02-09 04:48:14'),
(187, 121, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2019-02-09 04:48:14', '2019-02-09 04:48:14'),
(188, 121, 4, NULL, 10, 1, 2, 0, 0, 0, 20, '2019-02-09 04:48:15', '2019-02-09 04:48:15'),
(189, 121, 13, NULL, 2, 0, 21, 0, 0, 0, 42, '2019-02-09 04:48:15', '2019-02-09 04:48:15'),
(190, 121, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-02-09 04:48:15', '2019-02-09 04:48:15'),
(191, 121, 31, NULL, 1, 1, 300, 0, 0, 0, 300, '2019-02-09 04:48:15', '2019-02-09 04:48:15'),
(192, 121, 30, NULL, 1, 1, 100, 0, 0, 0, 100, '2019-02-09 04:48:15', '2019-02-09 04:48:15'),
(194, 123, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-02-19 08:32:14', '2019-02-19 08:32:14'),
(198, 127, 31, NULL, 1, 1, 300, 0, 0, 0, 300, '2019-03-03 04:40:10', '2019-03-03 04:40:10'),
(199, 127, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-03-03 04:40:10', '2019-03-03 04:40:10'),
(200, 127, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-03-03 04:40:10', '2019-03-03 04:40:10'),
(201, 128, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-04-04 03:55:55', '2019-04-04 03:55:55'),
(202, 128, 2, NULL, 1, 2, 104.35, 0, 15, 15.65, 120, '2019-04-04 03:55:55', '2019-04-04 03:55:55'),
(203, 129, 5, NULL, 2, 1, 120, 0, 0, 0, 240, '2019-04-04 03:59:37', '2019-04-11 04:50:16'),
(204, 130, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-04-21 06:21:24', '2019-04-21 06:21:24'),
(205, 130, 2, NULL, 1, 2, 125.22, 0, 15, 18.78, 144, '2019-04-21 06:21:24', '2019-04-21 06:21:24'),
(206, 130, 4, NULL, 1, 1, 2, 0, 0, 0, 2, '2019-04-21 06:21:24', '2019-04-21 06:21:24'),
(207, 131, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-05-28 04:32:29', '2019-05-28 04:32:29'),
(208, 131, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2019-05-28 04:32:29', '2019-05-28 04:32:29'),
(209, 131, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-05-28 04:32:29', '2019-05-28 04:32:29'),
(210, 131, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-05-28 04:32:29', '2019-05-28 04:32:29'),
(211, 132, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-06-13 04:16:37', '2019-06-13 04:16:37'),
(212, 132, 30, NULL, 1, 1, 100, 0, 0, 0, 100, '2019-06-13 04:16:37', '2019-06-13 04:16:37'),
(213, 132, 31, NULL, 1, 1, 300, 0, 0, 0, 300, '2019-06-13 04:16:37', '2019-06-13 04:16:37'),
(214, 133, 3, NULL, 2, 1, 250, 0, 0, 0, 500, '2019-06-13 04:17:51', '2019-06-13 04:17:51'),
(215, 133, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-06-13 04:17:52', '2019-06-13 04:17:52'),
(216, 133, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-06-13 04:17:52', '2019-06-13 04:17:52'),
(217, 134, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-10-19 09:30:28', '2019-10-19 09:30:28'),
(218, 134, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-10-19 09:30:28', '2019-10-19 09:30:28'),
(219, 134, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-10-19 09:30:28', '2019-10-19 09:30:28'),
(220, 134, 31, NULL, 1, 1, 300, 0, 0, 0, 300, '2019-10-19 09:30:28', '2019-10-19 09:30:28'),
(224, 138, 5, NULL, 1, 1, 120, 0, 0, 0, 120, '2019-10-31 06:29:37', '2019-10-31 06:29:37'),
(225, 139, 2, NULL, 2, 2, 125.22, 0, 15, 37.57, 288, '2019-11-03 05:40:44', '2019-11-03 05:40:44'),
(226, 139, 4, NULL, 100, 1, 2, 0, 0, 0, 200, '2019-11-03 05:40:44', '2019-11-03 05:40:44'),
(236, 144, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-11-09 13:41:31', '2019-11-09 13:41:31'),
(237, 144, 5, NULL, 1, 1, 120, 0, 0, 0, 120, '2019-11-09 13:41:31', '2019-11-09 13:41:31'),
(241, 147, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-11-11 04:40:08', '2019-11-11 04:40:08'),
(242, 147, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-11-11 04:40:08', '2019-11-11 04:40:08'),
(243, 147, 4, NULL, 10, 1, 2, 0, 0, 0, 20, '2019-11-11 04:40:08', '2019-11-11 04:40:08'),
(282, 172, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2019-12-03 09:46:31', '2019-12-03 09:46:31'),
(283, 173, 3, NULL, 1, 1, 225, 0, 0, 0, 225, '2019-12-04 17:19:40', '2019-12-04 17:19:40'),
(284, 173, 1, NULL, 1, 1, 360, 0, 10, 36, 396, '2019-12-04 17:19:40', '2019-12-04 17:19:40'),
(306, 187, 2, NULL, 2, 2, 125.22, 0, 15, 37.57, 288, '2019-12-22 04:40:58', '2019-12-22 04:40:58'),
(308, 190, 22, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2019-12-23 06:59:46', '2019-12-23 06:59:46'),
(312, 193, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2020-01-01 08:20:28', '2020-01-01 08:20:28'),
(313, 194, 1, NULL, 2, 1, 400, 0, 10, 80, 880, '2020-01-02 10:39:47', '2020-01-02 10:39:47'),
(314, 194, 2, NULL, 1, 1, 10.43, 0, 15, 1.57, 12, '2020-01-02 10:39:47', '2020-01-02 10:39:47'),
(323, 201, 5, NULL, 1, 1, 120, 0, 0, 0, 120, '2020-02-03 09:52:56', '2020-02-03 09:52:56'),
(324, 202, 25, NULL, 1, 1, 1000, 0, 10, 100, 1100, '2020-02-04 16:58:53', '2020-02-04 16:58:53'),
(325, 202, 31, NULL, 1, 1, 300, 0, 0, 0, 300, '2020-02-04 16:58:53', '2020-02-04 16:58:53'),
(326, 203, 3, NULL, 1, 1, 250, 0, 0, 0, 250, '2020-03-02 05:54:14', '2020-03-02 05:54:14'),
(327, 203, 30, NULL, 1, 1, 100, 0, 0, 0, 100, '2020-03-02 05:54:14', '2020-03-02 05:54:14'),
(328, 204, 4, NULL, 20, 1, 2, 0, 0, 0, 40, '2020-03-02 05:57:41', '2020-03-02 05:57:41'),
(329, 205, 1, NULL, 1, 1, 400, 0, 10, 40, 440, '2020-03-11 10:46:42', '2020-03-11 10:46:42'),
(330, 206, 5, NULL, 1, 1, 120, 0, 0, 0, 120, '2020-03-11 10:52:30', '2020-03-11 10:54:04'),
(331, 207, 30, NULL, 2, 1, 100, 0, 0, 0, 200, '2020-04-06 13:40:24', '2020-04-06 13:41:11'),
(332, 207, 31, NULL, 1, 1, 300, 0, 0, 0, 300, '2020-04-06 13:40:24', '2020-04-06 13:41:11'),
(333, 207, 2, NULL, 1, 2, 125.22, 0, 15, 18.78, 144, '2020-04-06 13:41:11', '2020-04-06 13:41:11');

-- --------------------------------------------------------

--
-- Table structure for table `product_transfer`
--

CREATE TABLE `product_transfer` (
  `id` int(10) UNSIGNED NOT NULL,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_transfer`
--

INSERT INTO `product_transfer` (`id`, `transfer_id`, `product_id`, `variant_id`, `qty`, `purchase_unit_id`, `net_unit_cost`, `tax_rate`, `tax`, `total`, `created_at`, `updated_at`) VALUES
(1, 1, 4, NULL, 100, 1, 1, 0, 0, 100, '2018-08-08 11:17:10', '2018-12-24 22:16:55'),
(7, 6, 48, 3, 1, 1, 2, 0, 0, 2, '2019-12-05 13:55:04', '2019-12-05 14:09:42'),
(11, 8, 5, NULL, 10, 1, 100, 0, 0, 1000, '2020-01-22 06:30:59', '2020-01-22 06:30:59');

-- --------------------------------------------------------

--
-- Table structure for table `product_variants`
--

CREATE TABLE `product_variants` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `item_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_price` double DEFAULT NULL,
  `qty` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_variants`
--

INSERT INTO `product_variants` (`id`, `product_id`, `variant_id`, `position`, `item_code`, `additional_price`, `qty`, `created_at`, `updated_at`) VALUES
(3, 48, 3, 1, 'S-93475396', NULL, 12, '2019-11-21 07:03:04', '2021-02-16 09:48:44'),
(5, 48, 5, 3, 'L-93475396', 50, 11, '2019-11-24 06:07:20', '2020-03-16 14:08:26'),
(6, 48, 2, 2, 'M-93475396', 10, 13, '2019-11-24 07:17:07', '2021-02-16 09:48:44');

-- --------------------------------------------------------

--
-- Table structure for table `product_warehouse`
--

CREATE TABLE `product_warehouse` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) NOT NULL,
  `qty` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_warehouse`
--

INSERT INTO `product_warehouse` (`id`, `product_id`, `variant_id`, `warehouse_id`, `qty`, `created_at`, `updated_at`) VALUES
(10, '1', NULL, 1, 136.5, '2018-08-08 08:30:12', '2020-01-17 05:11:26'),
(11, '2', NULL, 1, 1404, '2018-08-08 08:30:12', '2019-12-05 04:31:49'),
(12, '3', NULL, 1, 104, '2018-08-08 08:30:13', '2020-02-26 06:16:35'),
(13, '5', NULL, 1, 77, '2018-08-08 08:30:13', '2020-03-11 10:54:04'),
(14, '4', NULL, 1, 171, '2018-08-08 09:16:09', '2020-03-02 05:56:03'),
(15, '4', NULL, 2, 21, '2018-08-08 11:16:15', '2021-02-16 09:49:05'),
(16, '2', NULL, 2, 1847, '2018-08-08 11:26:49', '2020-04-06 13:41:11'),
(17, '1', NULL, 2, 73.5, '2018-08-08 11:33:33', '2020-03-16 14:08:26'),
(18, '3', NULL, 2, 68, '2018-08-08 23:47:23', '2020-03-02 05:54:14'),
(19, '5', NULL, 2, 63, '2018-08-08 23:48:36', '2020-02-03 09:52:56'),
(20, '10', NULL, 1, 50, '2018-08-08 23:49:29', '2019-12-04 05:49:14'),
(21, '10', NULL, 2, 61, '2018-08-08 23:49:55', '2018-12-01 00:05:18'),
(22, '22', NULL, 1, 24, '2018-09-03 04:06:09', '2019-01-03 01:01:24'),
(23, '22', NULL, 2, 12, '2018-09-03 04:07:14', '2021-02-16 09:48:54'),
(24, '24', NULL, 2, 0, '2018-09-15 21:49:30', '2018-09-15 21:50:49'),
(25, '25', NULL, 1, 14, '2018-10-23 01:14:21', '2019-03-02 10:06:10'),
(26, '25', NULL, 2, 15, '2018-10-23 01:14:41', '2021-02-16 09:48:33'),
(27, '31', NULL, 1, 14, '2018-12-04 23:34:30', '2019-04-13 13:50:08'),
(28, '30', NULL, 1, 15, '2018-12-04 23:34:30', '2020-04-06 13:53:31'),
(29, '31', NULL, 2, 10, '2018-12-04 23:35:08', '2021-02-16 09:48:33'),
(30, '30', NULL, 2, 10, '2018-12-04 23:35:08', '2021-02-16 09:48:33'),
(31, '32', NULL, 1, 10, '2018-12-18 23:57:16', '2019-02-09 04:45:23'),
(32, '32', NULL, 2, 20, '2018-12-18 23:57:41', '2019-11-11 04:28:59'),
(33, '33', NULL, 1, 16, '2018-12-24 00:38:40', '2019-03-03 04:39:17'),
(34, '33', NULL, 2, 25, '2019-02-09 04:21:38', '2019-11-03 05:39:49'),
(35, '48', 3, 1, 1, '2019-11-25 14:23:02', '2021-02-16 09:48:44'),
(36, '48', 2, 1, 2, '2019-11-26 06:47:42', '2021-02-16 09:48:44'),
(37, '48', 3, 2, 11, '2019-11-26 08:12:08', '2020-01-10 11:22:49'),
(38, '48', 2, 2, 11, '2019-11-26 08:12:08', '2020-01-10 11:22:06'),
(39, '48', 5, 1, 1, '2019-12-21 10:18:51', '2020-01-10 11:10:24'),
(40, '48', 5, 2, 10, '2019-12-22 08:36:39', '2020-03-16 14:08:26');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `order_discount` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `paid_amount` double NOT NULL,
  `status` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `reference_no`, `user_id`, `warehouse_id`, `supplier_id`, `item`, `total_qty`, `total_discount`, `total_tax`, `total_cost`, `order_tax_rate`, `order_tax`, `order_discount`, `shipping_cost`, `grand_total`, `paid_amount`, `status`, `payment_status`, `document`, `note`, `created_at`, `updated_at`) VALUES
(12, 'pr-20180808-051614', 1, 2, 3, 2, 300, 0, 0, 10200, 0, 0, 0, 0, 10200, 5000, 1, 1, NULL, NULL, '2018-08-08 11:16:14', '2020-12-06 12:53:15'),
(13, 'pr-20180809-054723', 1, 2, 3, 4, 410, 0, 7304.35, 92600, 10, 9260, 0, 500, 102360, 300, 1, 1, NULL, NULL, '2018-08-08 23:47:23', '2018-08-30 03:07:18'),
(14, 'pr-20180809-012348', 1, 1, 1, 5, 400, 0, 4452.17, 75300, 10, 7480, 500, 1000, 83280, 0, 1, 1, NULL, NULL, '2018-08-09 07:23:48', '2018-08-09 07:23:48'),
(15, 'pr-20180903-100609', 1, 1, 1, 1, 20, 0, 1600, 17600, 0, 0, 0, 100, 17700, 0, 1, 1, NULL, NULL, '2018-09-03 04:06:09', '2018-10-07 22:11:24'),
(16, 'pr-20180903-100714', 1, 2, 3, 1, 20, 0, 1600, 17600, 0, 0, 0, 150, 17750, 3350, 1, 1, NULL, NULL, '2018-09-03 04:07:14', '2018-10-07 00:57:36'),
(18, 'pr-20181022-042625', 1, 1, 1, 1, 50, 0, 0, 50, 0, 0, NULL, NULL, 50, 0, 1, 1, NULL, NULL, '2018-10-22 10:26:25', '2018-10-22 10:26:25'),
(19, 'pr-20181022-042652', 1, 2, 3, 1, 50, 0, 0, 50, 0, 0, NULL, NULL, 50, 0, 1, 1, NULL, NULL, '2018-10-22 10:26:52', '2018-10-22 10:26:52'),
(20, 'pr-20181023-071420', 11, 1, 1, 1, 15, 0, 750, 8250, 0, 0, NULL, NULL, 8250, 0, 1, 1, NULL, NULL, '2018-10-23 01:14:20', '2018-10-23 01:14:20'),
(21, 'pr-20181023-071441', 11, 2, 3, 1, 15, 0, 750, 8250, 0, 0, 0, 0, 8250, 0, 1, 1, NULL, NULL, '2018-10-23 01:14:41', '2018-10-23 01:14:58'),
(22, 'pr-20181101-045903', 1, 1, 1, 1, 5, 0, 400, 4400, 0, 0, NULL, NULL, 4400, 0, 1, 1, NULL, NULL, '2018-10-31 22:59:03', '2018-10-31 22:59:03'),
(23, 'pr-20181101-045928', 1, 2, 3, 1, 5, 0, 400, 4400, 10, 430, 100, 0, 4730, 500, 1, 1, NULL, NULL, '2018-10-31 22:59:28', '2018-12-04 01:01:34'),
(24, 'pr-20181105-091819', 1, 2, 1, 2, 20, 0, 1450, 15950, 0, 0, NULL, NULL, 15950, 15950, 1, 2, NULL, NULL, '2018-11-05 03:18:19', '2018-11-05 03:21:27'),
(25, 'pr-20181205-053429', 1, 1, 1, 2, 30, 0, 0, 4500, 0, 0, 100, 50, 4450, 4450, 1, 2, NULL, NULL, '2018-12-04 23:34:29', '2018-12-04 23:34:43'),
(26, 'pr-20181205-053508', 1, 2, 3, 2, 30, 0, 0, 4500, 0, 0, NULL, NULL, 4500, 0, 1, 1, NULL, NULL, '2018-12-04 23:35:08', '2018-12-10 00:20:52'),
(27, 'pr-20181219-055716', 1, 2, NULL, 1, 10, 0, 0, 10, 0, 0, 0, 0, 10, 10, 1, 2, NULL, NULL, '2018-12-18 23:57:16', '2018-12-20 00:34:39'),
(33, 'pr-20181224-063840', 1, 1, NULL, 1, 10, 0, 0, 10, 0, 0, 0, 0, 10, 0, 1, 1, NULL, NULL, '2018-12-24 00:38:40', '2018-12-24 03:04:21'),
(34, 'pr-20190103-070123', 1, 1, 1, 2, 4, 0, 260, 2860, 0, 0, NULL, NULL, 2860, 2860, 1, 2, NULL, NULL, '2019-01-03 01:01:23', '2019-01-29 04:03:24'),
(35, 'pr-20190129-095448', 9, 1, 1, 2, 4, 0, 0, 600, 0, 0, NULL, NULL, 600, 100, 1, 1, NULL, NULL, '2019-01-29 03:54:48', '2019-02-07 07:06:40'),
(36, 'pr-20190129-095558', 9, 2, 1, 2, 5, 0, 0, 650, 0, 0, NULL, NULL, 650, 650, 1, 2, NULL, NULL, '2019-01-29 03:55:58', '2019-01-29 04:03:02'),
(37, 'pr-20190209-102138', 1, 2, 1, 3, 18, 0, 580, 6390, 0, 0, 0, 0, 6390, 6390, 1, 2, NULL, NULL, '2019-02-09 04:21:38', '2019-06-13 04:13:51'),
(38, 'pr-20190209-102208', 1, 1, 1, 2, 13, 0, 150, 1660, 0, 0, 0, 0, 1660, 1660, 1, 2, NULL, NULL, '2019-02-09 04:22:08', '2019-02-09 04:49:40'),
(39, 'pr-20190209-104413', 1, 1, 1, 2, 3, 10, 63, 885, 10, 88.5, NULL, NULL, 973.5, 973.5, 1, 2, NULL, NULL, '2019-02-09 04:44:13', '2019-02-09 04:49:59'),
(40, 'pr-20190303-103917', 1, 1, 1, 1, 10, 0, 0, 100, 0, 0, NULL, NULL, 100, 100, 1, 2, NULL, NULL, '2019-03-03 04:39:17', '2019-03-03 04:40:46'),
(41, 'pr-20190303-104358', 1, 2, NULL, 2, 15, 0, 320, 3570, 0, 0, NULL, NULL, 3570, 1000, 1, 1, NULL, NULL, '2019-03-03 04:43:58', '2019-04-13 11:02:41'),
(42, 'pr-20190404-095757', 1, 1, 3, 2, 2, 0, 0, 300, 0, 0, 0, 0, 300, 300, 1, 2, NULL, NULL, '2019-04-04 03:57:57', '2019-04-13 13:50:08'),
(43, 'pr-20190613-101600', 1, 2, 1, 2, 6, 0, 390, 4290, 0, 0, NULL, NULL, 4290, 4290, 1, 2, NULL, NULL, '2019-06-13 04:16:00', '2019-10-19 09:29:25'),
(44, 'pr-20191019-033119', 1, 2, 3, 2, 2, 0, 130, 1430, 0, 0, NULL, NULL, 1430, 0, 1, 1, NULL, NULL, '2019-10-19 09:31:19', '2019-10-19 09:31:19'),
(46, 'pr-20191103-113949', 1, 2, 3, 2, 20, 0, 0, 150, 0, 0, NULL, 50, 200, 200, 1, 2, NULL, NULL, '2019-11-03 05:39:49', '2019-11-03 05:42:22'),
(47, 'pr-20191109-112510', 1, 1, NULL, 2, 3, 10, 63, 885, 0, 0, NULL, 66, 951, 0, 1, 1, NULL, NULL, '2019-11-09 05:25:10', '2019-11-09 05:25:10'),
(56, 'pr-20191127-102906', 1, 2, NULL, 1, 1, 0, 0, 2, 0, 0, 0, 0, 2, 2, 1, 2, NULL, NULL, '2019-11-27 16:29:06', '2020-01-01 08:21:44'),
(57, 'pr-20191204-110749', 1, 1, 1, 1, 1, 0, 0, 200, 0, 0, NULL, 20, 220, 220, 1, 2, NULL, NULL, '2019-12-04 17:07:49', '2019-12-04 17:11:24'),
(58, 'pr-20191205-102110', 1, 1, 1, 2, 2, 0, 0, 4, 0, 0, 0, 0, 4, 4, 1, 2, NULL, NULL, '2019-12-05 04:21:10', '2020-01-01 08:21:37'),
(59, 'pr-20191221-041851', 1, 1, NULL, 3, 3, 0, 0, 6, 0, 0, 0, 0, 6, 6, 1, 2, NULL, NULL, '2019-12-21 10:18:51', '2020-01-01 08:21:31'),
(61, 'pr-20200101-010631', 1, 2, 1, 3, 30, 0, 0, 60, 0, 0, NULL, NULL, 60, 60, 1, 2, NULL, NULL, '2020-01-01 07:06:31', '2020-01-01 07:07:50'),
(62, 'pr-20200101-022402', 1, 2, NULL, 1, 3, 0, 150, 1650, 0, 0, NULL, NULL, 1650, 0, 1, 1, NULL, NULL, '2020-01-01 08:24:02', '2020-01-01 08:24:02'),
(67, 'pr-20200204-110041', 1, 2, 1, 2, 2, 0, 0, 300, 0, 0, NULL, NULL, 300, 300, 1, 2, NULL, NULL, '2020-02-04 17:00:41', '2020-02-04 17:00:50'),
(69, 'pr-20200302-115510', 1, 2, NULL, 1, 50, 0, 0, 50, 0, 0, NULL, NULL, 50, 50, 1, 2, NULL, NULL, '2020-03-02 05:55:10', '2020-03-02 05:58:20'),
(70, 'pr-20200302-115603', 1, 1, 1, 1, 50, 0, 0, 50, 0, 0, NULL, NULL, 50, 50, 1, 2, NULL, NULL, '2020-03-02 05:56:03', '2020-03-02 05:58:11');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_product_return`
--

CREATE TABLE `purchase_product_return` (
  `id` int(10) UNSIGNED NOT NULL,
  `return_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchase_product_return`
--

INSERT INTO `purchase_product_return` (`id`, `return_id`, `product_id`, `variant_id`, `qty`, `purchase_unit_id`, `net_unit_cost`, `discount`, `tax_rate`, `tax`, `total`, `created_at`, `updated_at`) VALUES
(1, 1, 3, NULL, 1, 1, 200, 0, 0, 0, 200, NULL, '2019-12-07 11:19:03');

-- --------------------------------------------------------

--
-- Table structure for table `quotations`
--

CREATE TABLE `quotations` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `grand_total` double NOT NULL,
  `quotation_status` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quotations`
--

INSERT INTO `quotations` (`id`, `reference_no`, `user_id`, `customer_id`, `grand_total`, `quotation_status`, `note`, `created_at`, `updated_at`) VALUES
(1, 'qr-20180809-055250', 1, 3, 6913, 2, 'first quotation...', '2018-08-08 23:52:50', '2018-09-04 03:32:16'),
(2, 'qr-20180904-040257', 1, 1, 77.1, 1, NULL, '2018-09-03 22:02:57', '2018-09-21 07:05:57'),
(3, 'qr-20181023-061249', 19, 2, 453, 2, 'This is testing Quotation', '2018-10-23 00:12:49', '2021-04-04 14:44:20');

-- --------------------------------------------------------

--
-- Table structure for table `returns`
--

CREATE TABLE `returns` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_price` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `returns`
--

INSERT INTO `returns` (`id`, `reference_no`, `user_id`, `customer_id`, `warehouse_id`, `biller_id`, `account_id`, `item`, `total_qty`, `total_discount`, `total_tax`, `total_price`, `order_tax_rate`, `order_tax`, `grand_total`, `document`, `return_note`, `staff_note`, `created_at`, `updated_at`) VALUES
(2, 'rr-20180809-055834', 1, 1, 1, 1, 1, 1, 20, 0, 0, 40, 10, 4, 44, NULL, NULL, NULL, '2018-08-08 23:58:34', '2018-08-08 23:58:34'),
(3, 'rr-20180828-045527', 1, 1, 2, 1, 1, 1, 2, 0, 0, 44, 0, 0, 44, NULL, NULL, NULL, '2018-08-27 22:55:27', '2018-09-20 11:03:47'),
(5, 'rr-20181007-082129', 1, 11, 2, 2, 1, 1, 1, 0, 0, 250, 0, 0, 250, NULL, NULL, NULL, '2018-10-07 02:21:29', '2018-12-25 22:16:08'),
(6, 'rr-20190101-090630', 9, 1, 1, 1, 1, 1, 1, 0, 40, 440, 0, 0, 440, NULL, NULL, NULL, '2019-01-01 03:06:30', '2019-01-01 03:06:30');

-- --------------------------------------------------------

--
-- Table structure for table `return_purchases`
--

CREATE TABLE `return_purchases` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `return_purchases`
--

INSERT INTO `return_purchases` (`id`, `reference_no`, `supplier_id`, `warehouse_id`, `user_id`, `account_id`, `item`, `total_qty`, `total_discount`, `total_tax`, `total_cost`, `order_tax_rate`, `order_tax`, `grand_total`, `document`, `return_note`, `staff_note`, `created_at`, `updated_at`) VALUES
(1, 'prr-20190101-090759', 3, 1, 1, 1, 1, 1, 0, 0, 200, 0, 0, 200, NULL, NULL, NULL, '2019-01-01 03:07:59', '2019-12-07 11:19:03');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin can access all data...', '2018-06-01 23:46:44', '2018-06-02 23:13:05'),
(2, 'Supervisior', 'Supervisior has more roles than Staff', '2018-10-22 02:38:13', '2021-02-16 09:37:59'),
(4, 'Staff', 'Staff has specific access', '2018-06-02 00:05:27', '2021-04-09 09:54:33');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(6, 4),
(7, 1),
(7, 2),
(7, 4),
(8, 1),
(8, 2),
(8, 4),
(9, 1),
(9, 2),
(9, 4),
(10, 1),
(10, 2),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(12, 4),
(13, 1),
(13, 2),
(13, 4),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(17, 1),
(17, 2),
(18, 1),
(18, 2),
(19, 1),
(19, 2),
(20, 1),
(20, 2),
(20, 4),
(21, 1),
(21, 2),
(21, 4),
(22, 1),
(22, 2),
(23, 1),
(23, 2),
(24, 1),
(24, 2),
(24, 4),
(25, 1),
(25, 2),
(25, 4),
(26, 1),
(26, 2),
(27, 1),
(27, 2),
(28, 1),
(28, 2),
(28, 4),
(29, 1),
(29, 2),
(29, 4),
(30, 1),
(30, 2),
(31, 1),
(31, 2),
(32, 1),
(32, 2),
(33, 1),
(33, 2),
(34, 1),
(34, 2),
(35, 1),
(35, 2),
(36, 1),
(36, 2),
(37, 1),
(37, 2),
(38, 1),
(38, 2),
(39, 1),
(39, 2),
(40, 1),
(40, 2),
(41, 1),
(41, 2),
(42, 1),
(42, 2),
(43, 1),
(43, 2),
(44, 1),
(44, 2),
(45, 1),
(45, 2),
(46, 1),
(46, 2),
(47, 1),
(47, 2),
(48, 1),
(48, 2),
(49, 1),
(49, 2),
(50, 1),
(50, 2),
(51, 1),
(51, 2),
(52, 1),
(52, 2),
(53, 1),
(53, 2),
(54, 1),
(54, 2),
(55, 1),
(55, 2),
(56, 1),
(56, 2),
(57, 1),
(57, 2),
(58, 1),
(58, 2),
(59, 1),
(59, 2),
(60, 1),
(60, 2),
(61, 1),
(61, 2),
(62, 1),
(62, 2),
(63, 1),
(63, 2),
(63, 4),
(64, 1),
(64, 2),
(64, 4),
(65, 1),
(65, 2),
(66, 1),
(66, 2),
(67, 1),
(67, 2),
(68, 1),
(68, 2),
(69, 1),
(69, 2),
(70, 1),
(70, 2),
(71, 1),
(71, 2),
(72, 1),
(72, 2),
(73, 1),
(73, 2),
(74, 1),
(74, 2),
(75, 1),
(75, 2),
(76, 1),
(76, 2),
(77, 1),
(77, 2),
(78, 1),
(78, 2),
(79, 1),
(79, 2),
(80, 1),
(80, 2),
(81, 1),
(81, 2),
(82, 1),
(82, 2),
(83, 1),
(83, 2),
(84, 1),
(84, 2),
(85, 1),
(85, 2),
(86, 1),
(86, 2),
(87, 1),
(87, 2),
(88, 1),
(88, 2),
(89, 1),
(90, 1),
(91, 1),
(92, 1),
(93, 1),
(94, 1),
(95, 1),
(96, 1),
(97, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) DEFAULT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_price` double NOT NULL,
  `grand_total` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `order_discount` double DEFAULT NULL,
  `coupon_id` int(11) DEFAULT NULL,
  `coupon_discount` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `sale_status` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double DEFAULT NULL,
  `sale_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `reference_no`, `user_id`, `customer_id`, `warehouse_id`, `biller_id`, `item`, `total_qty`, `total_discount`, `total_tax`, `total_price`, `grand_total`, `order_tax_rate`, `order_tax`, `order_discount`, `coupon_id`, `coupon_discount`, `shipping_cost`, `sale_status`, `payment_status`, `document`, `paid_amount`, `sale_note`, `staff_note`, `created_at`, `updated_at`) VALUES
(1, 'sr-20180808-043622', 1, 1, 1, 1, 2, 3, 10, 15.65, 350, 380, 10, 30, 50, NULL, NULL, 50, 1, 2, NULL, 0, 'ukgjkgjkgkj', 'gjkgjkgkujg', '2018-08-08 10:36:22', '2018-10-06 09:25:29'),
(2, 'sr-20180809-055453', 1, 3, 1, 1, 3, 63, 0, 469.3, 5103, 5503, 0, 0, 100, NULL, NULL, 500, 1, 2, NULL, 2200, NULL, NULL, '2018-08-08 23:54:53', '2018-08-08 23:56:35'),
(3, 'posr-20180809-063214', 1, 2, 2, 2, 3, 26, 0, 0, 897, 897, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 897, NULL, NULL, '2018-08-09 00:32:14', '2018-08-09 00:32:14'),
(4, 'sr-20180825-034836', 1, 1, 1, 1, 1, 2, 0, 80, 880, 880, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 300, NULL, NULL, '2018-08-24 21:48:36', '2018-09-22 02:56:03'),
(6, 'sr-20180826-094836', 1, 2, 1, 2, 1, 1, 0, 0, 18.9, 20, 0, 0, 0, NULL, NULL, 1.1, 1, 4, NULL, 20, NULL, NULL, '2018-08-26 03:48:36', '2018-08-26 05:48:05'),
(7, 'sr-20180827-073545', 1, 1, 1, 1, 1, 2, 0, 80, 880, 880, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 880, NULL, NULL, '2018-08-27 01:35:45', '2018-08-27 01:35:45'),
(8, 'posr-20180902-053954', 1, 1, 1, 2, 1, 2, 0, 288, 3168, 3529.8, 10, 311.8, 50, NULL, NULL, 100, 1, 4, NULL, 3529.8, 'good customer', 'good customer', '2018-09-01 23:39:54', '2018-09-01 23:39:54'),
(9, 'posr-20180903-033314', 1, 1, 2, 1, 1, 10, 0, 0, 20, 20, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 20, NULL, NULL, '2018-09-02 21:33:14', '2018-09-02 21:33:14'),
(10, 'posr-20180903-050138', 1, 11, 2, 1, 1, 1, 0, 0, 250, 250, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 200, NULL, NULL, '2018-09-02 23:01:38', '2018-09-09 21:40:28'),
(11, 'posr-20180903-100821', 1, 11, 2, 1, 1, 5, 0, 500, 5500, 5500, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 5500, NULL, NULL, '2018-09-03 04:08:21', '2018-09-03 04:08:21'),
(12, 'sr-20180903-101026', 1, 3, 1, 5, 1, 10, 0, 1050, 11550, 11550, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 0, NULL, NULL, '2018-09-03 04:10:26', '2018-09-22 02:55:14'),
(29, 'sr-20180909-093841', 1, 1, 1, 1, 1, 1, 0, 0, 120, 132, 10, 12, NULL, NULL, NULL, NULL, 1, 2, NULL, 0, NULL, NULL, '2018-09-09 03:38:41', '2018-10-06 02:36:52'),
(30, 'posr-20180910-045706', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, 0, NULL, NULL, 0, 1, 2, NULL, 120, NULL, NULL, '2018-09-09 22:57:06', '2018-10-06 00:53:20'),
(31, 'posr-20180926-092059', 1, 11, 2, 1, 2, 2, 0, 55.65, 560, 560, 0, 0, 0, NULL, NULL, 0, 1, 4, NULL, 560, NULL, NULL, '2018-09-26 03:20:59', '2018-09-26 03:21:25'),
(32, 'posr-20181004-095547', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, '2018-10-04 03:55:47', '2018-10-04 03:55:47'),
(33, 'posr-20181004-100022', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, '2018-10-04 04:00:22', '2018-10-04 04:00:22'),
(37, 'sr-20181007-064605', 1, 1, 1, 1, 1, 1, 0, 0, 250, 250, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 0, NULL, NULL, '2018-10-07 00:46:05', '2018-10-07 00:46:28'),
(38, 'posr-20181007-064719', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 0, NULL, NULL, '2018-10-07 00:47:19', '2018-10-07 03:17:02'),
(40, 'posr-20181007-071312', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 0, NULL, NULL, '2018-10-07 01:13:12', '2018-10-07 03:17:39'),
(41, 'posr-20181010-041621', 1, 1, 2, 1, 2, 2, 0, 40, 461, 461, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 461, NULL, NULL, '2018-10-09 22:16:21', '2018-10-09 22:16:21'),
(42, 'posr-20181010-053450', 1, 1, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 440, NULL, NULL, '2018-10-09 23:34:50', '2018-10-09 23:34:50'),
(43, 'sr-20181016-033434', 1, 1, 1, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 0, 'sss\r\nsss\r\ns', NULL, '2018-10-15 21:34:34', '2018-10-23 00:21:27'),
(55, 'posr-20181021-065334', 1, 11, 2, 1, 1, 1, 0, 0, 250, 250, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 250, NULL, NULL, '2018-10-21 00:53:34', '2018-10-21 00:53:34'),
(57, 'posr-20181021-082612', 1, 11, 2, 1, 2, 3, 0, 40, 482, 575.2, 10, 43.2, 50, NULL, NULL, 100, 1, 4, NULL, 575.2, NULL, NULL, '2018-10-21 02:26:12', '2018-10-21 02:26:12'),
(58, 'posr-20181022-032723', 1, 11, 2, 1, 2, 2, 0, 100, 1220, 1220, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 1220, NULL, NULL, '2018-10-22 09:27:23', '2018-10-22 09:27:23'),
(73, 'posr-20181023-071543', 11, 11, 1, 5, 2, 5, 0, 500, 5500, 5500, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 5500, NULL, NULL, '2018-10-23 01:15:43', '2018-10-23 01:15:43'),
(74, 'posr-20181023-071644', 1, 11, 2, 1, 3, 3, 0, 200, 2320, 2320, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 2320, NULL, NULL, '2018-10-23 01:16:44', '2018-10-23 01:16:44'),
(75, 'posr-20181101-050027', 1, 11, 2, 1, 5, 12, 0, 626.96, 6980, 7678, 10, 698, NULL, NULL, NULL, NULL, 1, 4, NULL, 7678, NULL, NULL, '2018-10-31 23:00:27', '2018-10-31 23:00:27'),
(76, 'posr-20181101-050126', 1, 11, 2, 1, 3, 6, 0, 100, 1434, 1424, 0, 0, 10, NULL, NULL, 0, 1, 4, NULL, 1424, NULL, NULL, '2018-10-31 23:01:26', '2018-11-08 03:44:51'),
(79, 'posr-20181105-091516', 1, 11, 2, 1, 7, 52, 0, 1069.57, 14454, 14454, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 14454, NULL, NULL, '2018-11-05 03:15:16', '2018-11-05 03:15:16'),
(80, 'posr-20181105-091958', 1, 11, 2, 1, 3, 8, 0, 191.3, 2500, 2500, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 2500, NULL, NULL, '2018-11-05 03:19:58', '2018-11-05 03:19:58'),
(86, 'posr-20181105-095948', 1, 11, 2, 1, 1, 1, 0, 100, 1100, 1100, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 1100, NULL, NULL, '2018-11-05 03:59:48', '2018-11-05 03:59:48'),
(88, 'posr-20181105-100258', 1, 11, 2, 1, 1, 1, 0, 100, 1100, 1100, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 1100, NULL, NULL, '2018-11-05 04:02:58', '2018-11-05 04:02:58'),
(94, 'posr-20181126-020534', 1, 11, 2, 1, 1, 1, 0, 15.65, 120, 120, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 120, NULL, NULL, '2018-11-26 08:05:34', '2018-11-26 08:05:34'),
(95, 'posr-20181127-093608', 1, 11, 2, 1, 1, 3, 0, 0, 360, 360, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, '2018-11-27 03:36:08', '2018-11-27 03:36:08'),
(96, 'posr-20181128-071509', 1, 11, 2, 1, 1, 1, 0, 15.65, 120, 132, 10, 12, NULL, NULL, NULL, NULL, 1, 4, NULL, 132, NULL, NULL, '2018-11-28 01:15:09', '2018-11-28 01:15:09'),
(97, 'posr-20181201-060518', 1, 11, 2, 1, 2, 3, 0, 31.3, 262, 262, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 200, NULL, NULL, '2018-12-01 00:05:18', '2018-12-04 00:21:05'),
(98, 'posr-20181205-053558', 1, 11, 2, 1, 2, 4, 0, 0, 800, 800, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 800, NULL, NULL, '2018-12-04 23:35:58', '2018-12-04 23:35:58'),
(99, 'posr-20181205-053719', 1, 11, 1, 1, 2, 4, 0, 0, 800, 800, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 800, NULL, NULL, '2018-12-04 23:37:19', '2018-12-04 23:37:19'),
(101, 'posr-20181208-062026', 1, 11, 2, 1, 1, 1, 0, 0, 100, 100, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 100, NULL, NULL, '2018-12-08 00:20:26', '2018-12-08 00:20:26'),
(103, 'posr-20181224-045832', 1, 11, 2, 1, 1, 1, 0, 15.65, 120, 120, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 120, NULL, NULL, '2018-12-23 22:58:32', '2018-12-23 22:58:32'),
(104, 'sr-20181224-091527', 1, 1, 1, 2, 2, 6, 0, 0, 2508, 2518, 0, 0, 0, NULL, NULL, 10, 1, 2, NULL, NULL, NULL, NULL, '2018-12-24 03:15:27', '2018-12-24 21:55:23'),
(105, 'posr-20190101-054538', 1, 1, 2, 1, 1, 1, 0, 0, 21, 21, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 21, NULL, NULL, '2018-12-31 23:45:38', '2018-12-31 23:45:38'),
(106, 'posr-20190101-091040', 1, 11, 2, 1, 3, 5, 0, 15.65, 860, 860, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 860, NULL, NULL, '2019-01-01 03:10:40', '2019-01-01 03:10:40'),
(107, 'posr-20190103-065626', 1, 11, 2, 1, 6, 10, 0, 395.65, 5040, 5040, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 5040, NULL, NULL, '2019-01-03 00:56:26', '2019-01-03 00:56:26'),
(108, 'posr-20190120-035824', 1, 11, 2, 1, 1, 1, 0, 15.65, 120, 120, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 120, NULL, NULL, '2019-01-20 09:58:24', '2019-01-20 09:58:24'),
(109, 'posr-20190129-101443', 9, 11, 1, 5, 2, 2, 0, 40, 540, 540, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 540, NULL, NULL, '2019-01-29 04:14:43', '2019-01-29 04:14:43'),
(110, 'posr-20190129-115041', 9, 11, 1, 5, 2, 3, 0, 100, 1700, 1700, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 1700, NULL, NULL, '2019-01-29 05:50:41', '2019-01-29 05:50:41'),
(111, 'posr-20190131-110839', 9, 11, 1, 5, 2, 2, 0, 0, 271, 271, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 271, NULL, NULL, '2019-01-31 05:08:39', '2019-01-31 05:08:39'),
(112, 'posr-20190202-104045', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 440, NULL, NULL, '2019-02-02 04:40:45', '2019-02-02 04:40:45'),
(113, 'posr-20190202-114117', 1, 11, 2, 1, 2, 2, 0, 0, 350, 350, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 350, NULL, NULL, '2019-02-02 05:41:17', '2019-02-02 05:41:17'),
(114, 'posr-20190205-030445', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 440, NULL, NULL, '2019-02-05 09:04:45', '2019-02-05 09:04:45'),
(118, 'posr-20190207-111542', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 3, 2, NULL, NULL, NULL, NULL, '2019-02-07 05:15:42', '2019-02-07 05:15:42'),
(120, 'sr-20190207-114036', 1, 1, 1, 2, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, 50, NULL, NULL, '2019-02-07 05:40:36', '2019-02-07 07:09:15'),
(121, 'posr-20190209-104814', 1, 11, 2, 1, 7, 17, 0, 55.65, 1272, 1272, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 1272, NULL, NULL, '2019-02-09 04:48:14', '2019-02-09 04:48:14'),
(123, 'posr-20190219-023214', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 440, NULL, NULL, '2019-02-19 08:32:14', '2019-02-19 08:32:14'),
(127, 'posr-20190303-104010', 1, 11, 2, 1, 3, 3, 0, 200, 2500, 2500, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 2500, NULL, NULL, '2019-03-03 04:40:10', '2019-03-03 04:40:10'),
(128, 'posr-20190404-095555', 1, 11, 2, 1, 2, 2, 0, 55.65, 560, 560, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 560, NULL, NULL, '2019-04-04 03:55:55', '2019-04-04 03:55:55'),
(129, 'posr-20190404-095937', 1, 11, 2, 1, 1, 2, 0, 0, 240, 240, 0, 0, 0, NULL, NULL, 0, 1, 2, NULL, 120, NULL, NULL, '2019-04-04 03:59:37', '2019-04-11 04:50:16'),
(130, 'posr-20190421-122124', 1, 11, 2, 1, 3, 3, 0, 58.78, 586, 586, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 586, NULL, NULL, '2019-04-21 06:21:24', '2019-04-21 06:21:24'),
(131, 'posr-20190528-103229', 1, 11, 2, 1, 4, 4, 0, 240, 2890, 2890, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 2890, NULL, NULL, '2019-05-28 04:32:29', '2019-05-28 04:32:29'),
(132, 'posr-20190613-101637', 1, 11, 2, 1, 3, 3, 0, 40, 840, 840, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 840, NULL, NULL, '2019-06-13 04:16:37', '2019-06-13 04:16:37'),
(133, 'posr-20190613-101751', 1, 11, 2, 1, 3, 4, 0, 200, 2700, 2700, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 2700, NULL, NULL, '2019-06-13 04:17:51', '2019-06-13 04:17:51'),
(134, 'posr-20191019-033028', 1, 11, 2, 1, 4, 4, 0, 240, 2940, 2940, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 2940, NULL, NULL, '2019-10-19 09:30:28', '2019-10-19 09:30:28'),
(138, 'sr-20191031-122937', 1, 1, 1, 1, 1, 1, 0, 0, 120, 120, 0, 0, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, '2019-10-31 06:29:37', '2019-10-31 06:29:37'),
(139, 'posr-20191103-114044', 1, 11, 2, 1, 2, 102, 0, 37.57, 488, 488, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 488, NULL, NULL, '2019-11-03 05:40:44', '2019-11-03 05:40:44'),
(144, 'posr-20191109-074131', 1, 11, 2, 1, 2, 2, 0, 100, 1220, 1220, 0, 0, 0, NULL, NULL, 0, 1, 4, NULL, 1220, NULL, NULL, '2019-11-09 13:41:31', '2019-11-09 13:41:31'),
(147, 'posr-20191111-104008', 1, 11, 2, 1, 3, 12, 0, 200, 2220, 2220, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 2220, NULL, NULL, '2019-11-11 04:40:08', '2019-11-11 04:40:08'),
(172, 'posr-20191203-034631', 1, 11, 2, 1, 1, 1, 0, 40, 440, 440, 0, 0, NULL, NULL, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, '2019-12-03 09:46:31', '2019-12-03 09:46:31'),
(173, 'sr-20191204-111940', 1, 2, 1, 1, 2, 2, 0, 36, 621, 621, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 621, NULL, NULL, '2019-12-04 17:19:40', '2019-12-05 03:27:12'),
(187, 'posr-20191222-104058', 1, 11, 2, 1, 1, 2, 0, 37.57, 288, 288, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 288, NULL, NULL, '2019-12-22 04:40:58', '2019-12-22 04:40:58'),
(190, 'posr-20191223-125946', 1, 11, 2, 1, 1, 1, 0, 100, 1100, 1100, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 1100, NULL, NULL, '2019-12-23 06:59:46', '2019-12-23 06:59:46'),
(193, 'posr-20200101-022028', 1, 11, 2, 1, 1, 1, 0, 100, 1100, 1100, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 1100, NULL, NULL, '2020-01-01 08:20:28', '2020-01-01 08:20:28'),
(194, 'posr-20200102-043947', 1, 11, 2, 1, 2, 3, 0, 81.57, 892, 892, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 892, NULL, NULL, '2020-01-02 10:39:47', '2020-01-02 10:39:47'),
(201, 'posr-20200203-035256', 1, 11, 2, 1, 1, 1, 0, 0, 120, 120, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 120, NULL, NULL, '2020-02-03 09:52:56', '2020-02-03 09:52:56'),
(202, 'posr-20200204-105853', 1, 11, 2, 1, 2, 2, 0, 100, 1400, 1400, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 1400, NULL, NULL, '2020-02-04 16:58:53', '2020-02-04 16:58:53'),
(203, 'posr-20200302-115414', 1, 11, 2, 1, 2, 2, 0, 0, 350, 350, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 350, NULL, NULL, '2020-03-02 05:54:14', '2020-03-02 05:54:14'),
(204, 'posr-20200302-115741', 1, 11, 2, 1, 1, 20, 0, 0, 40, 40, 0, 0, NULL, NULL, NULL, NULL, 1, 4, NULL, 40, NULL, NULL, '2020-03-02 05:57:41', '2020-03-02 05:57:41'),
(205, 'posr-20200311-044641', 1, 11, 2, 1, 1, 1, 0, 40, 440, 352, 0, 0, NULL, 1, 88, NULL, 1, 4, NULL, 352, NULL, NULL, '2020-03-11 10:46:42', '2020-03-11 10:46:42'),
(206, 'sr-20200311-045230', 1, 1, 1, 1, 1, 1, 0, 0, 120, 120, 0, 0, 0, NULL, NULL, 0, 1, 2, NULL, NULL, NULL, NULL, '2020-03-11 10:52:30', '2020-03-11 10:54:04'),
(207, 'posr-20200406-074024', 1, 11, 2, 1, 3, 4, 0, 18.78, 644, 644, 0, 0, 0, NULL, NULL, 0, 1, 4, NULL, 644, NULL, NULL, '2020-04-06 13:40:24', '2020-04-06 13:42:01');

-- --------------------------------------------------------

--
-- Table structure for table `stock_counts`
--

CREATE TABLE `stock_counts` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `category_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initial_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_adjusted` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock_counts`
--

INSERT INTO `stock_counts` (`id`, `reference_no`, `warehouse_id`, `category_id`, `brand_id`, `user_id`, `type`, `initial_file`, `final_file`, `note`, `is_adjusted`, `created_at`, `updated_at`) VALUES
(1, 'scr-20190228-124939', 2, NULL, NULL, 1, 'full', '20190228-124939.csv', NULL, NULL, 0, '2019-02-28 06:49:39', '2019-02-28 06:49:39'),
(2, 'scr-20210216-031524', 1, NULL, NULL, 18, 'full', '20210216-031524.csv', NULL, NULL, 0, '2021-02-16 09:45:24', '2021-02-16 09:45:24');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vat_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `image`, `company_name`, `vat_number`, `email`, `phone_number`, `address`, `city`, `state`, `postal_code`, `country`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'abdullah', 'globaltouch.jpg', 'global touch', NULL, 'abdullah@globaltouch.com', '231231', 'fsdfs', 'fsdfs', NULL, NULL, 'bd', 0, '2018-05-12 22:06:34', '2021-03-12 08:38:08'),
(2, 'test', 'lion.jpg', 'lion', NULL, 'lion@gmail.com', '242', 'gfdg', 'fgd', NULL, NULL, NULL, 0, '2018-05-29 23:59:41', '2018-05-30 00:00:06'),
(3, 'ismail', NULL, 'Testing Company', NULL, 'test@gmail.com', '9960664553', 'Pune', 'Pune', 'Maharashtra', '412105', 'India', 1, '2018-07-20 04:34:17', '2021-03-12 08:38:52'),
(4, 'modon', 'mogaFruit.jpg', 'mogaFruit', NULL, 'modon@gmail.com', '32321', 'nasirabad', 'chittagong', NULL, NULL, 'bd', 0, '2018-09-01 04:30:07', '2018-09-01 04:37:20');

-- --------------------------------------------------------

--
-- Table structure for table `taxes`
--

CREATE TABLE `taxes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` double NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `taxes`
--

INSERT INTO `taxes` (`id`, `name`, `rate`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'vat@10', 10, 1, '2018-05-12 09:58:30', '2019-03-02 11:46:10'),
(2, 'vat@15', 15, 1, '2018-05-12 09:58:43', '2018-05-27 23:35:05'),
(4, 'vat 20', 20, 1, '2018-09-01 00:58:57', '2021-04-05 08:10:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_branch`
--

CREATE TABLE `tbl_branch` (
  `fd_branch_id` int(11) NOT NULL,
  `fd_branch_name` varchar(255) NOT NULL,
  `fd_company_id` int(11) NOT NULL,
  `fd_address` longtext NOT NULL,
  `fd_address1` longtext NOT NULL,
  `fd_address2` longtext NOT NULL,
  `fd_city` varchar(255) NOT NULL,
  `fd_state` varchar(255) NOT NULL,
  `fd_country` varchar(255) NOT NULL,
  `fd_pincode` varchar(20) NOT NULL,
  `fd_stdcode` varchar(20) NOT NULL,
  `fd_phone1` varchar(15) NOT NULL,
  `fd_phone2` varchar(15) NOT NULL,
  `fd_fax` varchar(15) NOT NULL,
  `fd_cpname` varchar(255) NOT NULL,
  `fd_mobile1` varchar(15) NOT NULL,
  `fd_mobile2` varchar(15) NOT NULL,
  `fd_email1` varchar(100) NOT NULL,
  `fd_email2` varchar(100) NOT NULL,
  `fd_url` varchar(200) NOT NULL,
  `fd_panno` varchar(20) NOT NULL,
  `fd_staxno` varchar(50) NOT NULL,
  `fd_pfcode` varchar(20) NOT NULL,
  `fd_esicode` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_branch`
--

INSERT INTO `tbl_branch` (`fd_branch_id`, `fd_branch_name`, `fd_company_id`, `fd_address`, `fd_address1`, `fd_address2`, `fd_city`, `fd_state`, `fd_country`, `fd_pincode`, `fd_stdcode`, `fd_phone1`, `fd_phone2`, `fd_fax`, `fd_cpname`, `fd_mobile1`, `fd_mobile2`, `fd_email1`, `fd_email2`, `fd_url`, `fd_panno`, `fd_staxno`, `fd_pfcode`, `fd_esicode`, `created_at`, `updated_at`) VALUES
(1, 'Pune - Perfect Protection', 2, 'Testing address', 'address', '', 'Pune', 'Maharashtra', 'India', '412115', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2021-03-18 03:35:09', '2021-04-05 09:37:16'),
(3, 'Pune - Care', 3, 'TEst', 'asdda', 'asdasd', 'asd', 'asdas', 'asdas', 'asda', 'asdas', '', '', '', '', '', '', '', '', '', '', '', '', '', '2021-03-18 05:50:32', '2021-04-05 09:37:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_client`
--

CREATE TABLE `tbl_client` (
  `client_id` int(11) NOT NULL,
  `client_code` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `comp_code` varchar(20) NOT NULL,
  `branch_code` varchar(20) NOT NULL,
  `catgcode` varchar(20) NOT NULL,
  `person` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `areacode` varchar(20) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `address3` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `statecode` varchar(20) NOT NULL,
  `countrycode` varchar(20) NOT NULL,
  `pin` varchar(10) NOT NULL,
  `email1` varchar(255) NOT NULL,
  `email2` varchar(255) NOT NULL,
  `phone1` varchar(20) NOT NULL,
  `phone2` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_client`
--

INSERT INTO `tbl_client` (`client_id`, `client_code`, `name`, `comp_code`, `branch_code`, `catgcode`, `person`, `mobile`, `areacode`, `address1`, `address2`, `address3`, `city`, `statecode`, `countrycode`, `pin`, `email1`, `email2`, `phone1`, `phone2`, `fax`, `status`, `created`, `updated`) VALUES
(5, 'cl-20210405-977612', 'Second Client', '2', '1', '1', 'adsasd', '878787', '1', '878987', '', '', 'asdasd', 'asda', 'asdas', '65665', '', '', '', '', '', '2', '2021-04-05 11:13:08', '2021-04-05 11:13:08'),
(6, 'A00050', 'ASSOCIATED CAPSULES LTD.-SHIRWAL', '1', '1', '7', '', '0', '9', 'GUT NO : 322,323, SHINDEWADI, KHANDALA,', 'SHIRWAL', '', 'PUNE', '1', 'India', '0', '', '', '646723', '644379', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(7, 'A00051', 'ASSOCIATED CAPSULES LTD.-PACK SHIELD DIVISION', '1', '1', '7', '', '0', '9', 'GUT NO : 322,323, SHINDEWADI, KHANDALA,', 'SHIRWAL', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(8, 'A00052', 'ARCHIES LTD - HO', '1', '1', '7', '', '0', '16', '461/4, TILAK ROAD,  SADASHIV PETH, OPP:', 'NEW ENGLISH SCHOOL, PUNE - 30.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(9, 'A00055', 'ASSOCIATED CAPSULES PVT. LTD.-CHAKAN', '1', '1', '7', '', '0', '7', 'GAT NO : 222, MAHALUNGE, TALEGAON CHAKAN', 'ROAD, TAL. KHED, DIST. PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(10, 'A00056', 'AMMUNITION FACTORY  KIRKEE-RIGIONAL MARKETING', '1', '1', '7', '', '0', '10', 'KIRKEE, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(11, 'A00057', 'AMMUNITION FACTORY  KIRKEE-RCS OFFICE', '1', '1', '7', '', '0', '10', 'KIRKEE, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(12, 'A00058', 'AMMUNITION FACTORY  KIRKEE-CSD CANTEEN (RANGE HILL ESTATE)', '1', '1', '7', '', '0', '10', 'KIRKEE, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(13, 'A00059', 'AMMUNITION FACTORY  KIRKEE-PETROL PUMP', '1', '1', '7', '', '0', '10', 'KIRKEE, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(14, 'A00062', 'ARCHIES GALLARY NUCLES BUILDING(CAMP)-NUCLES BUILDING', '1', '1', '7', '', '0', '14', '461/4 TILAK ROAD,SADASHIVE PETH, PUNE.', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(15, 'A00063', 'ARCHIES GALLARY MARIPLEX (KALYANI NAGAR)-KALYANI NAGAR', '1', '1', '7', '', '0', '22', '461/4,TILAK ROAD SADASHIVE PETH, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(16, 'A00064', 'ARCHIES GALLARY ICC (SENAPATI BAPAT ROAD)-SENAPATI BAPAT', '1', '1', '7', '', '0', '3', '461/4, TILAK ROAD SADASHIV PETH, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(17, 'A00067', 'ASHA MITTAL-HO', '1', '1', '7', '', '0', '2', 'SAI LAXMI 208 SINDH SOCIETY PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(18, 'A00069', 'ANKIT ENTERPRISES ( KOLTE PATIL ) - LAPIZ LAZULI', '1', '1', '2', 'NA', '0', '22', 'CITY POINT BOAT CLUB ROAD', 'SOUTH MAIN ROAD SANAR COLONY', 'KOREGAON PARK', 'PUNE', '1', 'India', '411001', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(19, 'A00070', 'ASK ENGINEERS', '1', '1', '1', 'MR.SANTOSH HEGADE', '0', '7', 'PLOT NO 267,269 AND 270, SECTOR - 10,', 'PCNTDA,', 'BHOSARI,', 'PUNE', '1', 'India', '411020', 'ajay@askenggrs.com', '', '9921161119', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(20, 'A00071', 'ADVIK HI-TECH PRIVATE LIMITED', '1', '1', '1', 'MR.AVDHOOT DESAI', '9561096187', '1', 'GUT NO.357/99, CHAKAN-TALEGAON ROAD,', 'KHARAB WADI, CHAKAN,', 'TAL - KHED,', 'PUNE', '1', 'India', '0', 'hr104@advik.co.in', '', '0', '0', '2135669501', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(21, 'B00020', 'BOMBAY CYCLE AND MOTORS AGENCY PUNE-HO', '1', '1', '7', '', '0', '14', '6, MOLEDINAROAD, PUNE - 411001.', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(22, 'B00021', 'ARMAPRO SECURITY SERVICES PVT LTD', '1', '1', '7', '', '0', '22', '12- A VICTORIA ROAD, GHORPHADI PUNE - 1', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(23, 'B00022', 'BANK OF MAHARASHTRA-BANK HOUSE', '1', '1', '7', '', '0', '3', 'MODEL COLONY,', 'SHIVAJINAGAR, PUNE 5', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(24, 'B00023', 'BANK OF MAHARASHTRA-MAHA BANK HOUSE', '1', '1', '7', '', '0', '16', 'BANK OF MAHARASHTRA, CENTRAL OFFICE LOKM', 'NAGAL 1501, SHIVAJI NAGAR, PUNE- 411005', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(25, 'B00024', 'BANK OF MAHARASHTRA (VIDYA VILAS)-NA', '1', '1', '7', '', '0', '3', 'BOM CENTRAL OFFICE, LOKMANGAL, 1501, SHI', 'VAJINAGAR, PUNE - 411 005', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(26, 'B00025', 'BRINKS ARYA ( I) P LTD (KOLHAPUR)-KOLHAPUR', '1', '1', '7', '', '0', '17', '12-A, LBS MARG, GHORPADI, PUNE - 1', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(27, 'B00026', 'BHOSLE ESTATE-KOLHAPUR', '1', '1', '7', '', '0', '17', 'NA', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(28, 'B00027', 'BRINKS  ARYA (QULLON)-HO', '1', '1', '7', '', '0', '6', 'KOREGAON PARK, OPP. BLIND SCHOOL,', '', '', 'PUNE', '1', 'India', '0', '', '', '6124390', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(29, 'B00028', 'BAL PHARMA LTD.-HO', '1', '1', '7', '', '0', '9', 'UNIT III, VILL. KUNJAL, AT PO NH NO.4,', 'TAL. BHOR, DIST. PUNE 412217', '', 'PUNE', '1', 'India', '0', '', '', '952113282404', '282362', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(30, 'B00029', 'BAGEECHA GLADES PVT. LTD. (LOCATION: K NAGAR PLOT)-HO', '1', '1', '7', '', '0', '22', 'DESAI HOUSE 177/2, DHOLE PATIL ROAD,', 'PUNE-411001', '', 'PUNE', '1', 'India', '0', '', '', '26131105', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(31, 'B00030', 'BANK OF MAHARASHTRA-HEAD OFFICE', '1', '1', '7', '', '0', '16', 'LOKMANGAL, GANESHKHIND ROAD, SHIVAJINAGA', 'R, PUNE 5', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(32, 'B00031', 'BANK OF MAHARASHTRA-KOTHRUD (DAHANUKAR)', '1', '1', '7', '', '0', '3', 'LOKMANGAL, GANESHKHIND ROAD, SHIVAJINAGA', 'R, LANE N0-3', 'PUNE-3', 'PUNE', '1', 'India', '0', '', '', '25537215', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(33, 'B00032', 'BANK OF MAHARASHTRA-KONDHWA', '1', '1', '7', '', '0', '5', 'RURAL REGIONAL OFFICE, 568, NARAYAN PETH', ', PUNE- 4110 30', '', 'PUNE', '1', 'India', '0', '', '', '24459184', '0', '24454458', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(34, 'B00033', 'BANK OF MAHARASHTRA (BARAMATI)-BARAMATI BRANCH', '1', '1', '5', '', '0', '14', 'PUNE RURAL REGIONAL OFFICE, 568, NARAYAN', 'PETH, PUNE 411030', '', 'PUNE', '1', 'India', '0', '', '', '24459187', '2112225200', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(35, 'B00034', 'BANK OF MAHARASHTRA.-(MAHA BANK HOUSE) PRABHAT ROAD', '1', '1', '7', '', '0', '3', 'LANE NO.9, PRABHAT ROAD,', 'PUNE 4', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(36, 'B00035', 'BANK OF MAHARASHTRA  (WAKHI BRANCH)-NA', '1', '1', '7', '', '0', '3', 'BOM CENTRAL OFFICE, LOKMANGAL, 1501, SHI', 'VAJINAGAR, PUNE - 411 005', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(37, 'B00036', 'BANK OF MAHARASHTRA WAKHI (CHAKAN)-HO', '1', '1', '5', 'CEPT. NAIR HR', '9561322022', '7', 'CHAKAN, PUNE', '', 'PUNE WEST ZONE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(38, 'B00037', 'BEDEKAR PICKLES PVT. LTD. KARJAT-LABOUR', '1', '1', '7', '', '0', '7', 'BEDEKAR SADAN NO.3, TATYA GHURPURE PETH,', 'MUMBAI - 400004', '', 'PUNE', '1', 'India', '0', '', '', '952148223431', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(39, 'B00038', 'BEDEKAR PICKLES PVT. LTD. KARJAT-GUARD', '1', '1', '7', '', '0', '7', 'BEDEKAR SADAN NO.3, TATYA GHURPURE PETH,', 'MUMBAI - 400004', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(40, 'B00039', 'BANK OF MAHARASHTRA  IT  TOWER-KHARADI', '1', '1', '7', '', '0', '22', 'LOKMANGAL, GANESH KHIND ROAD, SHIVAJI NA', 'GAR, PUNE 5', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(41, 'B00040', 'BANK OF MAHARASHTRA (SINDH SOCIETY)-HO', '1', '1', '7', '', '0', '2', 'SINDH SOCIETY, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(42, 'B00041', 'BANK OF MAHARASHTRA  (PADMA REKHA)-HO', '1', '1', '7', '', '0', '3', 'PADMAREKHA GRUHARACHANA SAHAKARI SANSTHA', ', PLOT NO.29, SURVEY NO.25, KARVENAGAR,', 'PUNE 52', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(43, 'B00042', 'BEKAERT INDUSTRIES LTD.-HO', '1', '1', '7', '', '0', '2', 'SAI TRINITY, CENTRAL WING,', 'S.NO.146, PASHAN PUNE', '', 'PUNE', '1', 'India', '411021', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(44, 'B00043', 'BANK OF MAHARASHTRA  STAFF TRAINING COLLEGE-HO', '1', '1', '7', '', '0', '3', 'GALI NO.11, PRABHAT ROAD, DECCAN GYMKHAN', 'A, PUNE 4.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(45, 'B00044', 'BELSARE INDUSTRIES-HO', '1', '1', '7', '', '0', '7', 'PLOT NO.S.21, T BLOCK, MIDC BHOSARI, PUN', 'E 26', '', 'PUNE', '1', 'India', '0', '', '', '32531951', '0', '27129763', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(46, 'B00045', 'BANK OF MAHARASHTRA (KARVE ROAD)-HO', '1', '1', '7', '', '0', '3', 'LOKMANGAL, GANESHKHIND ROAD, SHIVAJINAGA', 'R, PUNE 5', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(47, 'B00046', 'BHIKSHU GRANIMART-HO', '1', '1', '7', '', '25814561', '16', 'BULDG.  A 3 FLAT NO.101 KOHINOOR ESTATE,', 'MULAROAD KHADKI PUNE 411003', '', 'PUNE', '1', 'India', '0', '', '', '2581837071', '25816227', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(48, 'B00047', 'BOSCH LIMITED-HO', '1', '1', '7', '', '0', '3', 'DEMECH HOUSE, IST FLOOR, 814, LAW COLLEG', 'E ROAD, PUNE 411004', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(49, 'B00048', 'BADRI TAHERBHAI POONAWALA', '1', '1', '1', '', '0', '5', '93, MG ROAD, PUNE 411001', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(50, 'B00049', 'BANK OF MAHARASHTRA (KALYANI NAGAR)', '1', '1', '5', '', '0', '22', 'PUNE REGION OFFICE', 'KALYANINAGAR PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(51, 'B00050', 'BANK OF MAHARASHTRA (KASBA PETH)', '1', '1', '5', 'MR. PAWAR BRANCH MAN', '0', '16', 'PUNE REGION OFFICE, 568,', 'NARAYAN PETH, PUNE 30', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(52, 'B00051', 'BADRI TAHERBHAI POONAWALA', '1', '1', '7', '', '0', '5', '93, M G ROAD, PUNE 1', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(53, 'B00052', 'BANK OF MAHARASHTRA  (BHOSARI)', '1', '1', '5', '', '0', '7', 'BHOSARI, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(54, 'B00053', 'B K LOGISTICS', '1', '1', '7', '', '0', '7', 'ROOM NO. 7, 2ND FLOOR,', 'RAGHUNANDAN APARTMENT,', 'RAMNAGAR, BHOSARI,PUNE 411 026.', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(55, 'B00055', 'BOSCH LIMITED (CHAKAN )', '1', '1', '7', 'VENKATRAO P', '0', '7', 'CHAKAN', '', '', 'PUNE', '1', 'India', '0', 'VENKAT.RAO@INBOSCH.COM', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(56, 'B00056', 'BANK OF MAHARASHTRA (PASHAN)', '1', '1', '5', 'NA', '0', '1', 'LOKMANGAL 1183 FC ROAD, SHIVAJINAGAR,', 'PUNE', '', 'PUNE', '1', 'India', '0', '0', '0', '25530861', '0', '25510812', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(57, 'B00057', 'BANK OF MAHARASHTRA ( BAVDHAN )', '1', '1', '5', 'NA', '0', '1', 'LOKMANGAL 1183 F C ROAD', 'SHIVAJI NAGAR PUNE', '', 'PUNE', '1', 'India', '0', '', '', '25530861', '25510812', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(58, 'B00058', 'BANK OF MAHARASHTRA (LOKMANGAL)', '1', '1', '5', 'CAPT.SHARMA', '0', '3', 'LOKMANGA, GANESHKIND ROAD', 'SHIVAJINAGAR, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(59, 'B00059', 'BANK OF MAHARASHTRA (PIMPRI)', '1', '1', '7', 'MR.SANE', '0', '7', 'BANK OF MAHARASHTRA,PIMPRI', '', '', 'PUNE', '1', 'India', '0', '0', '0', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(60, 'B00060', 'BANK OF MAHARASHTRA (BAJIRAO ROAD)', '1', '1', '5', 'CAPT.NAIR', '0', '16', 'PUNE RURAL RIGIONAL OFFICE,568,', 'NARAYAN PETH,PUNE 30', '', 'PUNE', '1', 'India', '411030', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(61, 'B00061', 'BEKAERT INDUSTRIES PVT. LTD. (BENG)', '1', '1', '1', 'SHRIKANT SUTAR', '0', '2', 'SAI TRINITY BLDG, A WING', '5TH FLOOR, PASHAN, PUNE', 'PASHAN PUNE', 'PUNE', '1', 'India', '411021', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(62, 'B00062', 'BANK OF MAHARASHTRA (NIBM ROAD)', '1', '1', '5', 'MR.PANDARE', '26833745', '5', 'YASHOMANGAL, 1183A FC ROAD', 'SHIVAJINAGAR, PUNE', '', 'PUNE', '1', 'India', '411005', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(63, 'B00063', 'BOSCH LIMITED  HO (K-P)', '1', '1', '7', '', '0', '22', 'GODREJ MILLENIUM 3 RD FLOOR', 'KOREGAON PARK PUNE 411001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(64, 'B00064', 'BRAMHA BAUG CO- OP HOUSING SOCIETY LTD', '1', '1', '1', 'MR BEHALI', '9730009968', '22', 'BT KAVADE ROAD PO MUNDHWA PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(65, 'B00065', 'BANK OF MAHARASHTRA (LULLA NAGAR) KONDWA', '1', '1', '5', 'SHAH', '9823556246', '5', 'BANK OF MAHARASHTRA', 'LULLA NAGAR BRANCH,SALUNKE VIHAR ROAD', 'MARUTI SERVICE STN BLDG, WANDWADI', 'PUNE', '1', 'India', '411040', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(66, 'B00066', 'BRINKS ARYA INDIA PVT. LTD-  (FOR O.T.  OF GUNMAN & DRIVER ONLY)', '1', '1', '1', '', '0', '2', '12- A VICTORIA ROAD, GHORPHADI', 'PUNE - 1', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(67, 'B00067', 'BRINKS INDIA PVT. LTD-HO DECCAN', '1', '1', '7', 'ATUL', '0', '2', '', '', '', 'PUNE', '1', 'India', '0', 'amrut.sankpal@brinksglobal.com', '', '25884155', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(68, 'B00068', 'BERG AND SCHMIDT INDIA PVT LTD', '1', '1', '7', 'RAJESH AGNIHOTRI', '9325002886', '3', 'KASTROKING INDIA PVT LTD THE SYNERGY', '2 ND FLOOR PLOT NO 70/2 2ND FLOOR PUNE', '', 'PUNE', '1', 'India', '0', 'ragnihotri@giiava.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(69, 'C00039', 'CENTURIAN BANK (ALL ATM)-NIGDI', '1', '1', '7', '', '0', '7', 'CENTURIAN BANK SECTOR 25, SINDHU NAGAR,', 'PRADHIKARAN NIGDI PUNE - 19', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(70, 'C00041', 'CENTURIAN BANK (ALL ATM)-DHANUKAR COLONY', '1', '1', '7', '', '0', '3', 'CENTURIAN BANL LTD. MUMBAI ROAD, PIMPRI', 'ATM 5, GANGA CASCADE NORTH MAIN ROAD, KO', 'REGAON PARK.', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(71, 'C00042', 'CENTURIAN BANK (ALL ATM)-PIMPRI', '1', '1', '7', '', '0', '7', 'NEAR VISHAL THEATRE, PIMPRI  PUNE.', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(72, 'C00043', 'CENTURIAN BANK (ALL ATM)-FATIMA NAGAR', '1', '1', '7', '', '0', '5', 'CENTURIAN BANK LTD. MUMBAI PUNE ROAD, PI', 'MPRI SHOP N. 9 LAXMI CO-OP HOUSING SHIVA', 'RKAR ROAD. WANORI.', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(73, 'C00044', 'CENTURIAN BANK (ALL ATM)-MODEL COLONY', '1', '1', '7', '', '0', '16', 'NEAR VISHAL THEATRE, PIMPRI  PUNE.', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(74, 'C00045', 'CENTURIAN BANK (ALL ATM)-(( F C ROAD ))', '1', '1', '7', '', '0', '22', 'CENTURIAN BANK 2ND FLOOR F C ROAD PUNE 4', 'SITE ADD MAGAR PATTA CITY HADAPSAR MUN', 'DHWA', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(75, 'C00046', 'CHORADIA FOODS PRODUCTS LTD.-HO', '1', '1', '7', '', '0', '9', 'GAT NO. 399/400, SHIRWAL SATARA ROAD, TA', 'L. KHANDALA, DIST. SATARA', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(76, 'C00047', 'CHIEF COMM. OF INCOME TAX-BHANUVIALAS', '1', '1', '7', '', '0', '16', 'LANE NO.14, PRABHAT ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(77, 'C00048', 'CHIEF COMM. OF INCOME TAX-BRAHMA METAL', '1', '1', '7', '', '0', '22', 'SADHU WASWANI CHOWK,', 'MG ROAD, PUNE', '411001', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(78, 'C00049', 'CHIEF COMM. OF INCOME TAX-MANJRI FIRM', '1', '1', '7', '', '0', '22', 'LANE NO. 14, PRABHAT ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(79, 'C00050', 'CHIEF COMM. OF INCOME TAX-OFFICE', '1', '1', '7', '', '0', '5', 'NA', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(80, 'C00051', 'CORPOHOME BANK-HO', '1', '1', '7', '', '0', '3', 'BOMBAY PUNE ROAD, WAKDEWAD PUNE.', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(81, 'C00052', 'CHAMPION SEALS (INDIA) PVT. LTD-HO', '1', '1', '7', '', '0', '7', '18 PARSI PANCHAYAT ROAD, ANDHERI (EAST)', 'MUMBAI - 400069', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(82, 'C00054', 'CHEFSET HOUSE WARE PRIVATE LTD.-GUARD', '1', '1', '7', '', '0', '1', 'GATE NO. 605/1 PIRANGUT VILL:-TAL:-MULSH', 'I DIST:-PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(83, 'C00055', 'CARE PRINCIPIUM PVT LTD-HO', '1', '1', '7', '', '0', '22', '5TH FLOOR NYATI MILLENIUM VIMAN NAGAR PU', 'NE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(84, 'C00056', 'CRANE PROCESS FLOW TECHNOLOGIES (I) LTD.-HO', '1', '1', '7', '', '0', '14', '134,/4,  6  ASHOK NAGAR OPP RENJHILLS RO', 'AD PUNE  7', '', 'PUNE', '1', 'India', '0', '', '', '5654452', '0', '5654458', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(85, 'C00057', 'CHIEF COMM. OF INCOME TAX  ((PRABHAT ROAD))-OFFICE', '1', '1', '7', '', '0', '16', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(86, 'C00058', 'COFFEE DAY-HO', '1', '1', '7', '', '0', '17', 'COFFEE DAY ,TARABAI PARK ,KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(87, 'C00059', 'CENTURIAN BANK (( F,C ROAD ))-HO', '1', '1', '7', '', '0', '22', 'CENTURIAN BANK 2ND FLOOR , F C ROAD PUNE', '-4  SITE ADD MAGARPATTA CITY (CYBER CIT', 'Y) HADAP MUNDHWA  P.', 'PUNE', '1', 'India', '0', '', '', '25652533', '26817287', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(88, 'C00060', 'COLD STORAGE-HO', '1', '1', '7', '', '0', '9', 'GAT NO.399/400, SHIRWAL SATARA ROAD, TAL', '. KHANDALA DIST.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(89, 'C00061', 'COSMOS CO-OP BANK LTD.-BANGALORE', '1', '1', '7', '', '0', '23', 'BANGALORE', '', '', 'BANGALORE', '8', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(90, 'C00062', 'CHIEF COMM. OF INCOME TAX (DESHPANDE PROPERTIES)-HO', '1', '1', '7', '', '0', '16', 'NEAR OLD MANIKCHAN HOUSE, JANGALI MAHARA', 'J ROAD, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(91, 'C00063', 'CITY TOWER APARTMENT ASSOCIATION-HO', '1', '1', '7', '', '0', '14', 'BOAT CLUB ROAD PUNE 14', '', '', 'PUNE', '1', 'India', '0', '', '', '26053700', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(92, 'C00064', 'CITY POINT APARTMENT ASSOCIATION-HO', '1', '1', '7', '', '0', '14', 'BOAT CLUB ROAD PUNE 14', '', '', 'PUNE', '1', 'India', '0', '', '', '26053700', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(93, 'C00066', 'COSMOS HEIGHTS-HO', '1', '1', '7', '', '0', '16', 'COSMOS HEIGHTS, SHANIWAR PETH, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(94, 'C00067', 'CLR SERVICES-HO', '1', '1', '7', '', '0', '16', 'PLOT 65,1ST FLOOR, PADMAKUNJ, SHIVAJI NA', 'GAR SOCIRTY PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(95, 'C00068', 'CHAPHEKAR SUSPENSION PVT LTD-H.O.', '1', '1', '7', '', '0', '7', 'J-151, MIDC, BHOSARI, PUNE  411026', '', '', 'PUNE', '1', 'India', '0', '', '', '30683305', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(96, 'C00069', 'CORNER STONE TECHNOLOGIES PVT. LTD-BALEWADI', '1', '1', '7', '', '0', '1', 'S. NO. 2 PLOT 3 SOPAN BAG OPP.BHARTI VID', 'YAPITH,ENGLISH MUDUM SCHOOL, BALEWADI PU', 'NE', 'PUNE', '1', 'India', '0', '', '', '27290617', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(97, 'C00070', 'CENTRAL EXCISE DEPARTMENT-HO', '1', '1', '7', '', '0', '14', '41A, ICE HOUSE, SASOON ROAD, OPP. WADIA', 'COLLEGE, PUNE 1', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(98, 'C00071', 'CITY POINT APRATMENT ASSOCIATION', '1', '1', '7', '', '0', '1', 'BOAD CLUB ROAD', 'PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(99, 'C00072', 'COUPLING ENGINEERING', '1', '1', '7', '', '0', '9', 'KASURDI (K.B.), KHEDSHIVAPUR, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(100, 'C00073', 'CHAIRMAN,NAUKA CO OP HOUSING SOCIRTY', '1', '1', '1', '', '0', '1', 'PLOT NO.29 RAMNAGAR COLONY,', 'BAVDHAN, PUNE21', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(101, 'C00074', 'CHINTAMANI THERMAL TECHNOLOGIES PVT. LTD.', '1', '1', '7', 'MR,. DAHILWALKAR', '9923757129', '22', 'SR. NO 63/1A/3, HANDEWADI ROAD , PUNE', '411028', '', 'PUNE', '1', 'India', '411028', '0', '0', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(102, 'C00075', 'CUBIX MICRO SYSTEM ( I ) PVT LTD ( SINHAGAD ROAD)', '1', '1', '7', 'MANDAR KULKARNI', '0', '3', '3 RD FLOOR MANGALMURTI COMPLEX', 'SINHGAD ROAD', '', 'PUNE', '1', 'India', '0', '0', '0', '24251598', '32508899', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(103, 'C00076', 'CUBIX MICRO SYSTEM ( I ) PVT LTD ( TATHAWADE )', '1', '1', '7', 'NA', '0', '1', 'BH XPS GODAWN NEAR SAI PETROL PUMP', 'TATHAWADE', '', 'PUNE', '1', 'India', '0', '0', '0', '24251598', '32508899', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(104, 'C00077', 'CBS PUBLISHERS AND DISTRIBUTORS PVT.LTD', '1', '1', '1', '', '0', '16', 'BHURUK PRESTIGE SR NO 52/12/2+1+3/2', 'NARHE HAVELI (NEAR DEHU ROAD BY PASS)', 'PUNE 4110051', 'PUNE', '1', 'India', '0', 'pune@cbspd.com', '', '24464057', '24464058', '24464059', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(105, 'C00078', 'CBS PUBLISHERS AND DISTRIBUTORS', '1', '1', '7', '', '0', '5', 'SHAAN BRAHMA COMPLEX BASEMENT I,  APPA B', 'ALWANT CHOWK, PUNE 411002', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(106, 'C00079', 'CAMERON MANUFACTURING INDIA PVT LTD', '1', '1', '1', 'GANPAT', '9881376190', '1', 'SURVEY NO 255/01/08 HINJEWADI VILLAGE', 'TALUKA MULSI, NEXT TO YES BANK', 'MAHARASHTRA, INDIA PUNE 411057', 'PUNE', '1', 'India', '411057', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(107, 'C00080', 'CHINTAMANI THERMAL TECHNOLOGIES PVT LTD', '1', '1', '1', 'ARVIND', '9923757129', '22', 'S NO 29/ 3A/2 BEHIND GAIKWAD HOSPITAL,', 'HADAPSAR PUNE 411028', '', 'PUNE', '1', 'India', '411028', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(108, 'C00081', 'CLEANTECH SYSTEM PVT LTD', '1', '1', '1', 'PRASHANT SAVARDEKAR', '9881471781', '9', 'GATE NO 351 AT KASURDI (KB) POST', 'KHEDSHIVAPUR TAL BHOR DIST PUNE412205', '', 'PUNE', '1', 'India', '412205', '', '0211320308283', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(109, 'D00024', 'DRILLCO SECO-HO', '1', '1', '7', '', '0', '22', 'GAT NO. 849, PUNE NAGAR ROAD, KOREGAON B', 'HIMA, PUNE-412216', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(110, 'D00025', 'DURATECHNIC PHOTO LABS PVT. LTD.-DECCAN', '1', '1', '7', '', '0', '16', '301, EXPRESS TOWERS, 584, SADASHIV PETH,', 'LAXMI ROAD, PUNE-30', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(111, 'D00026', 'DURATECHNIC PHOTO LABS PVT. LTD.-B.RD', '1', '1', '7', '', '0', '5', '301, EXPRESS TOWERS 594, SADASHIV PETH,', 'LAXMI ROAD PUNE - 411030', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(112, 'D00027', 'DURATECHNIC PHOTO LABS PVT. LTD.-BARA', '1', '1', '7', '', '0', '9', '301, EXPRESS TOWERS 594, SADASHIV PETH P', 'UNE - 411030', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(113, 'D00028', 'DURATECHNIC PHOTO LABS PVT. LTD.-HO', '1', '1', '7', '', '0', '3', '301, EXPRESS TOWERS, ,594, SADASHIV PETH', ', PUNE-3', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(114, 'D00029', 'DURATECHNIC PHOTO LABS PVT. LTD.-KONICA AUNDH', '1', '1', '7', '', '0', '16', '301, EXPRESS TOWERS 594, SADASHIV PETH,', 'PUNE -30', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(115, 'D00030', 'DIVEKAR ASSOCIATES (INTERIOR DESIGNER)-HO', '1', '1', '7', '', '0', '3', 'VARUN COMPLEX, BHANDARKAR ROAD, NEXT TO', 'GAZELLA, LANE NO-16', 'PUNE-411004', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(116, 'D00031', 'DIVEKAR ASSOCIATES (INTERIOR DESIGNER)-ENG', '1', '1', '7', '', '0', '3', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(117, 'D00032', 'DESAI FOODS PVT. LTD. (MUNDHWA FARM)', '1', '1', '7', '', '0', '22', '3RD FLOOR, 2A, MOLEDINA ROAD,', 'CAMP, PUNE - 411001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(118, 'D00033', 'DESAI FOODS PRIVATE LIMITED', '1', '1', '7', 'DESHUMUKH', '0', '9', 'GAT NO. 204-266, BANGALORE-PUNE HIGHWAY', 'SAROLA, PUNE - 412205', '', 'PUNE', '1', 'India', '412205', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(119, 'D00034', 'DHARIWAL INDUSTRIES LTD.-HO', '1', '1', '7', 'B M VISHWASRAO', '9168655424', '14', 'MANIKCHAND HOUSE 100-101, D KENNEDY ROAD', ', BEHIND HOTEL LE- MERIDIAN PUNE-1', '', 'PUNE', '1', 'India', '0', 'bmvishwasrao@manikchandgroup.com', '', '9819679673', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(120, 'D00035', 'DESAI BROTHER (SASWAD)-NA', '1', '1', '7', '', '0', '9', 'SASWAD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(121, 'D00036', 'DESAI BROTHERS LTD.(BIDI DIV.) LOCATION :KASBA PETH)-NA', '1', '1', '7', '', '0', '16', 'DESAI HOUSE, 177/2, DHOLE PATIL ROAD, PU', 'NE 411 001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(122, 'D00037', 'DESAI FOODS PVT. LTD (SJD BUNGLOW)', '1', '1', '13', 'JANAK G C', '0', '14', '3RD FLOOR, 2A, MOLEDINA ROAD,', 'CAMP, PUNE - 411001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(123, 'D00038', 'DESAI BROTHERS LTD. (LOCATION : NRD RESIDENCE)-HO', '1', '1', '13', '', '0', '2', 'DESAI HOUSE, 177/2, DHOLE PATIL ROAD, PU', 'NE 411 001', '', 'PUNE', '1', 'India', '0', '', '', '9822114546', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(124, 'D00039', 'DESAI BROTHERS LTD ((HO))-HO', '1', '1', '7', '', '0', '14', 'ATUR CHAMBER, MOLEDINA ROAD, CAMP, PUNE', '411 001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(125, 'D00040', 'DESAI BROTHER LTD PVT. (SASWAD)-HO', '1', '1', '7', '', '0', '9', 'SASWAD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(126, 'D00041', 'DHARIWAL INDUSTRIES LTD.-SINDH SOCIETY', '1', '1', '13', 'PRAKASH DHARIWAL', '0', '2', 'MANIKCHAND HOUSE 100=101 D. KENNEDY ROAD', 'BEHIND L.E. MERIDIAN PUNE  1', '', 'PUNE', '1', 'India', '0', '', '', '26056099', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(127, 'D00042', 'DHARIWAL  INDUSTRIES LTD. (SITE  KOREGAON PARK)-KOREGAON PARK', '1', '1', '7', '', '0', '2', 'MANIKCHAND HOUSE 100-101 D. KENNEDY ROAD', 'BEHIND MANIKCHAND BUNGLOW (KOREGAON PAR', 'K) LE MARIDIAN LANE', 'PUNE', '1', 'India', '0', '', '', '26056099', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(128, 'D00043', 'DESAI BROTHERS LTD. (LOCATION: CORPORATE OFFICE)-HO', '1', '1', '7', '', '0', '14', 'DESAI HOUSE, 177/2, DHOLE PATIL ROAD, PU', 'NE 411 001', '', 'PUNE', '1', 'India', '0', '', '', '261365725411001', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(129, 'D00044', 'DDD-KOREGAON PARK', '1', '1', '7', '', '0', '22', 'COSMOS HEIGHT, 269/270, SHANIWAR PETH, P', 'UNE - 411 030', '', 'PUNE', '1', 'India', '0', '', '', '26121524', '268111768', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(130, 'D00045', 'DDD-DHANKAWADI', '1', '1', '7', '', '0', '5', 'DHANKAWADI - KATRAJ BR., S.NO. 19/9/1, R', 'OYAL ARCADE, NEAR SHANKAR MAHARAJ MATH,', 'PUNE - SATARA ROAD', 'PUNE', '1', 'India', '0', '', '', '24377403', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(131, 'D00046', 'DHARIWAL INDUSTRIES (KOREGAON PARK)-HO (64 BUNGLOW)', '1', '1', '7', '', '0', '22', 'MANIKCHAND HOUSE KENNEDY ROAD BEHIND HOT', 'AL LE MARIDIAN', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(132, 'D00047', 'DELVAL FLOW CONTROLS PVT. LTD.-HO', '1', '1', '7', '', '0', '7', 'CTS NO.4270, ELPRO COMPOUND, CHINCHWADGA', 'ON, PUNE 411033', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(133, 'D00048', 'DR. S M HARDIKAR-HO', '1', '1', '7', '', '0', '1', '41 B, RAM NAGAR COLONY, NDA ROAD, BAUDHA', 'N, PASHAN, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(134, 'D00049', 'DELOITTE HASKINS & SELLS LLP (7 TH FLOOR)', '1', '1', '7', '', '0', '3', '706, B WING, 7TH FLOOR, ICC TRADE TOWER,', 'INTERNATIONAL CONVENTION CENTRE,', 'SENAPATIBAPAT ROAD, PUNE16', 'PUNE', '1', 'India', '0', 'kevaidya@deloitte.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(135, 'D00050', 'DHL LEMUIR LOGISTICS PVT. LTD', '1', '1', '1', '', '0', '1', '140/3, TATHAWADE VILLAGE,', 'NEAR TUBE INVESTMENT', 'PUNE 411033', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(136, 'D00051', 'DHL LEMUIR LOGISTICS PVT. LTD.CLOSED', '1', '1', '7', '', '0', '1', '140/3, TATHAWADE VILLAGE, NEAR TUBE INVE', 'STMENT PUNE 411033', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(137, 'D00052', 'DV BRAHME AND SONS', '1', '1', '7', 'MR.AJAY BRAHME', '9822197691', '9', 'VAIBHAV CHAMBERS,33/41 ERANDAWANA', 'KARVE ROAD,PUNE', '', 'PUNE', '1', 'India', '411004', 'DIVSONS@PN3.USNL.NET.IN', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(138, 'D00053', 'DINANATH MANGESHKAR HOSPITAL', '1', '1', '8', '', '0', '1', '', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(139, 'D00054', 'DELOITTE HASKINS & SELLS LLP (I FLOOR)', '1', '1', '1', 'MRS SHAILASA', '0', '3', 'ICC TRADE CENTER B WING', 'I FLOOR SENAPATI BAPAT ROAD 5', '', 'PUNE', '1', 'India', '411005', 'kevaidya@deloitte.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(140, 'D00055', 'DESAI FOODS PVT. LTD (ATUR CHAMBER)', '1', '1', '7', '', '0', '14', '3RD FLOOR, 2A, MOLEDINA ROAD', 'CAMP, PUNE - 411001', '', 'PUNE', '1', 'India', '0', '', '', '26136572541', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(141, 'E00010', 'EMDET ENGINEERING PVT. LTD-HO', '1', '1', '7', '', '0', '7', 'J- 146, MIDC BHOSARI PUNE - 411026', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(142, 'E00011', 'E.C.M.I.SOFTWARE PVT. LTD.-HO', '1', '1', '7', '', '9822002447', '3', 'E.C.M.I.,204, MANTRI VERTEX, LAW COLLEGE', 'ROAD, PUNE 4', '', 'PUNE', '1', 'India', '0', '', '', '25450979', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(143, 'E00012', 'EUREKA FORBES LIMITED-KOREGAON PARK', '1', '1', '7', '', '0', '22', 'ORION BUILDING SECOND FLOOR, 201 B, OPP.', 'SENT MIRA COLLEGE 5, KOREGAON PARK, PUN', 'E 1', 'PUNE', '1', 'India', '0', '', '', '26003100', '26003333', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(144, 'E00013', 'EUREKA FORBES LTD.-KASARWADI', '1', '1', '7', '', '0', '7', 'GHANDHI COMPLEX, NASIK FHATA ROAD, KASAR', 'WADI, PUNE 12', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(145, 'E00014', 'EXCEL INDIA LTD.-HO', '1', '1', '7', '', '0', '1', 'B-127, AKSHAY COMPLEX, D.P. ROAD, PUNE(S', 'URVEY NO.120/3), TATAWADE, MULSHI.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(146, 'E00015', 'EUREKA FORBS LTD. (WAGHOLI)', '1', '1', '1', 'RAHUL KSHIRSAGAR', '9822874580', '22', '7A,CHAKRABERIA ROAD,SOUTH CALCUTTA', '25 WEST BENGOL.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(147, 'E00016', 'EUREKA FORBS LTD.', '1', '1', '7', '', '9881787827', '19', 'LALWANI WARE HOUSE, GATE NO.2324 PRIYANK', 'A NAGARI, NAGAR ROAD, WHAGHOLI.', '', 'PUNE', '1', 'India', '0', '', '', '27050869', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(148, 'E00017', 'EUREKA FORBES LTD.', '1', '1', '7', '', '0', '14', 'ORION BUILDING SECOND FLOOR, 201 B, OPP.', 'SENT MIRA COLLEGE 5, KOREGAON PARK, PUN', 'E 1', 'PUNE', '1', 'India', '0', '', '', '26003100', '26003333', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(149, 'E00018', 'EUREKA FORBES-AUNDH', '1', '1', '1', 'GHANSHYAM GAIKWAD', '9921292629', '2', 'FLAT NO-4,SAGAR APARTMENT', 'OPP.PARIHAR SWEETS,PARIHAR CHOWK,', 'AUNDH-PUNE-411007', 'PUNE', '1', 'India', '0', 'ghashyan g@eureka forbes .com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(150, 'E00019', 'ECOBOARDS INDUSTRIES LTD', '1', '1', '1', 'S.P SETHI & SHUBHANJ', '93710109925', '9', 'ECO HOUSE 65/A AKARSHAK BLDG OPP NAL', 'STOP KARVE ROAD, PUNE', '', 'PUNE', '1', 'India', '411004', 'info@ecoboardsmdea.com', '', '25465328', '41080808', '2025465328', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(151, 'F00004', 'FERNS-HO', '1', '1', '7', '', '0', '10', 'F.M. CARIAPPA ROAD, KIRKEE, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '5815781', '623258', '5810218', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(152, 'F00005', 'FINANCIAL ENGINEERING SOLUTIONS LTD-BANER', '1', '1', '7', '', '0', '2', '141, MAKER CHAMBER 111,', 'NARIMAN POINT, MUMBAI', '', 'PUNE', '1', 'India', '400021', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(153, 'F00003', 'FINANCIAL ENGINEERING SOLUTIONS PVT.LTD', '1', '1', '7', 'RITESH RATHOD   ', '2266303316', '1', '141, MAKER CHAMBER 111,', 'NARIMAN POINT, MUMBAI', '', 'PUNE', '1', 'India', '400021', 'ritesh.rathod@jmfl.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(154, 'F00006', 'FEUGO FURNITURE PVT. LTD. (HINJWADI, PUNE)-HO', '1', '1', '7', '', '0', '1', '3/1, PUTTAPPA, INDUSTRIAL ESTATE, BANGAL', 'ORE - 560048', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(155, 'G00020', 'GENOVATE SYSTEM (I) PVT. LTD.-HO', '1', '1', '7', '', '0', '14', '501, 502 NUCLUES MALL, PUNE CAMP 411 001', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '9325619539', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(156, 'G00021', 'GOODREJ SHERWOOD CO-OP HSG SOCIETY', '1', '1', '7', '', '0', '14', 'WAKDEWADI,', 'MUMBA-PUNE ROAD,', 'SHIVAJINAGAR', 'PUNE', '1', 'India', '411004', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(157, 'G00022', 'GANAGE PRESSING PVT.LTD.', '1', '1', '7', 'MR.SUNIL TADKAR', '9011034349', '7', 'F-11/49 &50,MIDE, PIMPRI,PUNE-144018.', '', '', 'PUNE', '1', 'India', '0', 'NAHULS@GANAGEGROUP.COM', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(158, 'H00011', 'HIGH TEM FURNANCES LTD-HO', '1', '1', '7', '', '0', '21', 'GATE NO. 615, VILL:- KURLI TAL:- KHED DI', 'ST:- PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(159, 'H00012', 'HIGH EXPLOSIVES FACTORY', '1', '1', '7', '', '0', '10', 'KHADKI PUNE- 411003', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(160, 'H00013', 'HERO MIND MINE-HO', '1', '1', '7', '', '0', '14', '6TH FLOOR, SOHRAB HALL, PUNE- 411001.', '', '', 'PUNE', '1', 'India', '0', '', '', '2226704536', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(161, 'H00014', 'HOTEL ATRI NIWAS-KOLHAPUR', '1', '1', '7', '', '0', '17', 'KAWALA NAKA , KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(162, 'H00015', 'HALLIBURTON  TECHNOLOGY INDIA PVT. LTD.-HO', '1', '1', '7', '', '0', '14', 'SAI RADHE, 101+101 D KENNEDY ROAD, -  PU', 'NE 411001  (PO NO.4505367423) DT.14.06.0', '7', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(163, 'H00016', 'POONA WAREHOUSING PVT LTD', '1', '1', '7', '', '912026125858', '14', '14, MOTILAL TALERA ROAD, ALANKAR HOTEL,', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(164, 'H00017', 'POONA  WAREHOUSING  PVT  LTD(SATKAR)', '1', '1', '1', 'PATIL', '9011057616', '14', 'OFF. PUNE RAILWAY STATION , NEAR TO', 'SATKAR HOTEL, PUNE 411001', '', 'PUNE', '1', 'India', '0', 'contact@taleragroup.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(165, 'H00018', 'HIGH EXPLOSIVE FACTORY (K)-KHADKI', '1', '1', '7', '', '0', '2', 'KHADKI, PUNE  411003', '', '', 'PUNE', '1', 'India', '0', '', '', '25819567', '25819566', '25813204', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(166, 'H00019', 'HNB ENGINEERING PVT. LTD. (KASARWADI)', '1', '1', '1', 'MR.THORAT', '0', '2', 'CENTRE 326, SHUKRWAR PETH, BAJIRAO ROAD,', 'PUNE 411002', '', 'PUNE', '1', 'India', '0', '', '', '24473299', '0', '2024473185', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(167, 'H00020', 'HOTEL SMART INN', '1', '1', '3', 'GANESHAN PILLAY', '9890755879', '16', '1226, SHIVAJINAGAR, FC OAD,', 'DECCAN COLLEGE ROAD,', 'PUNE 411004', 'PUNE', '1', 'India', '411004', '', '', '2553811', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(168, 'H00021', 'HNB ENGINEERING PVT. LTD. (BALEWADI)', '1', '1', '1', 'MR. THORAT', '0', '1', 'HENAB CENTRE 1326, SHUKRWAR PETH,', 'OFF. BAJIRAO ROAD, PUNE 411002', '', 'PUNE', '1', 'India', '411002', '', '', '24473299', '0', '24473185', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(169, 'H00022', 'HNB ENGINNERING PVT LTD ( AKURDI )', '1', '1', '13', 'MR.THORAT', '0', '7', 'HENABH CENTRE,1326,SHUKRAWAR PETH,', 'OPP- BAJIRAO ROAD,PUNE-02', '', 'PUNE', '1', 'India', '411035', 'hnbc@hnbc.in', '', '2024479185', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(170, 'H00023', 'HOTEL LE MEREDIAN', '1', '1', '3', 'PANDAY', '0', '14', 'RAJA BAHADUR MILL ROAD, PUNE 411001', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(171, 'H00024', 'HNB ENGINEERS  PVT. LTD.-DIGHI', '1', '1', '1', 'MR.THORAT', '0', '7', '1326,SHUKRAWAR PETH,BAJIRAO ROAD,', 'PUNE-2', '', 'PUNE', '1', 'India', '0', 'hnbc@hnbc.in', '', '24473299', '0', '2024473185', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(172, 'H00025', 'HOTEL ROYALITY (AJINKYA HOTELLING ) PVT LTD', '1', '1', '3', 'MR AJINKYA SONTAKKE', '9890941899', '3', 'HOTEL ROYALITY NO 1143 PRABHAT RD', 'ERANDWANE  PUNE', '', 'PUNE', '1', 'India', '411004', 'director@hotel_royalty.com', '', '2025466793', '2025466794', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(173, 'S00239', 'SAMARTH SYSTEMS', '1', '1', '7', 'MS P R JOSHI', '0', '14', '26/A, VRINDAWAN NO 02, CO-OPERARATIVE', 'HOUSING SOCIETY, PANCHAWATI, PASHAN ROAD', 'PUNE -411008.', 'PUNE', '1', 'India', '411008', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(174, 'I00008', 'ING VYSYA LIFE INSURANCE COMPANY PVT. LTD.-NA', '1', '1', '7', '', '0', '14', '3, 2ND FLOOR, AMAR AVINASH CORPORATE CIT', 'Y, 11 BUND GARDEN ROAD, PUNE - 411 001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(175, 'I00009', 'ING VYSYA LIFE INSURANCE-HO', '1', '1', '7', '', '0', '14', 'NA', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(176, 'I00010', 'IDEAS-HO', '1', '1', '7', '', '0', '16', '8 & 9TH FLOOR, PRIDE KUMAR SENATE, PLOT', 'NO.970 BHAMBURDA, BEHIND DOMINOS  PIZZA,', 'SENAPATI BAPAT ROAD', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(177, 'I00011', 'INDIA COM LTD.-HO', '1', '1', '7', '', '0', '22', 'HERMES HERITAGE PHASE I, OPP. SHASTRI NA', 'GAR. MSEB, PUNE NAGAR ROAD, PUNE 6', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(178, 'I00012', 'INDIA COM LTD.-DIRECTOR  BUNGLOW', '1', '1', '7', '', '0', '1', 'HERMES HERITAGE , PHASE I ,OPP. SASHTRI', 'NAGAR, MSEB PUNE NAGAR ROAD, PUNE 06', '', 'PUNE', '1', 'India', '0', '', '', '26613197', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(179, 'I00013', 'INNVENU HOSPITALITY MANAGEMENT PVT. LTD.((H]]-HADAPSAR', '1', '1', '7', '', '0', '5', 'OPP. SPYKA, BEHIND TATA HONEY WELL, HADA', 'PSAR, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(180, 'I00014', 'INDIA BULLS FINANCIAL SERVICES LTD. (PL)-AURORA TOWERS', '1', '1', '7', '', '0', '14', 'AURORA TOWERS, EAST WING, OFF.NO.212/9,', 'MOLEDINA ROAD,  PUNE 411001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(181, 'I00015', 'INDIA BULLS FINANCIAL SERVICES LTD. (PL)-KOTHRUD', '1', '1', '7', '', '0', '3', '67/68, SARVADARSHAN APARTMENT, OPP. TELE', 'PHONE EXCHANGE, KARVE ROAD,NAL STOP, KOT', 'HRUD, PUNE 4', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(182, 'I00016', 'INDIA BULLS FINANCIAL SERVICES LTD. (PL)-SHIVAJI NAGAR (CORPORATION)', '1', '1', '7', '', '0', '16', 'SHOP NO.123, PLOT NO.777, 562/6, NIRMALA', 'HEIGHTS, GROUND FLOOR, CONGRESS BHAVAN', 'RD, SHIVAJINAGAR 05', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(183, 'I00017', 'INDIA BULLS FINANCIAL SERVICES LTD. (PL)-VEGA CENTRE', '1', '1', '7', '', '0', '5', 'SHOP NO. 5, A WING, VEGA CENTRE, SHANKAR', 'SETH ROAD, SWARGATE, PUNE 411037', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(184, 'I00018', 'INDIA BULLS FINANCIAL SERVICES LTD. (PL)-NAGAR ROAD 1', '1', '1', '7', '', '0', '22', 'SR.NO.29/A/1/3/5, OFFICE NO.1 & 2 SHRISH', 'TI CENTRE VADGAONSHERI, PUNE NAGAR ROAD,', 'PUNE 411014', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(185, 'I00019', 'INDIA BULLS CREDIT SERVICES LTD. (PL)-PIMPRI', '1', '1', '7', '', '0', '7', 'JEWEL OF PIMPRI, KAMLA CROSSROADS, SHOP', 'NO.1,2,3,4, S.NO.4700 OPP.PCMC OFFICE, F', 'INOLEX CHOWK, PUNE18', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(186, 'I00020', 'INDIA BULLS FINANCIAL SERVICES LTD. (PL)-HADAPSAR', '1', '1', '7', '', '0', '5', 'YASHDEEP SHOPING CENTRE, OFF.NO.1,3RD FL', 'OOR, PUNE SOLAPUR ROAD,  HADAPSAR, PUNE', '28', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(187, 'I00021', 'INDIA BULLS FINANCIAL SERVICES  LTD. (PL)-PARMAR CHAMBERS', '1', '1', '7', '', '0', '14', 'G P/4, PARMAR CHAMBER, SADHU VASWANI CHO', 'WK, PUNE 411001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(188, 'I00022', 'INDIA BULLS FINANCIAL SERVICES LTD. (PL)-COLLECTION SHIVAJINAGAR', '1', '1', '7', '', '9860057461', '16', '30/31, OPP.SARSWATI HOUSING COMPLEX, JOG', 'BONGLOW, AGRICULTURE COLLEGE, SHIVAJINA', 'GAR,PUNE-5', 'PUNE', '1', 'India', '0', '', '', '32312519', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(189, 'I00023', 'INDIAN MAGIC EYE PVT. LTD.-HO', '1', '1', '7', '', '0', '4', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(190, 'I00024', 'IDIADA AUTOMOTIVE TECHOCHOLOGY INDIA PRIVATE LIMITED', '1', '1', '7', 'MR CARLES PEREL', '0', '14', 'RAJA BAHADUR MILL COMPOUND SAI  RADHE', 'UNIT NO.206 , 411001', 'KENNEDY ROAD,', 'PUNE', '1', 'India', '411001', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(191, 'I00025', 'IDIADA AUTOMOTIVE TECHOCHOLOGY II', '1', '1', '1', 'MR CARLES PEREL', '0', '2', 'RAJA BAHADUR MILL COMPOUND SAI  RADHE', 'UNIT NO.206 , 411001', 'KENNEDY ROAD,', '', '1', 'India', '411001', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(192, 'I00026', 'IDIADA AUTOMOTIVE TECHNOLOGY (HINGWADI)', '1', '1', '1', 'YOGESH BHOSALE', '8600018692', '1', 'RAJA BAHADUR MILL COMPUND SAI RADHE', 'UNIT NO 206 KENNDY ROAD', '', 'PUNE', '1', 'India', '411001', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(193, 'J00013', 'JAY KAY FURNITURE', '1', '1', '1', 'KAILASH JAIN', '0', '7', '', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(194, 'J00014', 'JAY KAY FURNITURE', '1', '1', '7', '', '9422309847', '7', 'S.NO.111/110 RANOKPUR DARSHAN, NEXT TO A', 'NAND MEDICAL, TANK ROAD, VISHRANTWADI, P', 'UNE', 'PUNE', '1', 'India', '0', '', '', '26685970', '26695439', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(195, 'J00015', 'JW CONSULTANTS LLP', '1', '1', '1', 'MRS PRACHI KARMARKAR', '9881202765', '14', 'SAI RADHE OFFICE NO 201,2ND FLOOR BEHIND', 'HOTEL LE MERIDIEN 100-101 KENNEDY ROAD', 'PUNE 411001', 'PUNE', '1', 'India', '411001', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(196, 'K00021', 'KIRLOSKAR GHATGE PATIL AUTO LTD.-HO', '1', '1', '7', '', '0', '1', 'R.S. 307,UNCHAGAON,KOLHAPUR 416005', '', '', '', '1', 'India', '416005', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(197, 'K00022', 'KOLHAPUR STAFF-HO', '1', '1', '7', '', '0', '1', 'R.S.307 UNCHAGAON KOLHAPUR 416005', '', '', '', '1', 'India', '416005', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(198, 'K00023', 'KIRLOSKAR GHATGE PATIL-HO', '1', '1', '7', '', '0', '5', 'BOMBAY PUNE ROAD, WAKDEWAD PUNE.', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(199, 'K00024', 'KOTHARI WHEELS-HO', '1', '1', '7', '', '0', '10', 'SAFFARI PARK, SHIVAJI NAGAR, PUNE 411005', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56');
INSERT INTO `tbl_client` (`client_id`, `client_code`, `name`, `comp_code`, `branch_code`, `catgcode`, `person`, `mobile`, `areacode`, `address1`, `address2`, `address3`, `city`, `statecode`, `countrycode`, `pin`, `email1`, `email2`, `phone1`, `phone2`, `fax`, `status`, `created`, `updated`) VALUES
(200, 'K00025', 'KOLTE PATIL KALYANINAGAR (FLORINA ESTATE)-HO', '1', '1', '7', '', '0', '22', 'KALYANINAGAR PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(201, 'K00026', 'KOLTE PATIL DEVELOPERS (THE SOVEREIGN NEW PLOT)-HO', '1', '1', '7', '', '0', '22', 'KALYANINAGAR PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(202, 'K00027', 'K & K BUILDERS-MITHILA NAGARI', '1', '1', '7', '', '0', '2', 'F C ROAD, BEHIND HOTEL SWARAJ, MITHILA N', 'AGARI, KATE PIMPLE, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(203, 'K00028', 'KRISHIDHAN SEEDS LTD', '1', '1', '1', '', '0', '1', 'SAI CAPITAL, 9TH FLOOR,', 'SENAPATI BAPAT ROAD', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(204, 'L00013', 'LIFE FITNESS INDIA  PVT LTD.(F C ROAD)-HO', '1', '1', '7', '', '0', '16', '925, B.F ROAD, SHIVAJINAGAR PUNE - 41100', '5.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(205, 'L00014', 'LIFE FITNESS INDIA PVT. LTD.(M G ROAD)-HO', '1', '1', '7', '', '0', '14', '625, B.FC ROAD SHIVAJINAGAR PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(206, 'L00015', 'LEEMUIR HEAD', '1', '1', '7', '', '9823030829', '18', 'B 127, AKSHAY COMPLEX, DP ROAD, PUNE  (S', 'R.NO.140/3, TATHWDE, MULSHI, PUNE.)', '', 'PUNE', '1', 'India', '0', '', '', '56246244', '0', '26113738', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(207, 'L00016', 'LABGUARD INDIA PVT. LTD-HO', '1', '1', '7', '', '0', '22', 'SECTOR NO.4, NEIGHBOURHOOD COMPLEX, OPP.', 'PALM BEACH ROAD, NERUL NEW BOMBAY', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(208, 'L00017', 'LAPIZ LAZULI APARTMENT ASSOCIATION', '1', '1', '7', '', '0', '22', 'CITY POINT BOAD CLUB ROAD, SOUTH MAIN RO', 'AD SANAR COLONY, KOREGAON PARK PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(209, 'L00018', 'LAPIZ LAZULI  (I)-HO', '1', '1', '7', '', '0', '22', 'CITY POINT BOAT CLUB ROAD, SOUTH MAIN RO', 'AD, SANAR COLONY, KOREGAON PARK', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(210, 'L00108', 'LUTF  FOODS PVT. LTD.', '1', '1', '4', 'GAUTAM GAIKWAD', '9881317563', '5', 'S.NO.37, NEAR ANGRAJ DHABA,', 'KONDHWA BUDRUK', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(211, 'M00082', 'MAYUR CO. OP. MILK UNION LTD.-HO', '1', '1', '7', '', '0', '17', 'TAMBAKHU SANGH BUILDING, SHREE SAHU MARK', 'ET YARD, KOLHAPUR', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(212, 'M00083', 'MAYUR COLDRAGE-NA', '1', '1', '7', '', '0', '9', 'KARJEEL MIDC, KOLHAPUR', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(213, 'M00084', 'MAYUR DUDH CO-OP SOCIETY SANPADA-HO', '1', '1', '7', '', '0', '10', 'PLOT NO. 6 SANPADA NAVI MUMBAI', '', '', 'PUNE', '1', 'India', '0', '', '', '27620687', '27620688', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(214, 'M00085', 'MAINTEC TECHNOLGIES PVT LTD-HO', '1', '1', '7', '', '0', '3', '4 TH FLOER NO. -815 TANHALE HIGHT LOW CO', 'LLEGE ROAD SHIVAJI NAGAR PUNE - 4', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(215, 'M00086', 'MAYUR MILK (CHIKLLING CENTER  KERUR)-HO', '1', '1', '7', '', '0', '17', 'MAYUR MILK (CHIKLLING CENTER - KERUR) ,', 'DIST - CHIKODE (KARANATAKA)', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(216, 'M00087', 'MAYUR PASHUKHADYA PRAKALP SHKROL-HO', '1', '1', '7', '', '0', '17', 'MAYUR PASHUKHADYA PRAKALP SHKROL TAL - S', 'HRIKOL DIST-KOLHAPUR', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(217, 'M00088', 'MAYUR PETROL PUMP-PHULEWADI', '1', '1', '7', '', '0', '9', 'MAYUR PETROL PUMP (PHULEWADI) KOLHAPUR', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(218, 'M00089', 'MAHARASHTRA ROAD CARRIER PVT LTD-HO', '1', '1', '7', '', '0', '22', '11 TH MILESTONE NAGAR ROAD WAGOLI (ST NO', '. ECC 7177200646)', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(219, 'M00090', 'MAYUR PETROL PUMP-CHOKAK', '1', '1', '7', '', '0', '9', 'MAYUR PETROL PUMP (PHULEWADI) KOLHAPUR', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(220, 'M00091', 'MAYUR MILK TURMBA-TURMBA', '1', '1', '7', '', '0', '9', 'KOLHAPUR', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(221, 'M00092', 'MAYUR MILK H.O.-HO', '1', '1', '7', '', '0', '9', 'KOLHAPUR', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(222, 'M00093', 'M D INDIA HELTHCARE SERVICES (I) PVT LTD.-HO', '1', '1', '7', '', '0', '2', '261/2/7/SILVER OAK PARK  BANER ROAD PUNE', '-411045', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(223, 'M00094', 'MAINTECH TECHNOLOGY PVT. LTD. BANGALORE-BANGALORE', '1', '1', '7', '', '0', '23', 'BANGALORE', '', '', 'BANGALORE', '8', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(224, 'M00095', 'MAYUR DOODH CO- OP SOCIETY ( SHIROLI )-HO', '1', '1', '7', '', '0', '7', 'SHAM MILK AND MILK PRODUCTS SHIROLI TAL', 'KHED . DIST. PUNE  RAJGURU NAGAR ROAD CH', 'AKAN PUNE.', 'PUNE', '1', 'India', '0', '', '', '9382225802', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(225, 'M00096', 'MAYUR MOLK UNION HAAD OFFICE-HO', '1', '1', '7', '', '0', '17', 'KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(226, 'M00097', 'M/S S. B. BILLIMORYA-HO', '1', '1', '7', '', '0', '3', '706, B WING, 7TH FLOOR, ICC TRADE TOWER,', 'INTERNATIONAL CONVENTION CENTRE,SENAPAT', 'IBAPAT ROAD, PUNE16', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(227, 'M00098', 'M/S A. F. FERGUSSON & COMPANY-HO', '1', '1', '7', '', '0', '3', 'ICC TRADE TOWER, INTERNATIONAL CONVENTIO', 'N CENTRE 706, B WING, 7TH FLOOR SENAPATI', 'BAPAT ROAD, PUNE16', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(228, 'M00099', 'MAHAVEER JWELLERS-S3', '1', '1', '7', '', '0', '5', 'BIBWEWADI ROAD, KALE HOSPITAL, PUNE  37', '', '', 'PUNE', '1', 'India', '0', '', '', '24213423', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(229, 'M00100', 'M/S RAMEE HOTELS PVT. LTD. (BOMBAY)-HO', '1', '1', '7', '', '0', '16', 'APTE ROAD, BHOPTKAR BUNGLOW, OPP. VIVEKA', 'NAND KARYALAYA', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(230, 'M00102', 'MOTIRAM NAGAR CO. OP. SOCIETY-HO', '1', '1', '7', '', '0', '3', 'MOTIRAM NAGAR,WARJE MALWADI, NEAR CIPLA', 'FOUNDATION, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '9881745251', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(231, 'M00103', 'M/S ALCOB SYSTEM PVT. LTD. (FACTORY)', '1', '1', '1', '', '0', '5', 'PISOLI, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(232, 'M00104', 'MR.MILIND HULLALKAR', '1', '1', '7', '', '0', '7', 'ANAND BAN OPP. HOTEL THANDA MAMLA', 'NEAR POLICE STATION TALEGAON PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(233, 'M00105', 'MICROLINE (I) PVT. LTD.', '1', '1', '1', 'CAPT. SP KUTE', '9371652776', '3', '94/16, BUTTE PATIL CLASSIC', 'OPP SUVARNA REKHA DINNING HALL', 'PRABHAT ROAD, PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(234, 'M00106', 'MALHOTRA BUNGLOW', '1', '1', '1', 'DAREKAR', '9822148718', '22', 'KOREGAON PARK, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(235, 'M00107', 'LOKSEVA PRATISHTAN', '1', '1', '7', 'MR.DEEPAK PAIGUDE', '0', '1', 'LOKSEVA PRATISHTHAN,SOMWAR PETH.', '', '', 'PUNE', '1', 'India', '0', '0', '0', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(236, 'M00108', 'M/S MOHINI RESORTS PVT. LTD.', '1', '1', '3', '', '0', '16', '14, MOTILAL TALERA ROAD,', 'PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(237, 'M00109', 'M/S ADVIK HIGHTECH PVT.LTD', '1', '1', '7', 'MR. BHARTIA', '0', '2', 'GUT NO.357199 TALEGAO', 'ROAD KHARABWADI', 'CHAKAN PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(238, 'M00110', 'MR.DEEPAK PAIGUDE', '1', '1', '7', '', '0', '1', 'LOKSEVA PRATISHATHAN,SOMWAR PETH,OPP.SAI', 'TRINITY,SUS RD,PASHAN', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(239, 'M00111', 'M/S MOHINI RESORTS PVT. LTD.', '1', '1', '7', '', '0', '16', '14, MOTILAL TALERA ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(240, 'M00112', 'M/S VENKATESHWARA HATCHERIES PVT. LTD.', '1', '1', '11', 'MR.KAPADNIS', '9922901409', '5', 'SINHAGAD ROAD,', 'PUNE', '', 'PUNE', '1', 'India', '411052', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(241, 'M00113', 'M/S BINDRAJ HOSPITALITY SERVICES PVT. LTD.', '1', '1', '4', 'MRS.BINDRA', '65002940', '5', 'BINDRAS GOURMET HOUSE,', 'S.NO.432/4, SALISBURY PARK,', 'NEXT TO16, GOLDEN BAKERIES,', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(242, 'M00114', 'M/S CORE OBJECTS INDIA PVT.LTD', '1', '1', '7', 'MR.YOGESH JADHAV', '0', '14', 'B-WING 2ND FLOOR,SAI RADHE,', 'RAJA BAHADUR MOTILAL MILLS COMPOUND', 'PUNE 411001', 'PUNE', '1', 'India', '0', 'YOGESHJADHAV@COREOBJECT.C', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(243, 'J00017', 'JRD PRINTPACK  PRIVATE LIMITED', '1', '1', '7', 'AMIT DHARIWAL', '0', '22', '850 KOREGAON BHIMA PUNE NAGER ROAD', 'PUNE 412216', '', 'PUNE', '1', 'India', '412216', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(244, 'M00116', 'MERWAN CAMA', '1', '1', '1', 'MR.M CAMA', '9822208941', '14', 'WANOWORI', 'PUNE', '', 'PUNE', '1', 'India', '0', 'merwancama@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(245, 'M00117', 'MITRA MANDAL CO-OP HSG SOCIETY LTD', '1', '1', '1', 'MR PURKAR', '0', '5', '484+31+32  PARVATI PUNE 411009', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(246, 'M00118', 'MAHI SIDDHANT ENTERPRISES', '1', '1', '7', 'DEEPAK KANGER', '9822022009', '9', 'BRHMA MAJASTIC', 'N.I.B.M ROAD', 'SHOP NO 30, KONDWA', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(247, 'M00119', 'MAHARASHTRA NATURAL GAS LIMITED (SHIVAJINAGAR) OFFICE HO', '1', '1', '1', 'SACHIN KALE', '8888154377', '3', 'PLOT NO.27, A BLOCK, 1 FLOOR,', 'NARVEER TANAJIWADI, PMPML BUS DEPOT,', 'COMMERCIAL BUILDING, SHIVAJINAGAR,', 'PUNE', '1', 'India', '411005', 'sachinkale@mngl.in', '', '25611000', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(248, 'M00120', 'MAHARASHTRA NATURAL GAS LIMITED (CHINCHWAD) OFFICE', '1', '1', '1', 'SACHIN KALE', '8888154377', '7', 'OMKAR PLAZA, PLOT NO.GP-77,', 'G-BLOCK, MIDC SAMBAJINAGAR,', 'CHINCHWAD', 'PUNE', '1', 'India', '411019', '', '', '65107600', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(249, 'M00121', 'MAHARASHTRA NATURAL GAS LIMITED (SHIVAJINAGAR CNG)PUMP', '1', '1', '1', 'SACHIN KALE', '8888154377', '3', 'CNG MOTHER STATION, NARVEER', 'TANAJIWADI, PMPML BUS DEPOT,', 'SHIVAJINAGAR,', 'PUNE', '1', 'India', '411005', '', '', '65106862', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(250, 'M00122', 'MAHARASHTRA NATURAL GAS LIMITED (CHIKHALI)', '1', '1', '1', 'SACHIN KALE', '8888154377', '7', 'CNG MEGA STATION, GUT NO.539,', 'MOJE CHIKHALI, OPP. MERCEDEZ BENZ,', 'MOJE CHIKHALI, TAL. HAVELI,', 'PUNE', '1', 'India', '0', '', '', '65107588', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(251, 'M00123', 'MAHARASHTRA NATURAL GAS LIMITED (SANT TUKARAM)', '1', '1', '1', '', '0', '7', 'CNG MOTHER STATION, SANT', 'TUKARAMNAGAR, PMPML BUS DEPOT', 'MORYA INDUSTRIAL ESTATE, PIMPRI', 'PUNE', '1', 'India', '411018', '', '', '20270100', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(252, 'M00124', 'MILANO PATEL TILES PVT LTD', '1', '1', '1', 'M.SS PATEL', '0', '9', 'GAT NO 205 KASURDI(KB) 412205', 'KHED SHIVAPUR TAL BHOR DIST PUNE', '', 'PUNE', '1', 'India', '0', '', '', '26452178', '26453202', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(253, 'M00125', 'MAHARASHTRA NATURAL GAS (KOTHRUD BHUSARI COLONY)', '1', '1', '6', 'SACHIN KALE', '888154377', '3', 'KOTHRUD PMPL BUS DESPOST BHUSARI COLONY', 'ROAD', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(254, 'N00021', 'NIAN  ENTERPRISES-HO', '1', '1', '7', '', '0', '9', 'CHORDIA FOODS PRODUCTS LTD. GAT NO. 399/', '400, SHIRWAL, SATARA ROAD,TAL KHANDALA,', 'DIST SATARA', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(255, 'N00022', 'NAKODA JWELLERS-S1', '1', '1', '7', '', '0', '14', 'BIBWEWADI ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '24213423', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(256, 'N00023', 'NORTH COURT VENTURES-KALYANI NAGAR', '1', '1', '7', '', '0', '22', 'CITY POINT , BOAT CLUB ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(257, 'N00024', 'NAKODA JWELLERS', '1', '1', '7', '', '0', '14', 'BIBWEWADI ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '24213423', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(258, 'N00025', 'NORTH COURT VENTURES', '1', '1', '7', '', '0', '19', 'CITY POINT , BOAT CLUB ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(259, 'O00001', 'OPULENTUS OVERSEAS EDU. PVT. LTD.', '1', '1', '7', 'SANTHOSH NAGAMALLY', '9225614411', '14', '143&144, 1ST FLOOR,', 'CONNAUGHT PLACE, BUNDGARDEN ROAD,', 'PUNE', 'PUNE', '1', 'India', '411001', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(260, 'O00002', 'OBARA INDIA PVT. LTD.', '1', '1', '1', 'MR. VINOD P', '8806669899', '7', 'W 17, F11 BLOCK, MIDC PIMPRI,', 'PUNE 411018', '', 'PUNE', '1', 'India', '0', 'vinod@obara.co.in', '', '30688550', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(261, 'P00044', 'PRAJ  INDUSTRIES LTD (VELU)', '1', '1', '7', '', '0', '9', '\"PRAJ HOUSE\" MUMBAI BANGLORE HIGHWAY', 'BAVDHAN; PUNE 411021', '', 'PUNE', '1', 'India', '411021', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(262, 'P00045', 'PERFECT PROTECTION (STAFF)-HO', '1', '1', '7', '', '0', '19', '\"SAI DARSHAN\" 251/2, D.P. ROAD, OPP AUND', 'H, BANER, PUNE-411008', '', 'PUNE', '1', 'India', '0', 'dsb27march@gmail ,com', '', '5818129', '5882242', '5816869', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(263, 'P00046', 'PAM PAC MACHINES-HO', '1', '1', '7', '', '0', '7', 'GET NO. 446/2, BIBEDOHAL, SOMATNE PHATA,', 'TAL: MAVAL', '', 'PUNE', '1', 'India', '0', '', '', '22808', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(264, 'P00047', 'PATHFINDER INVESTMENT CO. PVT. LTD.-HO', '1', '1', '7', '', '0', '3', '2ND FLOOR, VARUN COMPLEX, LAW COLLEGE RO', 'AD, LANE NO-16', 'PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(265, 'P00048', 'PRABHAT THREATRE-KOLHAPUR', '1', '1', '7', '', '0', '17', 'KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(266, 'P00049', 'PADMA THEATER-KOLHAPUR', '1', '1', '7', '', '0', '17', 'KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(267, 'P00050', 'PERFECT PROTECTION (I) PVT LTD  STAFF-KOLHAPUR', '1', '1', '7', '', '0', '17', 'KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(268, 'P00051', 'PIAT-HO', '1', '1', '7', '', '0', '5', 'INSTITUTE CAMPUS I, 2074 DSADASHIVPETH,', 'VIJAYNAGAR COLONY, BEHIND SP COLLEGE, PU', 'NE 30', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(269, 'P00052', 'PATANJALI BUNGLOW-HO', '1', '1', '7', '', '0', '18', 'CHAMPION ELECTRICAL PVT. LTD.,17 MIDC, B', 'HOSARI, BANER RESIDENCY NEAR SUPREME ICO', 'N SHOW ROOM, PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(270, 'P00053', 'POWERCON EQUIPMENTS-HO', '1', '1', '7', '', '0', '14', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(271, 'P00054', 'PRECISION AUTOMATION AND ROBOTICS (I) LTD.,-SHIRWAL', '1', '1', '7', '', '9881203966', '9', '436A,463B,464 DHANGARWADI,', 'TALUKA KHANDALA, DIST. SATARA', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(272, 'P00055', 'PRECISION AUTOMATION AND ROBOTICS (I) LTD., CHAKAN', '1', '1', '1', '', '0', '7', 'GAT NO 147, VILLAGE MHALUNGE', 'CHAKAN - TALEGAON ROAD', 'TAL KHED', 'PUNE', '1', 'India', '410501', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(273, 'P00056', 'PROFILE EDEN', '1', '1', '7', '', '0', '16', 'LANE NO.8 PRABHAT ROAD', 'ERANDWANE PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(274, 'P00058', 'PNG JEWELLERY & GEMS', '1', '1', '1', '', '0', '3', 'KOTHRUD, PUNE 38', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(275, 'P00059', 'PERFECT PROTECTION (INDIA ) PVT LTD (EXECUTIVE STAFF)', '1', '1', '1', '', '0', '19', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(276, 'P00060', 'PK MEHTA', '1', '1', '7', '', '0', '2', '231, VARSHA PARK SOCIETY, BANER ROAD, PU', 'NE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(277, 'P00062', 'PNG JEWELLERY & GEMS', '1', '1', '7', '', '0', '3', '1, PUNYAYEE, 127/1, PAUD ROAD, OPP. COMM', 'ERCE AVENUE, KOTHRUD, PUNE 38', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(278, 'P00063', 'P CUBE ENTERPRISES  PVT LTD', '1', '1', '7', 'MR.KOLPE', '0', '2', 'P-CUBE HOUSE, C,T.S NO 144S,B/1,', 'PASHAN ROAD, AUNDH, PUNE 411008', '', 'PUNE', '1', 'India', '411008', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(279, 'P00064', 'PRAJ INDUSTRIES LTD (KINNARI BUNGLOW)', '1', '1', '1', 'NANDAN KULKARNI', '9623440319', '2', 'PRAJ TOWER, 274 & 275, BHUMKAR CHOWK', 'HINJEWADI ROAD, PUNE 411057', '', 'PUNE', '1', 'India', '411007', 'amardevsodhi & praj net', '', '2071802000', '22941000', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(280, 'P00065', 'PUCON CIVIL ENGINEERS, CONTRACTORS & INTERIOR DECORATORS', '1', '1', '1', 'MR.SATISH BHATIA', '8888861791', '7', 'S.NO.101/1, C2-501/502, 5TH FLOOR,', 'SAUDAMINI COMPLEX, BHUSARI COLONY,', 'PAUD ROAD, KOTHRUD,', 'PUNE', '1', 'India', '411038', 'info@pucon.in', '', '60307070', '0', '25285855', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(281, 'P00066', 'PERFECT PROTECTION (DIRECTOR)3', '1', '1', '7', 'DSB', '0', '19', '34 DUCCAN ROAD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(282, 'R00038', 'RAI UNIVERSITY-HO', '1', '1', '7', '', '0', '14', '36/3B, NORTH MAIN ROAD, AFTER ABC FARMS,', 'KOREGAON PARK, PUNE - 1', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(283, 'R00039', 'RAJARAM CHITRA MANDIR-KOLHAPUR', '1', '1', '7', '', '0', '17', 'KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(284, 'R00040', 'RAVI ENTERPRISES-HO', '1', '1', '7', '', '0', '14', '37/1, WADGAON SHERI INDUSTRIAL ESTATE, P', 'UNE NAGAR ROAD, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(285, 'R00041', 'RATILAL B. KHIVASARA-HO', '1', '1', '7', '', '0', '5', 'SOUTHERN MACHINS INDUSTRIES, COMPOUND 70', '7, GULTEKADI ROAD, PUNE -411037', '', 'PUNE', '1', 'India', '0', '', '', '24263162', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(286, 'R00042', 'RED HAT SOFTWARE SERVICES (I) PVT. LTD.-HO', '1', '1', '7', '', '912030221201', '22', 'MARIGOLD PREMISES, EAST WING, 6TH FLOOR,', 'KALAYAN NAGAR, PUNE - 411 006', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '912030221200', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(287, 'R00043', 'R.B. INDUSTRIAL CONSTRUCTION ( PUNE ) PVT. LTD.-JIGNESH ENGINEERING', '1', '1', '7', '', '0', '7', 'BUNGLOW 341, SINDH SOCIEY, BANER ROAD, P', 'UNE 7', '', 'PUNE', '1', 'India', '0', '', '', '25897749', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(288, 'R00044', 'R.B. INDUSTRIAL CONSTRUCTION ( PUNE ) PVT. LTD.-BHIMA KOREGAON', '1', '1', '7', '', '0', '9', 'DHAN VILLA, 341, SINDH CO -OP SOCIETY, R', 'OAD NO.3, AUNDH, PUNE 7', '', 'PUNE', '1', 'India', '0', '', '', '25897749', '9850992372', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(289, 'R00045', 'R-HO', '1', '1', '7', '', '0', '22', 'MANIKCHAND HOUSE KENNEDY ROAD BEHIND HOT', 'AL LE MARIDIAN', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(290, 'R00046', 'RAGDARI APARTMENT OWNERS ASSOCIATION.-HO', '1', '1', '7', '', '0', '2', 'SR. NO. 156/18/1, D P ROAD, AUNDH, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '40056875', '40056874', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(291, 'R00047', 'R M DHARIWAL KOREGAON PARK', '1', '1', '7', '', '0', '22', 'MANIKCHAND BUNGLOW,', '79,80, LANE NO. 4', 'KOREGAON PARK', 'PUNE', '1', 'India', '411001', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(292, 'R00048', 'RAMESH & COMPANY', '1', '1', '7', 'DR.UDAY GOSAVI', '27474414', '7', 'NEAR KSB PUMPS,PLOT NO.29/7/8', 'CHINCHWAD', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(293, 'R00049', 'R A MUTHA (HUF)', '1', '1', '7', '', '0', '5', '1117,A/1 ASHISH, LAKAKI ROAD, PUNE 5', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(294, 'R00050', 'RAMAMANI IYENGAR MEMORIAL INSTITUTE OF YOGA', '1', '1', '6', 'MR. PRASHANT', '0', '16', '1/07 B-1 RAMAMANI IYENGAR YOGA INSTITUTE', 'HARE KRISHNA MANDIR ROAD', 'MODEL COLONY, PUNE -16', 'PUNE', '1', 'India', '0', '', '', '2025656134', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(295, 'S00132', 'S. BALAN ( SAI CHAMBER)-HO', '1', '1', '7', '', '0', '16', 'SAI CHAMBER BOMBAY PUNE ROAD', 'WAKDEWADI PUNE - 12.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(296, 'S00133', 'S BALAN BUNGLOW-HO', '1', '1', '7', '', '0', '10', '16, SAI CHEMBER, WAKDEWADI, BOMBAY POONA', 'ROAD, PUNE-3', '', 'PUNE', '1', 'India', '0', '', '', '5815136', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(297, 'S00134', 'SAI DARSHAN-HO', '1', '1', '7', '', '0', '2', 'D.P.ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '7290892', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(298, 'S00135', 'S BALAN(SWEEPER)-SWEEPER', '1', '1', '7', '', '0', '1', 'SAI CHEMBER, MUMBAI-PUNE ROAD, WAKDEWADI', ', PUNE-12', '', 'PUNE', '1', 'India', '411012', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(299, 'S00136', 'SNAP MARKETING-HO', '1', '1', '7', '', '0', '5', '322/16, SHANKERSETH ROAD, NEAR INDIAN OI', 'L PETROL PUMP, OPP. MEERA HOUSING SOCIET', 'Y, PUNE 411 042', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(300, 'S00137', 'SHETI MAL PRAKRIYA SANGH-HO', '1', '1', '7', '', '0', '17', 'TAL SHIROL DIST KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(301, 'S00138', 'SHIVAJI PARK-HO', '1', '1', '7', '', '0', '1', 'KOLHAPUR', '', '', '', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(302, 'S00139', 'SUBAL ENTERPRISES (MILLENIA)-HO', '1', '1', '7', '', '0', '1', 'TARABAI PARK, KOLHAPUR', '', '', '', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(303, 'S00140', 'SUMA SOFT  (II)   PVT. LTD.-NA', '1', '1', '7', '', '0', '3', 'OPP. MANGESHKAR HOSPITAL, NEAR MAHENDALE', 'GARAGE, NAL STOP, KOTHRUD, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(304, 'S00141', 'SUYOG GEOGRAPHY INFORMATION SYSTEMS PVT. LTD.-HO', '1', '1', '7', '', '0', '3', 'AKSHAYA INDUSTRIES, NEXT TO HOTEL GREEN', 'FIELD , SINHAGAD ROAD, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(305, 'S00142', 'SHREE CHANAKYA EDUCATION SOCIETY-SHIVAJI NAGAR', '1', '1', '7', '', '0', '16', 'B 2/14 A-B RAGHDHARI D P ROAD AUNDH PUNE', '- 7', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(306, 'S00143', 'SHREE CHANAKYA EDUCATION SOCIETY-WAKAD', '1', '1', '7', '', '0', '1', 'B 2/14 A-B RAGHDHARI D P ROAD AUNDH PUNE', '- 7', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(307, 'S00144', 'SHETI MAL PRAKRIYA SANGH - CL128-ALL ATM', '1', '1', '7', '', '0', '7', 'CENTURIAN BANK SECTOR 25, SINDHU NAGAR,', 'PRADHIKARAN NIGDI PUNE - 19', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(308, 'S00145', 'SHETI MAL PRAKRIYA SANGH - CL128-ATM KOREGAON PARK', '1', '1', '7', '', '0', '6', 'CENTURIAN BANL LTD. MUMBAI ROAD, PIMPRI', 'ATM 5, GANGA CASCADE NORTH MAIN ROAD, KO', 'REGAON PARK.', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(309, 'S00146', 'SHETI MAL PRAKRIYA SANGH - CL128-DHANUKAR COLONY', '1', '1', '7', '', '0', '3', 'CENTURIAN BANL LTD. MUMBAI ROAD, PIMPRI', 'ATM 5, GANGA CASCADE NORTH MAIN ROAD, KO', 'REGAON PARK.', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(310, 'S00147', 'SHETI MAL PRAKRIYA SANGH - CL128-PIMPRI', '1', '1', '7', '', '0', '7', 'NEAR VISHAL THEATRE, PIMPRI  PUNE.', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(311, 'S00148', 'SHETI MAL PRAKRIYA SANGH - CL128-FATIMA NAGAR', '1', '1', '7', '', '0', '5', 'CENTURIAN BANK LTD. MUMBAI PUNE ROAD, PI', 'MPRI SHOP N. 9 LAXMI CO-OP HOUSING SHIVA', 'RKAR ROAD. WANORI.', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(312, 'S00149', 'SHETI MAL PRAKRIYA SANGH - CL128-MODEL COLONY', '1', '1', '7', '', '0', '7', 'NEAR VISHAL THEATRE, PIMPRI  PUNE.', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(313, 'S00150', 'SHAMLA ASSO-KOLHAPUR', '1', '1', '7', '', '0', '9', '12-A, LBS MARG, GHORPADI, PUNE - 1', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(314, 'S00151', 'SOS CHILDRENS  VILLAGES  OF INDIA', '1', '1', '7', 'SUREKHA JADHAV', '0', '2', 'PUSHPAK PARK, BLOCK NO.-6 , AUNDH PUNE-7', '', '', 'PUNE', '1', 'India', '0', '', '', '25896894', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(315, 'S00152', 'SUMA SHILP PVT LTD. (III)  FLOOR-HO', '1', '1', '7', '', '0', '3', 'OPP. MANGESHKAR HOSPITAL, NEAR MAHENDALE', 'GARAGE, NAL-STOP, KOTHRUD, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(316, 'S00153', 'SUMA  SHILP LIMITED.-HO', '1', '1', '7', '', '0', '3', '93/5 A ERANDWANE PUNE (SITE) SUMA-CENTRE', ', OPP D.M. HOSPITAL ERANDWANE PUNE.', '', 'PUNE', '1', 'India', '0', '', '', '56713212', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(317, 'S00154', 'S. K. PATIL BANK LTD.-HO', '1', '1', '7', '', '0', '17', 'S. K. PATIL LTD , KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(318, 'S00155', 'SOLUTION EYE-ENGG', '1', '1', '7', '', '0', '16', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(319, 'S00156', 'SOLUTION EYE-ITES', '1', '1', '7', '', '0', '16', 'SAI CHAMBER, BOMBAY PUNE ROAD, WAKDEWADI', ', PUNE 3', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(320, 'S00157', 'SUMA SOFT (SUMA HOUSE)-HO', '1', '1', '7', '', '0', '3', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(321, 'S00158', 'SHREE CHALUKYA EDUCATION SOCIETY-HO', '1', '1', '7', '', '0', '18', 'INDIRA KIDS SECTOR NO. 83/3 A-2, ATHRVA', 'RESIDENCY, OPP. MALWANI GAZALI HOTEL, BA', 'NER ROAD', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(322, 'S00159', 'SUYOG AUTO CAST PVT. LTD.-HO', '1', '1', '7', '', '0', '7', 'PLOT. NO. 73 F-II BLOCK MIDC 411018', '', '', 'PUNE', '1', 'India', '0', '', '', '27475875', '27470352', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(323, 'S00160', 'SURYADATTA INSTITUTE OF MANAGEMENT-HO', '1', '1', '7', '', '0', '5', 'INSTITUTE CAMPUS I, 2074 SADASHIVPETH, V', 'IJAYNAGAR COLONY, BEHIND SP COLLEGE , PU', 'NE 30', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(324, 'S00161', 'SOLUTION EYE CALL CENTRE-HO', '1', '1', '7', '', '0', '16', 'SAI CHAMBER, BOMBAY PUNE ROAD, WAKDEWAD,', 'PUNE3', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(325, 'S00162', 'SIDBI ( ANAGA SPECILITIES PVT. LTD.-HO', '1', '1', '7', '', '0', '4', 'SURYKIRAN HOTEL BUILDING, C-8, MUMBAI PU', 'NE ROAD, CHINCHWAD, PUNE - 411 019', '', 'PUNE', '1', 'India', '0', '', '', '27474333', '0', '20', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(326, 'S00163', 'SIDBI ( ANAGA SPECILITIES PVT. LTD.)-HO', '1', '1', '7', '', '0', '1', 'SURYKIRAN HOTEL BUILDING, C-8, MUMBAI PU', 'NE ROAD, CHINCHWAD, PUNE - 411 019', '', 'PUNE', '1', 'India', '0', '', '', '27474333', '0', '20', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(327, 'S00164', 'SECO TOOLS INDIA PVT LTD-HO', '1', '1', '7', '', '0', '22', 'GAT NO.582, PUNE NAGAR ROAD, KOREGAON BH', 'IMA, PUNE TAL SHIRUR', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(328, 'S00165', 'SDB, CISCO ( INDIA ) LTD.-HO', '1', '1', '7', '', '0', '16', 'FLAT NO 4, 5 GANDHAR APARTMENTS. SR. NO.', '25, HISSA NO 2 A/9 OPP MEHATA HOSPITAL,', 'WAKADEWADI. PUNE 3', 'PUNE', '1', 'India', '0', '', '', '25511250', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(329, 'S00166', 'SIDBI-HO', '1', '1', '7', '', '0', '3', 'SURYAKIRAN BUILDING, 1ST FLOOR, C-8, CHI', 'NCHWAD PUNE-', '', 'PUNE', '1', 'India', '0', '', '', '27481754', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(330, 'S00167', 'SIDBI-ANAGA SPECILITIES PVT. LTD.', '1', '1', '7', '', '0', '7', 'GAT NO.28-2, VILL. KUMBHIVILL, TAL.KHALA', 'PUR, RAIGAD', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(331, 'S00168', 'SCMIT-HO', '1', '1', '7', '', '0', '20', 'INSTITUTE CAMPUS I, 2074 SADASHIVPETH, V', 'IJAYNAGARCOLONY, BEHIND SP COLLEGE, PUNE', '30', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(332, 'S00169', 'SHILPA SALES-KOLHAPUR', '1', '1', '7', '', '0', '17', 'KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(333, 'S00170', 'S.D. BILLIMORYA  & COMPANY-HO', '1', '1', '7', '', '0', '2', '5 LANDMARK , 42 AUNDH ROAD , PUNE 411020', '', '', 'PUNE', '1', 'India', '0', '', '', '25690891', '0', '25691619', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(334, 'S00171', 'SCMIRT-HO', '1', '1', '7', '', '0', '3', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(335, 'S00172', 'SHEETAL RUBBER PRODUCTS (P)  LTD.-HO', '1', '1', '7', '', '0', '7', '395, MIDC, BHOSARI PUNE 26PLOT NO. 7', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(336, 'S00173', 'SEALANTS & GASKET-HO', '1', '1', '7', '', '0', '7', '18, PARSI PANCHAYAT ROAD, ANDHER (EAST)', 'MUMBAI - 400069', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(337, 'S00174', 'STP GLOBAL SOLUTIONS PVT LTD.-HO', '1', '1', '7', '', '0', '1', 'BANER , BALEWADI ROAD, PUNE 4110046', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(338, 'S00175', 'SEALANTS GASKET-HO', '1', '1', '7', '', '0', '7', '18 PARSI PANCHAYAT ROAD, ANDERI (EAST)MU', 'MBAI 69', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(339, 'S00176', 'SUMASOFT III-HO', '1', '1', '7', '', '0', '3', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(340, 'S00177', 'SUMA SOFT (III FLOOR)-HO', '1', '1', '7', 'MR.VIRENDRA SURVE', '25425655', '3', 'OPP. MANGESHKAR HOSPITAL, NEAR MAHENDALE', 'GARAGE, NALSTOP PUNE KOTHRUD', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(341, 'S00178', 'SURYA DATTA(JOG)-HO', '1', '1', '7', '', '0', '20', 'INSTITUTE CAMPUS 1, 2074 D, SADASHIV PET', 'H, VIJAYNAGAR COLONY, BEHIND SP COLLEGE,', 'PUNE 30', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(342, 'S00179', 'S BALAN MAINTENANCE DIVISION    (SITE - SAI HIRA)', '1', '1', '7', '', '0', '22', 'SAI CHAMBER, UNIT NO.604,', 'BOMBAY PUNE RD,PUNE-411003.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(343, 'S00180', 'S BALAN MAINTENANCE ( SAI RADHE)-HO', '1', '1', '7', '', '0', '14', 'SAI CHAMBER, BOMBAY PUNE ROAD WAKDEWADI,', 'PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(344, 'S00181', 'S BALAN MAINTENANCE ( SAI TRINITY)-HO', '1', '1', '2', '', '0', '1', 'SAI CHAMBER, BOMBAY PUNE ROAD, WAKDEWADI', ', PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(345, 'S00182', 'S BALAN MAINTENANCE -TL', '1', '1', '7', '', '0', '7', 'SAI CHEMBER, BOMBAY PUNE ROAD,', 'WAKADEWADI PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(346, 'S00183', 'SUMA SOFT PVT. LTD.  (III FLOOR)', '1', '1', '7', 'MR.VIJENDRA SURVE', '25425655', '3', 'OPP. MANGESHKAR HOSPITAL, NEAR MAHENDALE', 'GARAGE, NALSTOP PUNE KOTHRUD', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(347, 'S00184', 'SAAMA TECHNOLOGIES (I) PVT. LTD.-HO', '1', '1', '7', '', '9823322888', '22', '6TH FLOOR, WEST WING, MARI SOFT III, KAL', 'YANI NAGAR, PUNE 411014', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(348, 'S00185', 'S BALAN MAINTENANCE-SAI HIRA', '1', '1', '7', '', '0', '22', 'SAI CHAMBER BOMBAY PUNE ROAD WAKDEWADI P', 'UNE - 12.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(349, 'S00186', 'S BALAN MAINTENANCE (SAI GAURAV)-HO', '1', '1', '7', '', '0', '5', 'SAI CHAMBER, BOMBAY PUNE ROAD, WAKDEWADI', ', PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(350, 'S00187', 'SAHYADRI INDUSTRIES LTD.-HO', '1', '1', '7', '/', '0', '16', 'SWASTIK HOUSE, 39/D, GULTEKDI, JN MARG,', 'PUNE 37', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(351, 'S00188', 'SUJANIL CHEMO INDUSTRIES (KONDHWA) FACTORY', '1', '1', '1', 'NA', '0', '5', '69/1/A/1B/3, WANOWARE INDUSTRIAL AREA,', 'KONDWA', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(352, 'S00189', 'SUJANIL CHEMO INDUSTRIES (KONDHWA)I', '1', '1', '7', '', '0', '5', '69/1/A/1B/3, WANOWARE INDUSTRIAL AREA,', 'KONDHWA', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(353, 'S00190', 'SUJANIL CHEMO (PIRANGUT)', '1', '1', '7', '', '0', '1', '', '69/A/1B/3,WANOWARE INDUSTRIES', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(354, 'S00192', 'SHRAYAN MOTOR PVT LTD', '1', '1', '7', 'MR. MOHAN DIXIT', '0', '22', 'POONA WAREHOUSE', 'TALERA FORD', 'NAGAR ROAD', 'PUNE', '1', 'India', '0', 'HRD@TALERAAUTO.COM', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(355, 'S00195', 'S BALAN MAINTENANCE SAI TRINITY (PS)', '1', '1', '7', '', '0', '1', 'WAKDEWADI, PUNE MUMBAI ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(356, 'S00197', 'SAI FABRICATION', '1', '1', '1', '', '0', '5', 'PISOLI, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(357, 'S00198', 'SHAGUN NISARG CO OP HSG SOCIETY', '1', '1', '1', 'NA', '0', '1', 'CO OP HOUSING SOCIETY BHAVDHAN, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(358, 'S00199', 'SYNERGY FOODS PVT, LTD HO', '1', '1', '7', '0', '0', '3', 'KASTROKING INDIA PVT.LTD., THE SYNERGY', '2ND FLOOR, PLOT NO.72/21 LAW', 'COLLEGE ROAD,FIRST FLOOR, PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(359, 'S00200', 'S BALAN MAINTENANCE (SAI RADHE) UPPER FLOOR', '1', '1', '7', 'MR. TALWAR', '0', '14', 'SAI CHAMBER , BOMBAY PUNE ROAD,', 'WAKDEWADI, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '30556900', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(360, 'S00203', 'S BALAN MAINTENANCE SAI TRINITY', '1', '1', '7', '', '0', '1', 'WAKDEWADI, PUNE MUMBAI ROAD, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(361, 'S00204', 'SAI FABRICATION', '1', '1', '7', '', '0', '5', 'PISOLI, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(362, 'S00205', 'S BALAN MAINTENANCE - TL NEW PLOT', '1', '1', '4', 'MR. SATHE', '9371086487', '7', 'SAI CHAMBER, BOMBAY PUNE ROAD,', 'WAKDEWADI, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(363, 'S00206', 'SAMAL CONSTRUCTION PVT. LTD.(PALLOD FARM)', '1', '1', '1', 'KIRAN SAMAL', '0', '1', 'MUKUND APARTMENT, GHARPURE', 'COLONY, 1180-60/13, SHIVAJINAGAR,', 'PUNE 5', 'PUNE', '1', 'India', '411005', '', 'RATE INCLUSING WEEKLY OFF', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(364, 'S00207', 'S BALAN MAINTENANCE SAI RADHE (VIGILANCE OFFICER)', '1', '1', '1', '', '0', '14', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(365, 'S00208', 'S BALAN SAI RADHE ( COMPUTER OPERATOR)', '1', '1', '1', '0', '0', '14', '0', '0', '0', 'PUNE', '1', 'India', '0', '0', '0', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(366, 'S00209', 'SOLUTIION EYES CONSULTANCY SERVICES PVT. LTD.', '1', '1', '1', 'S BALAN', '0', '16', 'UNIT NO.604, SAI RADHE,', '6TH FLOOR, 100-101, KENNEDY', 'ROAD, PUNE 411 001', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(367, 'S00210', 'SAMAL CONSTRUCTIION PVT. LTD. (FINOLEX I POWER, SHIRWAL)', '1', '1', '1', 'KIRAN SAMAL', '0', '9', 'MUKUNDNAGAR, GHARPURE', 'COLONY, 118061/13,', 'SHIVAJINAGAR,', 'PUNE', '1', 'India', '411005', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(368, 'S00211', 'SAMAL CONSTRUCTION PVT. LTD. (WAGHOLI)', '1', '1', '1', 'MR.SOLANKI', '0', '22', 'MUNKUND APARTMENT, GHARPURE', 'COLONY, 1180-61-13, SHIVAJINAGAR,', 'PUNE - 5', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(369, 'S00212', 'SUMA SOFT (VI) FLOOR', '1', '1', '7', 'MR.SURVE', '2025425655', '3', 'SUMA CENTER,2ND FLOOR,', 'ERENDWANE OPP,DINANATH MANGESHKAR HOSP.', 'PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(370, 'S00213', 'S.BALAN  MAINTENANCE DIVISION ( L )', '1', '1', '7', 'TALWAR', '0', '16', 'SAI CHAIMBER MUMBAI PUNE ROAD', 'PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(371, 'S00214', 'ADMINISTRATOR OF THE ESTATE OF THE VARADHACHARI', '1', '1', '1', 'MAHENDRA SHAR', '9373337937', '22', '4, LAVENDER, RUNWAL SHRUSHTI', 'LANE. OPP TO PPCL PETROL PUMP', 'BANER ROAD', 'PUNE', '1', 'India', '411045', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(372, 'S00215', 'SHRI SADGURU DATTA DHARMIK EVAM PARMARTHIK TRUST', '1', '1', '6', '', '0', '9', 'SAI CHAMBER, WAKDEWADI,', 'PUNE', 'BIBWEWADI', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(373, 'S00216', 'SUMA SOFT PVT.LTD. (IV FLOOR)', '1', '1', '1', '', '0', '3', 'OPP.MANGESHKAR HOSPITAL,NEAR MAHENDALE', 'GARAGE,NAL STOP, KOTHRUD ,PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(374, 'S00217', 'SAMAL CONSTRUCTION PVT. LTD.', '1', '1', '1', '', '0', '5', '', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(375, 'S00218', 'SAMAL CONSTRUCTION PVT. LTD. (KONDHWA)', '1', '1', '1', 'MR.SOLANKI', '9860067070', '5', 'SAMAL CONSTRUCTION LTD (NIBM KONDHWA)', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(376, 'S00219', 'SHANTA SAGER HOTEL', '1', '1', '3', 'MR PATIL', '9011057616', '22', '1 FAIR ROAD SOLAPUR BAZAR CHOWK', 'PUNE CAMP', '', 'PUNE', '1', 'India', '0', '', '', '0', '2026134499', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(377, 'S00220', 'SUREKH JEWELLERS', '1', '1', '13', 'RAMESH SOLANKI', '9890391000', '14', '287/B MG ROAD, CAMP PUNE-1', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '26344184', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(378, 'S00221', 'SAHYADRI INDUSTRIES LTD. (KEDGAON)', '1', '1', '1', '', '0', '22', 'KEDGAON', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(379, 'S00222', 'SPIRAL TOOL PVT LTD', '1', '1', '7', 'SACHIN SUPEKAR', '9822841204', '9', 'GAT NO.6 B1 VILLAGE  KASURDI (KHEDA)', 'KHED SHIVAPUR  TALUKA  BHOR', '', 'PUNE', '1', 'India', '412205', 'productionsprial@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(380, 'S00223', 'SHRI RANGANATH INTERNATIONAL SCHOOL', '1', '1', '1', '', '0', '9', 'BAGALKOT', 'KARNATAKA', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(381, 'S00224', 'SAHYADRI  INDUSTRIES LTD (DOOR DIVISION) KEDGAON', '1', '1', '1', '', '0', '22', '', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(382, 'S00225', 'SAAMA TECHNOLOGIES (INDIA)PVT LTD', '1', '1', '1', 'VIRENDER SINGH', '9823322888', '22', '1 FLOOR WEIKFIELD IT CITI INFO PARK', 'WEIKFIELD ESTATES PUNE NAGER ROAD PUNE', '', 'PUNE', '1', 'India', '411014', 'virender.singh@saama.com', '', '2066071500', '0', '2066071501', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(383, 'T00023', 'THAKOR ELECTRONICS LTD.-HO', '1', '1', '7', '', '0', '7', 'T-134 MIDC BHOSARI PUNE-26', '', '', 'PUNE', '1', 'India', '0', '', '', '7120234', '7672349', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(384, 'T00024', 'TIBCO SOFTWARE(i) PVT LTD.-HO', '1', '1', '7', '', '0', '3', 'KOTHRUD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(385, 'T00025', 'TIBCO SOFTWARE(i) PVT LTD.-1ST FLOOR', '1', '1', '7', '', '0', '3', 'KOTHRUD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(386, 'T00026', 'TIBCO SOFTWARE(i) PVT LTD.-6HT FLOOR', '1', '1', '7', '', '0', '3', 'KOTHRUD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(387, 'T00027', 'TIBCO SOFTWARE(i) PVT LTD.-4TH FLOOR', '1', '1', '7', '', '0', '3', 'KOTHRUD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(388, 'T00028', 'TIBCO SOFTWARE(i) PVT LTD.-HOUSEKEEING', '1', '1', '7', '', '0', '3', 'KOTHRUD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(389, 'T00029', 'TIBCO SOFTWARE(i) PVT LTD.-5TH FLOOR', '1', '1', '7', '', '0', '3', 'KOTHRUD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(390, 'T00030', 'TELENTICA SOFTWARE (I) PVT. LTD.-HO', '1', '1', '7', '', '0', '2', '301/302 SAPPHIRE CHAMBERS SURVE NO. 2-2/', '3 BANER PUNE 411 45', '', 'PUNE', '1', 'India', '0', '', '', '27292748', '2729749', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(391, 'T00031', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-NIGDI', '1', '1', '7', '', '0', '7', '269/270, SHANIWAR PETH,  PUNE -30', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(392, 'T00032', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-GOKHALE NAGAR', '1', '1', '7', '', '0', '16', '267/270 SHANIWAR PETH PUNE 30', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(393, 'T00033', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-PASHAN', '1', '1', '5', '', '0', '1', '267/270 SHANIWAR PETH PUNE 30', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(394, 'T00034', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-KOTHRUD', '1', '1', '7', '', '0', '3', '267./270 SHANIWAR PETH PUNE 30', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(395, 'T00035', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-AUNDHGAON', '1', '1', '7', '', '0', '2', '267/270 SHANIWAR PETH PUNE 30', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(396, 'T00036', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE SANEWADI', '1', '1', '5', '', '0', '2', '269/270, SHANIWAR PETH,  PUNE -30', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(397, 'T00037', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-PAUD', '1', '1', '7', '', '0', '3', '', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(398, 'T00038', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-KOREGAON PARK', '1', '1', '5', '', '0', '22', 'COSMOS HEIGHT, 269/270, SHANIWAR PETH, P', 'UNE - 411 031', '', 'PUNE', '1', 'India', '0', '', '', '2621524', '268111768', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(399, 'T00039', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-DHANKAWADI', '1', '1', '7', '', '0', '5', 'DHANKAWADI-KATRAJ RD., S.NO.-19/9/1, ROY', 'AL ARCADE, NEAR SHANKAR MAHARAJ MATH, PU', 'N-SATARA RD., PUNE', 'PUNE', '1', 'India', '0', '', '', '24377403', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(400, 'T00040', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-ALANDI', '1', '1', '7', '', '0', '21', 'ALANDI, 800, OM SAI SADAN, OPP. OLD S.T.', 'STAND, ALANDI DEVACH, KHED, PUNE-412105', '', 'PUNE', '1', 'India', '0', '', '', '213232304', '232036', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56');
INSERT INTO `tbl_client` (`client_id`, `client_code`, `name`, `comp_code`, `branch_code`, `catgcode`, `person`, `mobile`, `areacode`, `address1`, `address2`, `address3`, `city`, `statecode`, `countrycode`, `pin`, `email1`, `email2`, `phone1`, `phone2`, `fax`, `status`, `created`, `updated`) VALUES
(401, 'T00041', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-GANESH NAGAR', '1', '1', '5', 'MRS. WAGH BRANCH', '0', '3', 'COSMOS TOWER PLOT NO.6 ICS COLONY', 'UNIVERSITY ROAD, GANESHKHIND PUNE-411007', '', 'PUNE', '1', 'India', '0', '', '', '25441141', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(402, 'T00042', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE .-HEAD OFFICE', '1', '1', '7', '', '0', '5', 'SHANIWAR PETH, PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(403, 'T00043', 'THE COSMOS BANK (PARVATI)-PARVATI', '1', '1', '7', '', '0', '5', 'PARVATI', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(404, 'T00044', 'THE COSMOS CO-OPERATIVE BANK , ALANDI  DEVACHI-ALANDI DEVACHI', '1', '1', '7', '', '0', '7', 'COSMOS HEIGHT, SHANIWAR PETH, CHIMAJI AP', 'PA PESHAWE CHOWK, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '232304', '0', '24453816', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(405, 'T00045', 'TRINITY CONVERGENCE INDIA PVT. LTD.-HO', '1', '1', '7', '', '0', '3', '3RD FLOOR, OFFICE NO. 301 & 302 PRIDE PO', 'RTALSR. NO.103 A/5 A/1A/ 4B, BAHIRAT WAD', 'I, SHIVAJI NAGAR', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(406, 'T00046', 'TRANSPERANT ENERGY PVT. LTD.-HO', '1', '1', '7', '', '0', '9', 'GAT NO. 312, SHINDEWADI, SHIRWAL, DIST.', 'SATARA', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(407, 'T00047', 'TRANSPERANT ENERGY PVT. LTD.-BHOSARI', '1', '1', '7', '', '0', '7', 'A-51,52,LONAND.MIDC  AT  POST ,LONAND ,', 'TAL-KHANDALA  DIST- SATARA', '415521', 'PUNE', '1', 'India', '415521', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(408, 'T00048', 'THE COSMOS BANK(LAXMIROAD)-HO', '1', '1', '7', '', '0', '5', '476 NARAYAN PETH KUNTE CHOWK PUNE 30', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(409, 'T00049', 'TEXITY SYSTEM PVT. LTD.-HO', '1', '1', '7', '', '9881127167', '2', 'RAJYOG CREATION ANAND PARK AUNDH PUNE 41', '1007', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(410, 'T00050', 'TEXITY SYSTEM PVT. LTD.-PRABHAT ROAD', '1', '1', '7', '', '981127167', '16', 'KALA-CHAYA BUILDING, IIIRD FLOOR, PRABHA', 'T ROAD, LANE NO.1, PUNE.', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(411, 'T00051', 'TEXITY SYSTEM PVT. LTD.-AUNDH', '1', '1', '7', '', '0', '2', '4 RAJYOG CREATION ANAND PARK, AUNDH', 'PUNE 411009   INDIA', '', 'PUNE', '1', 'India', '411009', '', '', '27299046', '27299047', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(412, 'T00052', 'TATA TOYO RADIATIORS LTD-HO', '1', '1', '7', '', '0', '6', 'TATA TOYO', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(413, 'T00053', 'THE SOVEREIGN APARTMENT ASSOCIATION-HO', '1', '1', '7', '', '0', '22', 'KALYANINAGAR', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(414, 'T00054', 'TALERA AUTOMOBILE LTD', '1', '1', '1', 'MR. MOHAN DIXIT', '0', '22', 'POONA WAREHOUSE', 'TALERA FORD', 'PUNE NAGAR ROAD', 'PUNE', '1', 'India', '0', 'HRD@TALERAAUTO.COM', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(415, 'T00055', 'TALERA MOTORS PVT LTD.', '1', '1', '1', 'MR. MOHAN DIXIT', '0', '22', 'POONA WAREHOUSE', 'TALERA FORD', 'PUNE NAGAR ROAD', 'PUNE', '1', 'India', '0', 'HRD@TALERAAUTO.COM', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(416, 'T00056', 'THE WALLACE FLOUR MILL CO.  LTD.', '1', '1', '7', '', '0', '5', '9, WALLACE FORT STREET, COMMERCIAL', 'UNION HOUSE, MUMBAI 400 001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(417, 'T00057', 'TRANSPARENT TECHNOLOGIES PVT. LTD.', '1', '1', '1', 'VISHWAS RAO', '0', '7', '280 W BLOCK', 'MIDC BHOSARI', 'PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(418, 'T00058', 'THE WALLACE FLOUR MILLS CO. LTD.', '1', '1', '7', '', '0', '5', '9, WALLACE STREET FORT COMMERCIAL UNION', 'HOUSE, MUMBAI 400001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(419, 'T00059', 'TAKSHI AUTO COMPONENTS PVT LTD', '1', '1', '7', 'RAJU CHAVAN', '0', '7', 'CHAKAN ALANDI ROAD', 'PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(420, 'T00060', 'THE COSMOS CO OPERATIVE  BANK LTD. PUNE CAMP BRANCH', '1', '1', '5', 'MR. JAYESH MANDLIKA', '0', '14', '476/477, SHUBHAM HOUSING SOCIETY,', 'OPP.KEJALS NARAYAN PETH', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(421, 'T00061', 'TAKSHI AUTO COMPONENTS PVT LTD', '1', '1', '7', '', '0', '7', 'CHAKAN ALANDI ROAD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(422, 'T00062', 'TEXITY SYSTEM PVT.LTD.(AUNDH I)', '1', '1', '7', 'MR.MANIJ SINGH', '0', '2', 'RAJYOG CREATION ANAND PARK,AUNDH I.', 'PUNE-411009', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(423, 'T00063', 'TRANSPARENT TECHNOLOGIES PVT. LTD. (J J ARC CONTROL)', '1', '1', '7', 'VISHWASRAO', '0', '7', 'W280,S BLOCK', 'MIDC BHOSRI PUNE-26', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(424, 'T00064', 'THE COSMOS CO -OPERATIVE BANK LTD PUNE-AJMERA BRANCH', '1', '1', '5', 'SUBHASH UTKARAN', '9011070333', '7', '612 SADASHIV PETH, KUNTE CHOWK', 'LAXMI ROAD PUNE-411030', '', 'PUNE', '1', 'India', '411030', 'Subhase Vthlar@ cosmos bank.in', '', '0', '0', '202450510', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(425, 'T00065', 'TRANS TECH TURNKEY PVT LTD : PUNE RANJANGAON', '1', '1', '1', 'PARITOSH', '9673000423', '22', 'PLOT D1 MIDC RANJANGON INDUSTRIAL', 'AREA RANJANGAON PUNE 412209', '', 'PUNE', '1', 'India', '412209', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(426, 'T00066', 'TRANS TECH TURNKEY PVT LTD PUNE : HUNTSMAN', '1', '1', '1', 'GAJANAN JOSHI', '7875554707', '7', '101, MAYFAIR TOWER II,', 'WAKDEWADI, SHIVAJINAGAR,', 'PUNE 5', 'PUNE', '1', 'India', '411005', 'HUNTSMAN INTERNATIONL (I) PVT.LTD.', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(427, 'T00067', 'TRANSTECH TURNKEY PVT LTD.(BOMBAY)', '1', '1', '2', 'ARVIND KUNDARGI', '9673000409', '7', '101, MAYFAIR TOWER II', 'WAKADEWADI', 'PUNE 411005', 'PUNE', '1', 'India', '411005', 'ONGC ANNEX BUILDING', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(428, 'T00068', 'TITAN COMPANY LIMITED', '1', '1', '1', 'RAVINDRA', '9145826367', '22', 'TANISHQ SHOWROOM, CTS 30, TIMES SQUARE', 'BUNDGARDEN, PUNE 411 001', '', 'PUNE', '1', 'India', '411001', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(429, 'T00069', 'TRANS TECH TURNKEY PVT LTD PUNE : YAPPZOOM', '1', '1', '1', 'GAJANAN JOSHI', '7875554707', '7', '101, MAYFAIR TOWER II,', 'WAKDEWADI, SHIVAJINAGAR,', 'PUNE 411005', 'PUNE', '1', 'India', '0', 'YAPPZOOM AUTOMOTIVE SYS PVT. LTD.', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(430, 'T00070', 'TANISHQ TITAN INDUSTRIES LTD.(II)', '1', '1', '1', 'RAVINDRA', '9145826367', '16', 'LAXMI ROAD', 'PUNE 2', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(431, 'T00071', 'TRANSTECH TURNKEY PVT. LTD: GABERIT', '1', '1', '1', 'VINAYAK SUTAR', '8390907897', '7', '101 MAYFAIR TOWER II, WAKDEWADI,', 'SHIVAJINAGAR,', 'PUNE 411005', 'PUNE', '1', 'India', '411005', 'GEBERIT INDIA MANUFACTURING PVT. LTD.', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(432, 'T00072', 'TRANSPERANT ENERGY SYSTEM PVT. LTD.(SHIRWAL)', '1', '1', '7', '', '0', '9', 'GAT NO. 312, SHINDEWADI, SHIRWAL,', 'DIST-SATARA', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(433, 'T00074', 'TANISHQ TITAN INDUSTRIES (PIMPRI)', '1', '1', '1', 'RAVINDRA', '9145826367', '7', 'BUNDGARDEN ROADS OPP PUNE CENTRAL', 'PUNE 411001', '', 'PUNE', '1', 'India', '0', 'ravindra@titan .co.in', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(434, 'T00075', 'THE ZOROASTIAN CO-OPERATIVE BANK LTD', '1', '1', '5', 'JASMINE B.KERAWALLA', '26119956', '14', '636,637 SACHPHIR STREET MODERN HOUSE', 'PUNE 411001', '', 'PUNE', '1', 'India', '0', 'zoropune@yahoo.com', '', '0', '0', '26119318', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(435, 'U00007', 'UBERALL SOLUTIONS (I) PVT. LTD.-INDUSTRY', '1', '1', '7', '', '0', '1', 'NA', '', '', 'PUNE', '1', 'India', '411016', '', '', '5660313', '0', '91205662236', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(436, 'V00016', 'VISHNU AND SONS (KOLHAPUR)-KOLHAPUR', '1', '1', '7', '', '0', '17', 'KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(437, 'V00017', 'V.S.N.L.-KOLHAPUR', '1', '1', '7', '', '0', '17', 'KOLHAPUR', '', '', 'KOLHAPUR', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(438, 'V00018', 'VERYSOFT INFO SERVICES PVT LTD.-HO', '1', '1', '7', '', '0', '1', '3RD FLOOR SUN GRACE BUILDING BAVDHAN KHU', 'RD NEAR CHANDNI CHOWK, PUNE 21', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(439, 'V00019', 'VERNEKAR JWELLERS-S6', '1', '1', '7', '', '0', '5', 'BIBWEWADI ROAD, KALE HOSPITAL, PUNE  37', '', '', 'PUNE', '1', 'India', '0', '', '', '24213423', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(440, 'V00020', 'VISAKA INDUSTRIES LTD', '1', '1', '7', 'RAMSAMY', '242334', '22', 'GAT NO 70/3A/3. SAHAJPUR INDUSTRIAL', 'AREA NANDUR VILLAGE TAL DAUND', 'PUNE', 'PUNE', '1', 'India', '412202', '0', '0', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(441, 'V00021', 'V.P.BEDEKAR & SONS PVT. - GUARD', '1', '1', '1', '', '0', '7', 'GROUND FLOOR, BEDEKAR SADAN NO -3', '56 GHARPURE PATH GIRGAON MUMBAI', '400004', 'PUNE', '1', 'India', '0', 'bedekar.sales@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(442, 'V00022', 'V.P.BEDEKAR & SONS PVT.', '1', '1', '7', '', '0', '7', 'BEDEKAR SADAN NO.4, TATYA GHARPURE PATH,', 'MUMBAI 400004', '', 'PUNE', '1', 'India', '0', '', '', '23856673', '0', '23859552', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(443, 'V00023', 'VEE NIMBKHAR CO OP HOUSING SOCIETY', '1', '1', '1', 'KETAN CHAPHEKAR', '0', '2', 'ABHIMAN SHREE SOCIETY ROAD', 'AUNDH PUNE', '', 'PUNE', '1', 'India', '411007', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(444, 'W00006', 'WESTERN PRESSING PVT. LTD (BHOSARI)-HO', '1', '1', '7', '', '0', '7', 'F-2, 24/25, MIDC, PIMPRI, PUNE-18', '', '', 'PUNE', '1', 'India', '0', '', '', '7477376', '0', '910207474034', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(445, 'W00007', 'WEIZMANN FOREX LTD-NA', '1', '1', '7', '', '0', '14', 'EAST STREET GALLERIA, GROUND FLOOR, NO.2', '421, GENERAL THIMAYA ROAD, PUNE 1', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(446, 'W00008', 'WAMAN HARI PETH-HO', '1', '1', '7', '', '0', '3', 'SHRISHTI CHAMBER, SHIVAJI NAGAR, PUNE -', '411 005', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(447, 'W00009', 'WEIZMANN FOREX LTD. (PIMPRI)-PIMPRI', '1', '1', '7', '', '0', '7', 'UNIT NO 19, UMED BHAVAN, SHRIROAD PIMPRI', 'PUNE 18', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(448, 'W00010', 'WOODSIDE VILLA-HO', '1', '1', '7', '', '0', '2', 'PLOT NO. 112 S.NO.129/130,AUNDH  PUNE  7', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(449, 'Y00010', 'YOGESH PATEL-HO', '1', '1', '7', '', '0', '9', 'PUNE', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(450, 'Z00001', 'GLATT SYSTEMS PRIVATE LIMITED', '1', '1', '1', '', '0', '22', 'II FLOOR,CONNOUGHT PLACE,', 'CTS 28 BUNDGARDEN ROAD', 'PUNE', 'PUNE', '1', 'India', '411001', 'umesh.kolhatkar@ziemann.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(451, 'S00226', 'SOLAR BIOTRONIC LABORATORIES PVT LTD', '1', '1', '1', 'MS UJWALA', '9881155441', '16', 'BUILDING NO.759/120, PRABHAT ROAD,', 'LANE-2, DECCAN', 'PUNE - 411 004', 'PUNE', '1', 'India', '411004', 'info@sblindia.com', '', '2030112605', '30112600', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(452, 'C00082', 'GIIAVA  (INDIA) PVT LTD', '1', '1', '7', 'RAJESH AGNIHOTRI', '9325002886', '3', 'THE SYNERGY, PLOT NO 70.21', 'LAW COLLEAGE ROAD PUNE 4', '', 'PUNE', '1', 'India', '0', 'ragnihotri@giiava.com', '', '25469360', '25455904', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(453, 'D00056', 'DIVEKAR ASSOCIATES  (INTERIOR DESIGNER) HO', '1', '1', '7', '', '0', '3', 'VARUN COMPLEX BHANDARKAR ROAD NEXT', 'TO GAZELLA LANE NO - 16', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(454, 'S00227', 'SOLUTION EYE CONSULTANCY SERVICES AND CONSTRUCTION PVT. LTD.', '1', '1', '1', 'MR.PUNIT BALAN', '2025542311', '16', '309, SAI CHAMBER, 16, MUMBAI PUNE', 'ROAD, WAKDEWADI, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(455, 'S00228', 'PUNEET S BALAN MAINTENANCE SERVICES (SAI RADHE)', '1', '1', '1', 'PUNIT BALAN', '0', '14', 'SAI CHAMBER, UNIT NO.606', 'MUMBAI PUNE ROAD PUNE 411003', 'PUNE', 'PUNE', '1', 'India', '411003', '', '', '2067680005', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(456, 'S00229', 'PUNEET S BALAN MAINTENANCE SERVICES (SAI CHAMBER)', '1', '1', '1', 'PUNIT BALAN', '0', '16', '606 SAI CHAMBER,16 MUMBAI PUNE ROAD', 'PUNE 411003', '', 'PUNE', '1', 'India', '0', 'corporate@sbalangroup.com', '', '2067680005', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(457, 'S00230', 'S BALAN MAINTENANCE DIVISION (SITE-SAI TRINITY)', '1', '1', '1', 'PUNIT BALAN', '0', '1', 'SAI CHAMBER, UNIT NO.604', 'BOMBAY PUNE ROAD, PUNE 3', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(458, 'P00067', 'PATHFINDER INVESTMENT CO. PVT. LTD.', '1', '1', '7', '', '0', '3', '2ND FLOOR , VARUN COMPLEX,', 'LAW COLLEGE ROAD, LANE NO.16', 'KOTHRUD', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(459, 'M00127', 'M/S SHIRKE ENGINEERING SERVICES PVT LTD', '1', '1', '7', 'MR PRAKESH CHITNIC', '9850558538', '7', 'PLOT NO 47 F2 BLOCK MIDC PIMPRI', 'PUNE 411014', '', 'PUNE', '1', 'India', '0', 'shirke.sameer@rediffmail.com', '', '0', '0', '27470751', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(460, 'A00072', 'ARMAPRO SECURITY SERVICES PVT LTD (OT)', '1', '1', '5', '', '0', '22', '12- A VICTORIA ROAD, GHORPHADI PUNE - 1', '', '', '', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(461, 'S00231', 'SAHYADRI INDUSTRIES OPEN PLOT', '1', '1', '1', '', '0', '16', 'SWASTIK HOUSE, 39/D,', 'GULTEKDI, J.N. MARG,', 'PUNE - 411037', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(462, 'S00232', 'SUMA SOFT PVT LTD (II FLOOR)', '1', '1', '1', 'VIJENDRA SURVE', '2025671312', '3', 'OPP MANGESHKAR HOSPITAL, NEAR', 'MAHENDALE GARAGE, NAL STOP, KOTHRUD PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(463, 'S00233', 'SUMA SOFT PVT LTD (III FLOOR)', '1', '1', '1', 'VIJENDRA SURVE', '2025671312', '3', 'OPP MANGESHKAR HOSPITAL NEAR MAHENDALE', 'GARAGE NALSTOP PUNE KOTHURD', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(464, 'B00069', 'BEKAERT INDUSTRIES PVT LTD', '1', '1', '1', 'SEBASTINE RAY', '2066276600', '22', 'PLOT NO 127, SAKORE NAGAR,', 'VIMAN NAGAR,PUNE- (P.O.NO.2674054649)', 'PUNE', 'PUNE', '1', 'India', '411014', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(465, 'D00057', 'DV BRAHME AND SONS SALES AND SERVICES PVT LTD', '1', '1', '4', 'MR AJAY BRAHME SONAL', '9822197691', '9', 'GAT NO 20C SHIVAPUR SASWAD ROAD KASURDI', 'BHOR PUNE 412205', '', 'PUNE', '1', 'India', '0', 'divsons@ gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(466, 'M00128', 'M/S CHINTAMANI THERMAL TECHOLOGIES PVT LTD', '1', '1', '7', 'MR ARVIND DAHIWALKAR', '9923757129', '14', 'SNO 29/3A/2 BEHIND GAIKWAD HOSPITAL,', 'HADAPSAR, PUNE 411028', '', 'PUNE', '1', 'India', '0', 'chintamani_@vsnl.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(467, 'S00234', 'S BALAN SAI RADHE (VIGILANCE OFFICER)', '1', '1', '1', '', '0', '14', '', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(468, 'S00235', 'SUMA SOFT PVT LTD (II FLOOR) OT', '1', '1', '1', 'VIJENDRA SURVE', '2025671312', '3', 'OPP MANGESHKAR HOSPITAL, NEAR', 'MAHENDALE GARAGE, NAL STOP, KOTHRUD PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(469, 'S00236', 'SUMA SOFT PVT LTD (III FLOOR) OT', '1', '1', '1', 'VIJENDRA SURVE', '2025671312', '3', 'OPP MANGESHKAR HOSPITAL NEAR MAHENDALE', 'GARAGE NALSTOP PUNE KOTHURD', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(470, 'P00068', 'PRAJ INDUSTRIES LIMITED ( HO )', '1', '1', '1', 'MR.GANESH PADEKAR', '0', '2', 'PRAJ TOWER, 274 & 275, BHUMKAR CHOWK,', 'HINJEWADI ROAD, PUNE 411057', '', 'PUNE', '1', 'India', '410057', 'ganeshpadkar@praj.net', '', '22941000', '71802000', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(471, 'U00009', 'UNPA ENGINEERING', '1', '1', '1', 'MRS.UMITA JADHAV', '7709040651', '9', 'GATT NO.352, KASURDI(KB),', 'KHED SHIVAPUR, TAL - BHOR,', 'DIST- PUNE', 'PUNE', '1', 'India', '412205', 'ashwini.jagtap@unpaengineering.com', 'unpaengineering@vsnl.net, unpa.onmesh@gm', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(472, 'A00073', 'ADVIK HI-TECH PVT.LTD.', '1', '1', '13', 'MR.AVDHOOT DESAI', '9561096187', '2', 'AHPL P5 CORPORATE, SOLITAIRE WORLD 7,6', 'RENAULT SHOWROOM, PUNE 411045', 'OPP SUPREME HQ', 'PUNE', '1', 'India', '411045', 'hr104@advik.co.in', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(473, 'D00058', 'DESAI BROTHERS LTD. HO ( KANTEBENNUR )', '1', '1', '7', 'MR.GANESH DESHMUKH', '0', '9', 'DESAI BROTHERS LTD.,374/B, HOLALU TO', 'HADAGALI RD.,KANTEBENNUR,', 'HUVINAHADGALI -TAL, BELLARY-DIST', 'KANTEBENNUR', '1', 'India', '0', '', '', '9481482161', '9742114510', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(474, 'S00237', 'SHREE DATTA DEVASTHAN TRUST', '1', '1', '6', 'MEGHANA MALU', '9850730773', '22', 'PREMDAN CHOWK, OPP.NOVBL HOSPITAL', 'AT POST SAVADI,', 'TAL/DIST - AHMEDNAGAR', 'PUNE', '1', 'India', '0', 'aosddt@gmail.com', '', '9405571582', '9579421763', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(475, 'A00074', 'ARIRANG HOSPITALITY PVT. LTD.', '1', '1', '1', 'RAVI JACOB', '9923200201', '22', 'NEW AIPORT ROAD, NEAR SYMBIOSISI', 'COLLEGE , SAKORE NAGAR,', 'VIMAN NAGAR, PUNE', 'PUNE', '1', 'India', '0', 'jacobarirang@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(476, 'J00016', 'JYOTHI ENGINEERING', '1', '1', '1', 'MR.VINOD', '9552593816', '7', 'F-II BLOCK, PLOT NO 44, MIDC,', 'PIMPRI, PUNE.', '', 'PUNE', '1', 'India', '411018', 'jothiengineering1976@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(477, 'G00023', 'GIGA SPACE CONDOMINIUM', '1', '1', '1', 'NJ SHAIKH', '0', '22', 'SR.NO.198/1B, GIGA SPACE IT PARK', 'VIMAN NAGAR, NAGAR ROAD,', 'PUNE 411014', 'PUNE', '1', 'India', '411014', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(478, 'A00075', 'ATTRA INFOTECH (P) LTD.', '1', '1', '1', 'KUMAR ASISH SINHA', '9923109789', '22', 'NO,201/202,ZERO1NE   BIDG.,', '2ND FLOOR ,MUNDHWA, PUNE-411036', '', 'PUNE', '1', 'India', '0', 'asish.sinha@attra.com.au', '', '49011900', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(479, 'Y00011', 'YUME INDIA PRIVATE LIMITED', '1', '1', '7', 'MR YOGESH DANDEKAR', '9677122022', '16', '605 ICC TRADE TOWER', '6TH FLOOR A WING', 'SENAPATI BAPAT RD, PUNE', 'PUNE', '1', 'India', '411016', 'ejohn@yume.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(480, 'K00029', 'KULTRONIX ESD TECHNOLOGY PVTLTD.', '1', '1', '1', 'MR.SAMEER KULKARNI', '9823183392', '2', '1ST FLOOR, A WING KARHADKAR HEIGHTS', 'BHOI ALI, CHINNCHWAD', '', 'PUNE', '1', 'India', '411033', 'kultronix@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(481, 'M00129', 'MR. DALJIT MIRCHANDANI', '1', '1', '1', '', '9503980007', '1', '101, SINGH HOUSING SOCIEYT', 'BANER ROAD, PUNE 411007', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(482, 'P00069', 'TALERA REAL ESTATE PVT LTD', '1', '1', '3', 'MS BHARTI', '9270766454', '14', 'PUNE 411 001', '', '', 'PUNE', '1', 'India', '411001', 'bharti.kadam@dynamiclogistic.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(483, 'P00070', 'POLY CHEM', '1', '1', '1', 'AMIT KAULGUD', '9970187385', '3', '6, KOTHRUD INDUSTRIAL ESTATE,', 'NEXT TO PRAGATI COMPLEX,', 'KOTHRUD', 'PUNE', '1', 'India', '411038', 'hr@polychem.co.in', '', '9970187385', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(484, 'O00003', 'KALOUPI IT SERVICES', '1', '1', '7', 'MR.GURPREET SINGH', '0', '14', 'OFFICE AT 4TH FLOOR, AMAR SYNERGY PARK,', 'SADHU VASWANI CHOUK, PUNE -411 001', '', 'PUNE', '1', 'India', '411001', 'oipladmin@optimos.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(485, 'I00027', 'INGERSOLL RAND (INDIA) LIMITED', '1', '1', '1', 'YOGESH MATHUR', '7774088008', '1', 'SURVEY NO. 255/01/08, HINJEWADI,', 'TALUKA MULSI, NEXT TO YES BANK', '', 'PUNE', '1', 'India', '411057', 'yogesh.mathur@irco.com', '', '67929103', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(486, 'N00026', 'NEELESH KANADE GROUP', '1', '1', '1', 'MR.ANAND KONDE', '8888841695', '16', '1073, BHOSALE MYSTICA,', 'NEXT TO FIAT SHOWROOM,', 'MODEL COLONY, PUNE', 'PUNE', '1', 'India', '411016', 'anand@ncordhealthcareusa.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(487, 'S00238', 'SENSATA TECHNOLOGIES', '1', '1', '1', 'MR.SIDDHARTH KINNARE', '702855674', '1', '1ST FLOOR BLOCK -A, SAI TRINITY,', 'PASHAN SUS ROAD,PUNE', '', 'PUNE', '1', 'India', '411045', 'sonawane_deepti@sensata.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(488, 'A00076', 'ASHTEKAR JWELLERS', '1', '1', '7', 'TUSHAR ASHTEKAR', '30', '22', 'WAGHOLI', '', '', 'PUNE', '1', 'India', '0', 'hrmbashtkar@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(489, 'N00027', 'NEELESH KANADE GROUP ( SUS ROAD )', '1', '1', '1', 'ANAND KONDE', '8888841695', '1', 'SUS ROAD', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(490, 'A00077', 'AYOKI FABRICON PVT.LTD.(SYENTA)', '1', '1', '1', 'CAPT.RR SHASHIKUMAR-', '9545332424', '22', 'H.0137&139, AKSHAY COMPLEX,', 'DHOLE PATIL ROAD,', 'PUNE 411 001', 'PUNE', '1', 'India', '411001', 'prs@ayokifabricon.com', 'sunilgaikwad@ayokifabricon.com', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(491, 'H00026', 'HURIX SYSTEMS PRIVATE LIMITED', '1', '1', '1', 'MR.DARSHAN PUROHIT', '9867555880', '14', 'UNIT NO. 9&10, 5TH FLOOR,CENTRAL WING', 'SAI TRINITY  PASHAN  PUNE-411021', 'MAHARASHTRA', 'PUNE', '1', 'India', '411021', 'darshan.purohit@hurix.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(492, 'H00027', 'HAN KUK INN PVT LTD', '1', '1', '1', 'RAVI JACOB', '9923200201', '22', 'SR. NO. 232/1+2,PLOT .NO. 46/47 A ,', 'LANE-12,SAKORE NAGAR,', 'VIMAN NAGAR', 'PUNE', '1', 'India', '410014', 'jacobarirang @gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(493, 'I00028', 'IMPERIAL AUTO INDUSTRIES LTD.*', '1', '1', '1', 'MR.AJIT PRABHUNE', '8411005992', '7', 'PLOT NO.A-13, CHAKAN INDUSTRIAL AREA', 'PHASE 4, NIGHOJE, CHAKAN, PUNE 410501', '', 'PUNE', '1', 'India', '410501', 'hrpune@impauto.com', '', '2114662900', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(494, 'P00071', 'PATEL  OSWAL HOUSING', '1', '1', '7', '', '0', '16', 'SWASTIK  HOUSE,39/D,GULTEKDI,JN MARG,', 'PUNE 37', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(495, 'N00028', 'NICHE  SOFTWARE SOLUTION   PVT LTD', '1', '1', '7', '', '0', '16', 'SWASTIK  HOUSE ,39/D,GULTEKDI,JN MARG,', 'PUNE  37', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(496, 'H00028', 'HRIDAAN  MOTORS LTD.', '1', '1', '7', 'ANUP  DHARIWAL', '9422011110', '7', 'OPP.LUMAX  COMPANY.TELCO ROAD MIDC', 'CHINCHWAD,PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(497, 'J00018', 'JVS COMATSCO INDUSTRIES PVT LTD', '1', '1', '1', '', '0', '16', 'SWASTIK  HOUSE,39/D,GULTEKDI,JN MARG', 'PUNE37', '', 'PUNE', '1', 'India', '0', 'dskshirsagar@silworld.in', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(498, 'K00030', 'KAIYUAN  WELDING& CUTTING AUTOMATION INDIA PVT LTD', '1', '1', '7', 'MR.VIKAS SHERE', '7755934568', '1', 'SURVEY  NO.255/2/4,HINJEWADI,TALUKA', 'MULSI,PUNE-411057', '', 'PUNE', '1', 'India', '411057', 'Shere.vikas@kaiyuan.in', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(499, 'C00083', 'CITY PRIDE MULTIPLEX', '1', '1', '7', 'SUGAT THORAT', '9922901445', '16', 'NEAR BIG BAZAR,', 'KOTHRUD PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(500, 'S00240', 'SHREE  DATTA  DEVASTHAN TRUST(TAPOVAN SITE)', '1', '1', '6', 'MADAM  MEGHANA MALU', '9850730773', '22', 'SHRI DATTA  DEVASTHAN TRUST', 'PREM DAN  CHOWK,OPP NOBEL', 'HOSPITAL AT POST  SAVADI', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(501, 'S00241', 'SHREE  DATTA  DEVASTHAN  TRUST (NAGAPUR  PLOT )', '1', '1', '1', 'MADAM  MEGHANA  MALU', '9850730773', '22', '', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(502, 'S00242', 'SPAN  OVERSEAS PVT. LTD.', '1', '1', '7', 'MR UNNI  KRISHNAN', '9823730095', '22', 'BUNGLOW NO.23, SAMRAT CO-OP HOUSING', 'SOCIETY, KALYANI NAGAR, PUNE', '', 'PUNE', '1', 'India', '0', 'accounts@spanpune.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(503, 'P00072', 'PRABHA ENGINEERING', '1', '1', '1', 'PRADEEP KENJALE', '7722092561', '1', 'SHELKEWADI, HINJEWADI,', 'PIRANGUT ROAD, MULSHI, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(504, 'D00059', 'DHARIWAL INDUSTRIES PVT LTD (DIV. MANIKCHAND PACKAGING)', '1', '1', '1', 'SHARAD KULKARNI', '9552550402', '9', 'DIVISION-MANIKCHAND PACKAGING', 'GAT NO1524-1528 PUNE NAGAR RD', 'SARADWADI TAL SHIRUR', 'PUNE', '1', 'India', '0', 'sharad.kulkarni@manikchandpackaging.com', '', '9011687930', '0', '912026057377', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(505, 'D00060', 'DHARIWAL INDUSTRIES PVT.LTD.SARADWADI', '1', '1', '7', '', '0', '9', 'GAT NO.1526,1528 & PARTLY ON', 'GAT NO1524/2  AT.SARADWADI.TAL.SHIRUR', '(GHODNADI),DIST.PUNE 412210', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(506, 'I00029', 'IDIADA AUTOMOTIVE TECHNOLOGY INDIA PVT. LTD.(HADAPSAR)', '1', '1', '1', '', '0', '14', 'PLOT NO.4, RAMTEKDI INDUSTRIAL ESTATE', 'INDUTRAIAL TOWN PLANNING SCHEME NO.2', 'VILL.HADAPSAR, TAL.HAVELI, PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(507, 'A00078', 'AEI  POWER  INDIA  PVT.LTD', '1', '1', '7', 'DODWADKAR', '9850881941', '16', 'OFF.UNIT NO.C3, MULA ROAD, KOHINOOR COOP', 'HSG. SOC. MUMBAI PUNE RD, PUNE 411003', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(508, 'A00079', 'AEI  POWER  INDIA  PVT.LTD  HK', '1', '1', '1', 'DODWADKAR', '9850881941', '16', 'KHANNA HOUSE, GROUND FLOOR', 'PLOT NO 39 & 40, PIMPARI, PUNE 411018', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(509, 'D00061', 'DELOITTE HASKINS & SELLS LLP ( 3RD FLOOR)', '1', '1', '1', '', '0', '3', '706, B WING, 7TH FLOOR, ICC TRADE TOWER,', 'INTERNATIONAL CONVENTION CENTRE,', 'SENAPATIBAPAT ROAD, PUNE16', 'PUNE', '1', 'India', '0', 'kevaidya@deloitte.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(510, 'A00080', 'AMARKANTAK FOODS PVT. LTD.', '1', '1', '1', 'ADIL USMANI', '9754009401', '9', '16, FOODS PARK,MANERI-481885', 'DIST.MANDLA ,MADHYA  PRADESH', '', 'PUNE', '1', 'India', '481885', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(511, 'V00024', 'VIRTUOSO  INFOTECH  PRIVATE  LIMITED.', '1', '1', '1', 'YOGESH SATPUTE', '9765012349', '1', '4TH FLOOR, VITORY LAND MARK', 'OPP. D MART BEHIND DOMINOS', 'PIZZA BANER', 'PUNE', '1', 'India', '411045', 'yogesh.satpute@virtuosoinfotech.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(512, 'C00084', 'CLOVER BELVEDERE COOP HOUSING SOCIETY LTD.', '1', '1', '1', 'RAJAN THADANI', '41228607', '14', 'SOPAN BAUG, GHORPADI,', 'PUNE - 411 001', '', 'PUNE', '1', 'India', '0', 'clover.belvedere@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(513, 'R00051', 'DHARIWAL INDUSTRIES PVT.LTD. (SITE-KOREGAON PARK)', '1', '1', '1', '', '0', '22', 'MANICHAND BUNGLOW 79, 80, LANE NO.4', 'KOREGAON PARK, PUNE 411001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(514, 'R00052', 'RM DHARIWAL  HUF - PUSHPAK BUNGLOW', '1', '1', '1', 'PRAKASH SETH', '0', '16', 'PUSHPAK BUNGLOW NO.2, MORA SOCIETY,', 'LAW COLLEGE ROAD, KOTHRUD, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(515, 'I00030', 'IMPERIAL  AUTO  IND.LTD.NIGHOJE (CHAKAN)', '1', '1', '1', 'MR AJIT PRABHUNE', '8411005992', '7', 'PLOT NO.A 13, PHASE  IV  MIDC,', 'VILLAGE  NIGHOJE CHAKAN.', '', 'PUNE', '1', 'India', '410501', 'hrpune@impauto.com', '', '2114662900', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(516, 'C00085', 'CHAMP ENGINEERING PVT. LTD.', '1', '1', '1', 'ACHAL KOTECHA', '0', '7', 'GAT NO.167/170, AT PO. KURULI', 'PUNE 410501', '', 'PUNE', '1', 'India', '410501', 'marketing@achalindustries.co.in', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(517, 'P00073', 'POONA WAREHOUSING PVT.LTD.', '1', '1', '1', 'PATIL', '9011057616', '3', 'OFF. PUNE RAILWAY STATION , NEAR TO', 'SATKAR HOTEL, PUNE 411001', '', 'PUNE', '1', 'India', '411001', 'contact@taleragroup.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(518, 'D00062', 'DECISIV EDGE TECHNOLOGY SERVICES INDIA PVT. LTD.', '1', '1', '1', 'ANTHONY', '8888435951', '22', 'PENTAGON 1,  102,  CYBER CITY,', 'MAGARPATTA, PUNE 13.', '', 'PUNE', '1', 'India', '0', 'anthony.handa@decisivedge.com', '', '2065002173', '2065002177', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(519, 'S00243', 'S BALAN MAINTENANCE DIVISION (SAI HIRA)', '1', '1', '1', '', '0', '22', 'SAI CHAMBER, WAKDEWADI,', 'MUMBAI PUNE ROAD, PUNE', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(520, 'S00244', 'SCREEN MAGIC MOBILE MEDIA PVT. LTD.', '1', '1', '1', 'RAGHAVENDERA', '9970388833', '22', 'OFFICE NO - 201 & 204, PRIDE HOUSE,', 'NEAR UNIVERSITY CIRCLE, SHIVAJI NAGAR,', 'PUNE - 411016', 'PUNE', '1', 'India', '0', 'raghavendra@screen-magic.com', '', '8668743611', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(521, 'H00029', 'HAN  KUN  INN  PVT  LTD.', '1', '1', '7', 'RAVI  JACOB', '9923200201', '22', 'S.NO  6/2 /24+ 25/1  NEAR   RELANCE', 'MART OPP. ZENSAR  KHARADI', 'PUNE 411014', 'PUNE', '1', 'India', '411014', 'hankuninnpune@gmail.com', '', '7767816623', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(522, 'I00031', 'IMPERIAL AUTO INDUSTRIES LTD.', '1', '1', '1', 'MR.AJIT PRABHUNE', '8411005992', '7', 'PLOT NO.A-13, CHAKAN INDUSTRIAL AREA', 'PHASE 4, NIGHOJE, CHAKAN, PUNE 410501', '', 'PUNE', '1', 'India', '410501', 'hrpune@impauto.com', '', '2114662900', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(523, 'I00032', 'IMPERIAL AUTO INDUSTRIES LTD (BOUNCER)', '1', '1', '1', '', '0', '7', '', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(524, 'B00070', 'BHAGWATI CARS PVT. LTD.', '1', '1', '1', 'CHANDNI', '9834742913', '3', '3 CASTELLINO ROAD, NEAR GOLIBAR', 'MAIDAN, PUNE 1', '', 'PUNE', '1', 'India', '0', '', 'SHIRISH KALURAKR 9921666237', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(525, 'A00081', 'ACHAL INDUSTRIES', '1', '1', '1', 'MR JADHAV', '0', '7', '56/6 D-2 BLOCK, MIDC CHINCHWAD', 'PUNE 411019', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(526, 'I00033', 'H & M EVENTS', '1', '1', '1', 'POONAM PAWAR', '7774062211', '22', 'TANISHQ BOUTIQUE, SR.NO.207, SHOP', 'NO.12/A, GROUND FLOOR, PHOENIX', 'MARKET CITY, VIMANNAGAR, PUNE 14', 'PUNE', '1', 'India', '411014', '', '', '67071111', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(527, 'I00034', 'ISHANYA MOTORS  LLP', '1', '1', '1', 'POONAM PAWAR', '7774062211', '3', 'S.NO.1, AMBEGAON, KATRAJ BYPASS', 'ROAD, NEAR POTDAR SCHOOL, PUNE', '', 'PUNE', '1', 'India', '411046', '', 'poonam@ishanyamotors.com', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(528, 'R00053', 'RMD FOODS  AND BEVERAGES PVT. LTD.', '1', '1', '1', 'TEENA', '0', '22', 'GAT NO.283, AT VITACHAMALA GRAM', 'PANCHAYAT, MAUJE WADE BOLAI,', 'PUNE', 'PUNE', '1', 'India', '0', 'hankukinnpune@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(529, 'A00082', 'ANAND ENGINEERING WORKS', '1', '1', '1', 'MRS.UMITA JADHAV', '7709040651', '9', 'GATT NO.352, KASURDI(KB),', 'KHED SHIVAPUR, TAL - BHOR,', 'PUNE', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(530, 'G00024', 'GIIAVA  (INDIA) PVT LTD - SITE - WAI', '1', '1', '1', 'RAJESH AGNIHOTRI', '9325002886', '3', 'WAI', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(531, 'V00025', 'VULCAN FORCE FACILITY MANAGEMENT (I) PVT. LTD.', '1', '1', '4', '', '0', '14', '6A&B SIDDHARTH COURT, 196', 'DHOLE PATIL ROAD, PUNE - 411001', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(532, 'P00074', 'PUNIT BALAN ENTERTANMENT  PVT LTD', '1', '1', '7', 'PREETI', '9860098669', '16', '605 SAI CHAMBER 16 PUNE MUMBAI ROAD', 'PUNE 411003', '', 'PUNE', '1', 'India', '411003', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(533, 'S00245', 'SAI CONSTRUCTION PVT.LTD', '1', '1', '6', 'PREETI', '2025541136', '16', '605 SAI CHAMBER 16 MUMBAI PUNE ROAD', 'WAKDEWADI PUNE 411003', '', 'PUNE', '1', 'India', '411003', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(534, 'E00020', 'ELECTRONICS INDIA', '1', '1', '1', 'MR. NIRJAN VILSAGAR', '9822395558', '9', 'GATE NO 682 PLOT NO 22 AP', 'VELU TAL. BHOR DIST PUNE', '', 'PUNE', '1', 'India', '0', 'selas@electronicsindiapune', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(535, 'B00071', 'BERJIS DESAI', '1', '1', '1', 'RAVI (SECRETARY)', '9892921836', '22', 'PRAJ TOWER, 274,275, BHUMKAR CHOWK', 'HINJEWADI', '', 'PUNE', '1', 'India', '411057', 'ravi@berjisdesai.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(536, 'I00035', 'IMPERIAL AUTO INDUSTRIES LTD.(O T)', '1', '1', '1', 'RAVI DHUTEKAR', '0', '7', 'CHAKHAN', '', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(537, 'H00030', 'HAOSEN AUTOMATION INDIA PVT. LTD.', '1', '1', '1', 'SHROPAD KULKARNI', '7770015767', '1', 'SR.NO.255/1/8,  HINJEWADI', 'PHASE - I, TAL MULSI DIST PUNE 411057', '', 'PUNE', '1', 'India', '0', '', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(538, 'P00075', 'PRAJ INDUSTRIES LTD.', '1', '1', '1', 'GANESH PADEKAR', '9890300301', '9', 'PRAJ TOWERR 274/275 BHUMKAR CHOWK', 'HINJWADI', '', 'PUNE', '1', 'India', '0', 'ganeshpadekar@praj.net', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(539, 'D00063', 'MEGTEC SYSTEM INDIA PVT LTD', '1', '1', '1', 'PADMAKAR JAGTAP', '9623035561', '16', '81/5, SHED K, VILLAGE SHIVNE, TALUKA', 'HAVELI  PUNE', '', 'PUNE', '1', 'India', '411023', 'padmakar_jagtap@megtec.in', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(540, 'S00246', 'SAI STONE CRUSHER', '1', '1', '1', 'SANDEEP AMBURE', '8888824909', '7', 'SAI HOUSE, 70 KADOLKAR COLONY,', 'OPP. STATE BANK OF INDIA. TALEGAON', 'DABHADE PUNE', 'PUNE', '1', 'India', '410506', 'saistonecrusher@gmail.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(541, 'I00036', 'INTOX PVT. LTD.', '1', '1', '7', 'DR. M P PORE', '9822024386', '2', '375, URAWADE,  TAL - MULSHI', 'PUNE- 412115', '', 'PUNE', '1', 'India', '412115', 'hr@intoxlab.com', 'mppre@intoxlab.com', '8879387567', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(542, 'N00029', 'NYATI BUILDERS PVT. LTD.', '1', '1', '13', 'MILAN THAKKAR', '0', '22', 'NAYATI UNITREE, 6TH FLOOR', 'NAGAR ROAD, YERAWADA,PUNE 411006', '', 'PUNE', '1', 'India', '411006', 'milan@nyatigroup.com', '', '7796687871', '9623200777', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(543, 'I00037', 'INFIILOOM INDIA PRIVATE LIMITED', '1', '1', '7', 'SIDDA MOHAPATRA', '7066234340', '22', '304,305 SKY VISTA SURVEY NO 230A/3/2 NEW', 'AIRPORT ROAD VIMAN NAGER PUNE', '', 'PUNE', '1', 'India', '411014', 'siddhamohapatra@infiiloom.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(544, 'I00038', 'ISON BPO PVT LTD', '1', '1', '7', 'YOGESH SAHANE', '7620584351', '22', 'BITA 2 GEEGA SPACE, FOURTH FLOOR, VIMAN', 'NAGAR, PUNE - 411014', '', 'PUNE', '1', 'India', '411014', 'rana@isonxperiences.com', '', '0', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56'),
(545, 'G00025', 'GREENJOULES PVT.LTD', '1', '1', '7', 'GIRIJA RAJPOOT', '8956722946', '7', 'PLOT NO. PAP B-77, VARALE MIDC,', 'PHASE - II, TEHSIL- KHED, CHAKAN', 'PUNE - 410501', 'PUNE', '1', 'India', '410501', 'vradhika@greenjoules.in', '', '8956722946', '0', '0', '1', '2021-04-05 11:31:56', '2021-04-05 11:31:56');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE `tbl_company` (
  `fd_company_id` int(11) NOT NULL,
  `fd_company_name` varchar(255) NOT NULL,
  `fd_address` longtext NOT NULL,
  `fd_city` varchar(255) NOT NULL,
  `fd_state` varchar(255) NOT NULL,
  `fd_country` varchar(255) NOT NULL,
  `fd_pincode` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`fd_company_id`, `fd_company_name`, `fd_address`, `fd_city`, `fd_state`, `fd_country`, `fd_pincode`, `created_at`, `updated_at`) VALUES
(2, 'Perfect Protection India Pvt Ltd', 'Kirkee', 'Pune', 'Maharashtra', 'India', '412115', '2021-03-17 18:48:43', '2021-03-17 18:48:43'),
(3, 'Care', 'Kirkee', 'Pune', 'Maharashtra', 'India', '412115', '2021-03-17 18:49:03', '2021-03-17 18:49:03'),
(4, 'White Hawk', 'Kirkee', 'Pune', 'Maharashtra', 'India', '412115', '2021-03-17 18:49:28', '2021-03-17 18:49:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_designation`
--

CREATE TABLE `tbl_designation` (
  `fd_designation_id` int(11) NOT NULL,
  `fd_designation` varchar(500) NOT NULL,
  `fd_hsncode` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_designation`
--

INSERT INTO `tbl_designation` (`fd_designation_id`, `fd_designation`, `fd_hsncode`, `created_at`, `updated_at`) VALUES
(1, 'FINANCE MANAGER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(2, 'MANAGING DIRECTOR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(3, 'GENERAL MANAGER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(4, 'GENERAL MANAGER OPERATION', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(5, 'AREA MANAGER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(6, 'AREA MANAGER 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(7, 'AREA MANAGER 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(8, 'AREA MANAGER 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(10, 'ACCT 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(11, 'ACCT 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(12, 'ACCTS HEAD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(13, 'ADMIN', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(14, 'ADMIN 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(15, 'AREA MANAGER 4', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(16, 'AREA MANAGER 5', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(17, 'AREA MANAGER 6', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(18, 'AREA MANAGER5', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(19, 'ASST. STROE KEEPER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(20, 'BRANCH MANAGER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(21, 'CASHIER 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(22, 'CLERK 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(23, 'CLERK 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(24, 'CLERK 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(25, 'CLERK 4', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(26, 'CLERK 5', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(27, 'CLERK III', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(28, 'CO 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(29, 'CO 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(30, 'CO 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(31, 'CO 4', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(32, 'COMP HEAD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(33, 'COMP.OP III', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(34, 'COMPUTER HEAD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(35, 'DRIVER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(36, 'DRIVER 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(37, 'ENGINEERS', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(38, 'ESI CLERK 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(39, 'ESI CLERK 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(40, 'ESI HEAD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(41, 'FIELD EXECUTIVE', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(42, 'FIELD OFFICER 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(43, 'FIELD OFFICER 10', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(44, 'FIELD OFFICER 11', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(45, 'FIELD OFFICER 12', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(46, 'FIELD OFFICER 13', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(47, 'FIELD OFFICER 14', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(48, 'FIELD OFFICER 15', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(49, 'FIELD OFFICER 16', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(50, 'FIELD OFFICER 17', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(51, 'FIELD OFFICER 18', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(52, 'FIELD OFFICER 19', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(53, 'FIELD OFFICER 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(54, 'FIELD OFFICER 20', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(55, 'FIELD OFFICER 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(56, 'FIELD OFFICER 4', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(57, 'FIELD OFFICER 5', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(58, 'FIELD OFFICER 6', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(59, 'FIELD OFFICER 7', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(60, 'FIELD OFFICER 8', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(61, 'FIELD OFFICER 9', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(62, 'FIELD OFFICER II', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(63, 'FIELD OFFICER8', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(64, 'FIELD OFFICER9', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(65, 'GENERAL MANAGER 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(66, 'GUNMAN', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(67, 'JR. CO. HEAD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(68, 'JR. SECURITY GUARD', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(69, 'MANAGER TRAINING & ENROLL', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(70, 'MD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(71, 'OFFICE BOY', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(72, 'OS 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(73, 'PEON', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(74, 'PEON 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(75, 'RECPT 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(76, 'RECPT 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(77, 'SR. SECURITY GUARD', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(78, 'STAFF', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(79, 'STORES IC', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(80, 'SUPERVISOR', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(81, 'SWEEPER 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(82, 'SWEEPER 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(83, 'SWEEPER 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(84, 'WORKERS', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(86, 'ATTENDANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(88, 'CLEANING STAFF', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(89, 'CLEANING STAFF FULL', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(90, 'COBBLER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(91, 'COOK', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(92, 'DECURITY GUARD 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(93, 'DHOBI', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(94, 'DRIVER SKILLED', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(95, 'DRIVER UNSKILLED', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(96, 'ELECTRICIAN', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(97, 'EX MAN GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(98, 'FRONT OFFICE SUPERVISOR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(99, 'GARDNER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(100, 'HEAD SECURITY GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(101, 'J ATTENDANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(102, 'JR ATTENDANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(103, 'JR LOADER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(104, 'JR SECURITY GUARD', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(105, 'JR. ATTENDENT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(106, 'JR. COOK', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(107, 'JR. HEAD GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(108, 'JR. HOUSE KEEPING STAFF', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(109, 'JR. LADIES GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(110, 'SR.LADIES GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(111, 'JR. LIFTMAN', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(112, 'JR. LOADER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(113, 'JR. SECURITY OFFICER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(114, 'JR. SUPERVISOR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(115, 'JR. SWEEPER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(116, 'JR.DRIVER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(117, 'JR.GUNMAN', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(118, 'JR.LABOUR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(119, 'LIFTMAN 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(120, 'LIFTMAN 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(121, 'LIFTMAN SEMI SKILLED', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(122, 'LOADER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(123, 'LOADER SR GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(124, 'S  ATTENDANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(125, 'SECURITY GUARD 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(126, 'SECURITY GUARD 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(127, 'SECURITY GUARD 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(128, 'SECURITY GUARD 4', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(129, 'SECURITY GUARD 5', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(130, 'SECURITY GUARD 6', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(131, 'SECURITY GUARD 7', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(132, 'SECURITY GUARD 8', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(133, 'SECURITY GUARD 9', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(134, 'SECURITY GUARDS', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(135, 'SECURITY OFFICER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(136, 'SECURTY GUARD 6', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(137, 'SEMISKILLED LABOURS', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(138, 'SG AT BUNG (NIGHT)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(139, 'SG AT BUNGLOW  (NIGHT)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(140, 'SG EXTRA', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(141, 'SG LOBI', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(142, 'SG MAIN GATE', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(143, 'SG TRAFFIC', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(144, 'SHIRKE', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(145, 'SKILLED LABOURS', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(146, 'SPECIAL GUNMAN', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(147, 'SPECIAL SR.SECURITY GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(148, 'SR ATTENDANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(149, 'SR GUNMAN', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(150, 'SR. ATTENDANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(151, 'SR. ATTENDENT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(152, 'SR. COOK', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(153, 'SR. HEAD GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(154, 'SR. HOUSE KEEPING  STAFF', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(155, 'SR. LABOUR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(156, 'LADY GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(157, 'SR. LADY GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(158, 'SR. LIFTMAN', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(159, 'SR. LOADER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(160, 'SR. SECURITY GUARDS', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(161, 'SR. SUPERVISOR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(162, 'SR. SWEEPER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(163, 'SR.DRIVER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(164, 'SR.GUNMAN', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(165, 'SR.SECURITY OFFICER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(166, 'SWEEPER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(167, 'SWEEPER   I', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(168, 'SWEEPER   II', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(169, 'SWEEPER  III', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(170, 'SWEEPER  IV', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(171, 'SWEEPER  V', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(172, 'SWEEPER AT BUNGLOW', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(173, 'SWEEPER RELIEVER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(174, 'SWIMMING POOL INCHARGE', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(175, 'TAILOR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(176, 'TEMPORARY COOK', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(177, 'UNSKILLED LABOURS', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(178, 'TRAFFIC ATTENDANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(179, 'AREA M', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(180, 'AREA M1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(181, 'AREA MANAGER 7', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(182, 'NIKI INTERNATIONAL', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(183, 'SR.GUNMAM', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(184, 'GUARD PARKING', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(185, 'HOUSEKEEPING STAFF 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(186, 'ADMIN OFFICER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(187, 'HEAD GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(188, 'MOBILE CHARGES', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(189, 'VIGILANCE OFFICER', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(190, 'VIGILANCE OFFICER 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(191, 'VIGILANCE OFFICER 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(192, 'MANAGER OPERATION', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(193, 'VIGILANCE OFFICER 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(194, 'COMPUTER OPERATOR', '998513', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(195, 'DETECTIVE', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(196, 'FIELDER III', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(197, 'GENERAL MANAGER 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(198, 'RECEPTION 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(199, 'MARKETING MANAGER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(200, 'FIELD OFFICER 20', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(201, 'FEILD OFFICER 21', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(202, 'OS 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(203, 'BODY GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(204, 'FEILD OFFICER V', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(205, 'SERVICE CHARGES', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(206, 'SURVELLANCE STAFF', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(207, 'LEGAL', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(208, 'SECURITY NIGHT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(209, 'GUNMAN(E)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(210, 'SECURITY (E)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(211, 'SUPERVISOR (EXMAN)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(212, 'SUPERVISOR (CIVIL)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(213, 'GUARD (EXMAN)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(214, 'GUARD (CIVIL)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(215, 'GUNMAN (SPECIAL)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(216, 'GUNMAN (EXMAN)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(217, 'CCTV SURVELLANCE STAFF', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(218, 'SURVELLANCE STAFF II', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(219, 'MANAGAR OPRATION (I)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(220, 'MANAGER OPERATION(1)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(221, 'DRIVER(I)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(222, 'UNARMED', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(223, 'UNARMED SECURITY GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(224, 'UNARMED SECURITY GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(225, 'AREA MANAGER MIII  12000', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(226, 'UNARMED S/GUARD(OT)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(227, 'FIELD OFFICER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(228, 'FIELD OFFICER - 5', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(229, 'PARKING GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(230, 'SUPERVISOR 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(231, 'SUPERVISOR 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(232, 'AREA MANAGER - 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(233, 'SUPERVISOR -1(CIVIL)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(234, 'CCTV SURVELLANCE STAFF 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(235, 'COMPUTER OPERATOR-1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(236, 'DRIVER OT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(237, 'ASST.GEN.MANAGER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(238, 'STORE KEEPER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(239, 'GUNMAN-( OT )', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(240, 'DIRECTOR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(241, 'MANAGER-TRAINING', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(242, 'AREA MANAGER - 2', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(243, 'ARREARS', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(244, 'SECURITY GUARD (LADY)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(245, 'SUPERVISOR (FIRE)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(246, 'GUARD (FIRE)', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(247, 'ATTENDANT GUARD', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(248, 'ATTENDANT SUPERVISOR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(249, 'DG OPERATOR', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(250, 'FIRE GUARD CUM EXECUTIVE', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(251, 'SECURITY OFFICER-1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(252, 'AREA MANAGER - 3', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(253, 'FIELD OFFICER - 6', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(254, 'OPERATION MANAGER JR.', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(255, 'FIELD OFFICER-7', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(256, 'ACCOUNT ASSISTANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(257, 'ACCOUNTANT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(258, 'MANAGER TRAINING 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(259, 'LOADER OT', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(260, 'BARIER GUARD', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(261, 'CLEANING MATERIAL', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(262, 'BOUNCER', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(263, 'FIELD OFFICER 1', '1', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(264, 'BOUNCER 1', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(265, 'ADVISOR', '998513', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(266, 'ADVISOR 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(267, 'OPERATION MANAGER', '998513', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(268, 'FIELD OFFICER 001', '998513', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(269, 'FIELD OFFICER 002', '998513', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(270, 'S/G', '998513', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(271, 'BUSINESS DEVELOPMENT', '880589', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(272, 'FIELD OFFICER 17', '985687', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(273, 'F/O 001', '258964', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(275, 'SEC. GUARD TRAINING FEES', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(276, 'TRAINING REGISTRATION', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(277, 'MARKITING MANAGER', '998513', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(278, 'BODYGUARD', 'VI', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(279, 'BODY GUARD 1', '854695', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(280, 'PISTALMAN', '856974', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(281, 'VIGILANCE OFFICER', '895642', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(282, 'ACCOUNT', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(283, 'GANARAL MANAGER', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(284, 'GANARAL MANAGER 1', '', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(285, 'BRANCH MANAGER', '998513', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(286, 'BOUCER 2', '895624', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(287, 'NAGER MARKETING OPERATION', '656565', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(288, 'JR.LADY GUARD', '452653', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(289, 'SR. LADY GUARD', '423651', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(290, 'CLIENT RELETION MANAGER', '815634', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(291, 'SALARY COMPUTER OP 1', '521463', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(292, 'ACCOUNTANT BACK OFFICE', '521463', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(293, 'STORE KEEPER 1', '524163', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(294, 'BOUNCER 3', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(295, 'SALARY DEP HEAD', '253614', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(296, 'HR ADMIN', '995813', '2021-04-05 11:39:01', '2021-04-05 11:39:01'),
(297, 'TRAFFIC WARDEN', '998525', '2021-04-05 11:39:01', '2021-04-05 11:39:01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_document`
--

CREATE TABLE `tbl_document` (
  `fd_document_id` int(11) NOT NULL,
  `fd_document` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_document`
--

INSERT INTO `tbl_document` (`fd_document_id`, `fd_document`, `created_at`, `updated_at`) VALUES
(1, 'Education Certificates', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(2, 'School Leaving', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(3, 'Ration Card', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(4, 'Electricity Bill', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(5, 'PAN Card', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(6, 'Driving License', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(7, 'Gun Licence', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(8, 'Government ID', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(9, 'Voter Card', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(10, 'Aadhar Card', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(11, 'Training Certificates', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(12, 'Police Verification', '2021-04-05 11:42:56', '2021-04-05 11:42:56'),
(13, 'Ex-Man Discharge', '2021-04-05 11:42:56', '2021-04-05 11:42:56');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `fd_employee_id` int(11) NOT NULL,
  `fd_employee_code` varchar(100) NOT NULL,
  `fd_employee_type` varchar(200) NOT NULL,
  `fd_surname` varchar(255) NOT NULL,
  `fd_firstname` varchar(255) NOT NULL,
  `fd_mname` varchar(255) DEFAULT NULL,
  `fd_birthdate` varchar(100) NOT NULL,
  `fd_age` int(11) NOT NULL,
  `fd_education` varchar(255) DEFAULT NULL,
  `fd_nominee` varchar(255) DEFAULT NULL,
  `fd_nominee_age` int(11) DEFAULT NULL,
  `fd_nominee_relation` varchar(255) DEFAULT NULL,
  `fd_leftdate` varchar(100) DEFAULT NULL,
  `fd_reason_of_leaving` varchar(255) DEFAULT NULL,
  `fd_name_in_bank` varchar(255) DEFAULT NULL,
  `fd_pf_name` varchar(255) DEFAULT NULL,
  `fd_pf_memberId` varchar(200) DEFAULT NULL,
  `fd_joining_date` varchar(100) DEFAULT NULL,
  `fd_confirmation_date` varchar(100) DEFAULT NULL,
  `fd_icard_issue_date` varchar(100) DEFAULT NULL,
  `fd_renewal_date` varchar(100) DEFAULT NULL,
  `fd_tr_deposit` int(11) DEFAULT NULL,
  `fd_esi` int(11) DEFAULT NULL,
  `fd_esi_number` varchar(100) DEFAULT NULL,
  `fd_smartcard_issued` varchar(100) DEFAULT NULL,
  `fd_uid_no` varchar(255) DEFAULT NULL,
  `fd_sex` varchar(10) DEFAULT NULL,
  `fd_rejoining` int(11) DEFAULT NULL,
  `fd_bank_ac_closed` int(11) DEFAULT NULL,
  `fd_mlwf` int(11) DEFAULT NULL,
  `fd_pf` int(11) DEFAULT NULL,
  `fd_pf_number` varchar(255) DEFAULT NULL,
  `fd_pf_withdrawal` int(11) DEFAULT NULL,
  `fd_pf_withdrawal_date` varchar(100) DEFAULT NULL,
  `fd_submission_date` varchar(100) DEFAULT NULL,
  `fd_settlement_date` varchar(100) DEFAULT NULL,
  `fd_cheque_number` varchar(255) DEFAULT NULL,
  `fd_p_tax` int(11) DEFAULT NULL,
  `fd_aadhar_name_mismatch` int(11) DEFAULT NULL,
  `fd_addhar_birthdate_yearonly` int(11) DEFAULT NULL,
  `fd_status` varchar(30) NOT NULL,
  `fd_createtime` timestamp NOT NULL DEFAULT current_timestamp(),
  `fd_updatetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`fd_employee_id`, `fd_employee_code`, `fd_employee_type`, `fd_surname`, `fd_firstname`, `fd_mname`, `fd_birthdate`, `fd_age`, `fd_education`, `fd_nominee`, `fd_nominee_age`, `fd_nominee_relation`, `fd_leftdate`, `fd_reason_of_leaving`, `fd_name_in_bank`, `fd_pf_name`, `fd_pf_memberId`, `fd_joining_date`, `fd_confirmation_date`, `fd_icard_issue_date`, `fd_renewal_date`, `fd_tr_deposit`, `fd_esi`, `fd_esi_number`, `fd_smartcard_issued`, `fd_uid_no`, `fd_sex`, `fd_rejoining`, `fd_bank_ac_closed`, `fd_mlwf`, `fd_pf`, `fd_pf_number`, `fd_pf_withdrawal`, `fd_pf_withdrawal_date`, `fd_submission_date`, `fd_settlement_date`, `fd_cheque_number`, `fd_p_tax`, `fd_aadhar_name_mismatch`, `fd_addhar_birthdate_yearonly`, `fd_status`, `fd_createtime`, `fd_updatetime`) VALUES
(1, 'S123123', 'guard', 'Testing', 'Name', '', '', 30, '', '', 0, '', '', '', '', '', '', '', '', '', '', 0, 0, '', '', '', '', 0, 0, 0, 0, '', 0, '', '', '', '', 0, 0, 0, 'active', '2021-03-15 16:01:50', '2021-03-15 16:01:50');

-- --------------------------------------------------------

--
-- Table structure for table `transfers`
--

CREATE TABLE `transfers` (
  `id` int(10) UNSIGNED NOT NULL,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `shipping_cost` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transfers`
--

INSERT INTO `transfers` (`id`, `reference_no`, `user_id`, `status`, `from_warehouse_id`, `to_warehouse_id`, `item`, `total_qty`, `total_tax`, `total_cost`, `shipping_cost`, `grand_total`, `document`, `note`, `created_at`, `updated_at`) VALUES
(1, 'tr-20180808-051710', 1, 1, 2, 1, 1, 100, 0, 100, 0, 100, NULL, NULL, '2018-08-08 11:17:10', '2018-12-24 22:16:55'),
(6, 'tr-20191205-075504', 1, 1, 1, 2, 1, 1, 0, 2, 0, 2, NULL, NULL, '2019-12-05 13:55:04', '2019-12-05 14:09:42'),
(8, 'tr-20200122-123058', 1, 1, 1, 2, 1, 10, 0, 1000, NULL, 1000, NULL, NULL, '2020-01-22 06:30:58', '2020-01-22 06:30:58');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(10) UNSIGNED NOT NULL,
  `unit_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_unit` int(11) DEFAULT NULL,
  `operator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation_value` double DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `unit_code`, `unit_name`, `base_unit`, `operator`, `operation_value`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'pc', 'Piece', NULL, '*', 1, 1, '2018-05-12 02:27:46', '2018-08-17 21:41:53'),
(2, 'dozen', 'dozen box', 1, '*', 12, 1, '2018-05-12 09:57:05', '2018-05-12 09:57:05'),
(4, 'm', 'meter', NULL, '*', 1, 0, '2018-05-12 09:58:07', '2021-03-12 08:44:05'),
(7, 'kg', 'kilogram', NULL, '*', 1, 1, '2018-06-25 00:49:26', '2018-06-25 00:49:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `company_name`, `role_id`, `is_active`, `created_at`, `updated_at`) VALUES
(18, 'admin', 'ravi.d.jadhav@gmail.com', 'admin', '9960664553', 'Blucorsys', 1, 1, '2020-12-01 03:59:55', '2020-12-01 03:59:55'),
(19, 'ravi jadhav', 'ravi@blucorsys.com', 'asdasd', '9960664553', '', 1, 0, '2021-02-16 09:13:56', '2021-03-17 13:14:04'),
(20, 'ravijadhav89', 'ravi@gmail.com', 'admin', '9981923981', '', 4, 1, '2021-03-12 08:57:33', '2021-03-17 10:09:37'),
(21, 'ravijadhav', 'ravitesting@gmail.com', 'admin', '9960664553', '', 2, 0, '2021-03-17 10:23:53', '2021-03-17 11:03:44');

-- --------------------------------------------------------

--
-- Table structure for table `variants`
--

CREATE TABLE `variants` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `variants`
--

INSERT INTO `variants` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'Medium', '2019-11-21 07:03:04', '2019-11-24 08:43:52'),
(3, 'Small', '2019-11-21 07:03:04', '2019-11-24 08:43:52'),
(5, 'Large', '2019-11-24 06:07:20', '2019-11-24 08:44:56');

-- --------------------------------------------------------

--
-- Table structure for table `warehouses`
--

CREATE TABLE `warehouses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `warehouses`
--

INSERT INTO `warehouses` (`id`, `name`, `phone`, `email`, `address`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'warehouse 1', '2312121', 'war1@lion.com', 'khatungonj, chittagong', 1, '2018-05-12 07:51:44', '2019-03-02 15:40:17'),
(2, 'warehouse 2', '1234', NULL, 'boropul, chittagong', 1, '2018-05-12 08:09:03', '2018-06-19 22:30:38'),
(3, 'test', NULL, NULL, 'dqwdeqw', 0, '2018-05-30 00:14:23', '2018-05-30 00:14:47'),
(6, 'gudam', '2121', '', 'gazipur', 0, '2018-08-31 22:53:26', '2018-08-31 22:54:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adjustments`
--
ALTER TABLE `adjustments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendances`
--
ALTER TABLE `attendances`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `billers`
--
ALTER TABLE `billers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_groups`
--
ALTER TABLE `customer_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gift_cards`
--
ALTER TABLE `gift_cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gift_card_recharges`
--
ALTER TABLE `gift_card_recharges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `holidays`
--
ALTER TABLE `holidays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrm_settings`
--
ALTER TABLE `hrm_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `money_transfers`
--
ALTER TABLE `money_transfers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_with_cheque`
--
ALTER TABLE `payment_with_cheque`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_with_credit_card`
--
ALTER TABLE `payment_with_credit_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_with_gift_card`
--
ALTER TABLE `payment_with_gift_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_with_paypal`
--
ALTER TABLE `payment_with_paypal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payrolls`
--
ALTER TABLE `payrolls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pos_setting`
--
ALTER TABLE `pos_setting`
  ADD UNIQUE KEY `pos_setting_id_unique` (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_adjustments`
--
ALTER TABLE `product_adjustments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_purchases`
--
ALTER TABLE `product_purchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_quotation`
--
ALTER TABLE `product_quotation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_returns`
--
ALTER TABLE `product_returns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sales`
--
ALTER TABLE `product_sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_transfer`
--
ALTER TABLE `product_transfer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_warehouse`
--
ALTER TABLE `product_warehouse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_product_return`
--
ALTER TABLE `purchase_product_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotations`
--
ALTER TABLE `quotations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `returns`
--
ALTER TABLE `returns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `return_purchases`
--
ALTER TABLE `return_purchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_counts`
--
ALTER TABLE `stock_counts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taxes`
--
ALTER TABLE `taxes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  ADD PRIMARY KEY (`fd_branch_id`);

--
-- Indexes for table `tbl_client`
--
ALTER TABLE `tbl_client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`fd_company_id`);

--
-- Indexes for table `tbl_designation`
--
ALTER TABLE `tbl_designation`
  ADD PRIMARY KEY (`fd_designation_id`);

--
-- Indexes for table `tbl_document`
--
ALTER TABLE `tbl_document`
  ADD PRIMARY KEY (`fd_document_id`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`fd_employee_id`);

--
-- Indexes for table `transfers`
--
ALTER TABLE `transfers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `variants`
--
ALTER TABLE `variants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouses`
--
ALTER TABLE `warehouses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `adjustments`
--
ALTER TABLE `adjustments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendances`
--
ALTER TABLE `attendances`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `billers`
--
ALTER TABLE `billers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `customer_groups`
--
ALTER TABLE `customer_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `deliveries`
--
ALTER TABLE `deliveries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gift_cards`
--
ALTER TABLE `gift_cards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `gift_card_recharges`
--
ALTER TABLE `gift_card_recharges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `holidays`
--
ALTER TABLE `holidays`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `hrm_settings`
--
ALTER TABLE `hrm_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `money_transfers`
--
ALTER TABLE `money_transfers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=270;

--
-- AUTO_INCREMENT for table `payment_with_cheque`
--
ALTER TABLE `payment_with_cheque`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `payment_with_credit_card`
--
ALTER TABLE `payment_with_credit_card`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment_with_gift_card`
--
ALTER TABLE `payment_with_gift_card`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment_with_paypal`
--
ALTER TABLE `payment_with_paypal`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payrolls`
--
ALTER TABLE `payrolls`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `product_adjustments`
--
ALTER TABLE `product_adjustments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_purchases`
--
ALTER TABLE `product_purchases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `product_quotation`
--
ALTER TABLE `product_quotation`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `product_returns`
--
ALTER TABLE `product_returns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `product_sales`
--
ALTER TABLE `product_sales`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=334;

--
-- AUTO_INCREMENT for table `product_transfer`
--
ALTER TABLE `product_transfer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product_warehouse`
--
ALTER TABLE `product_warehouse`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `purchase_product_return`
--
ALTER TABLE `purchase_product_return`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `quotations`
--
ALTER TABLE `quotations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `returns`
--
ALTER TABLE `returns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `return_purchases`
--
ALTER TABLE `return_purchases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT for table `stock_counts`
--
ALTER TABLE `stock_counts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `taxes`
--
ALTER TABLE `taxes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  MODIFY `fd_branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_client`
--
ALTER TABLE `tbl_client`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=546;

--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `fd_company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_designation`
--
ALTER TABLE `tbl_designation`
  MODIFY `fd_designation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;

--
-- AUTO_INCREMENT for table `tbl_document`
--
ALTER TABLE `tbl_document`
  MODIFY `fd_document_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `fd_employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transfers`
--
ALTER TABLE `transfers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `variants`
--
ALTER TABLE `variants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `warehouses`
--
ALTER TABLE `warehouses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
