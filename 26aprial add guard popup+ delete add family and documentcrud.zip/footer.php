<?php
?>

<footer class="main-footer">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12">
        <p>2021 © Perfect Protection | Developed By <a target="_blank" href="https://blucorsys.com/" class="external">Blucor Systems Pvt Ltd.</a></p>
      </div>
    </div>
  </div>
</footer>
