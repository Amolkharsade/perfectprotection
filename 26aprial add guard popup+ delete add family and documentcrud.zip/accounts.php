<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/Account.php");
require_once("businessLogic/Common.php");
require_once("businessLogic/ExpenseCategory.php");
require_once("businessLogic/User.php");

$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="accounts";
session_start();

$database = new Database();
$db = $database->getConnection();
$account = new Account($db);
$common = new Common();
$user = new User($db);
$expensecategory = new ExpenseCategory($db);

if(isset($_SESSION["username"]))
{
  // $member->getMemberDetails($_SESSION['memberId']);
  $username = $_SESSION['username'];
  $user->getUserByEmail($_SESSION['username']);
}
else {
  // $memberId="Not logged in";
  header("location: ".$project->getProjectUrl()."index");
  exit;
}


if(isset($_POST['addNewValue']))
{
    $account->setAccountNo($_POST['accountno']);
    $account->setName($_POST['name']);
    $account->setInitialBalance($_POST['initial_balance']);
    $account->setNote($_POST['note']);
    if($account->create())
    {
        $successmessage="Account is created successfully";
    }
    else {
        $errormessage ="Account cannot be added";
    }
}

if(isset($_POST['editValue']))
{
    $account->getAccountByID($_POST['account_id']);

    $account->setAccountNo($_POST['accountno']);
    $account->setName($_POST['name']);
    $account->setInitialBalance($_POST['initial_balance']);
    $account->setNote($_POST['note']);
    if($account->update())
    {
      $successmessage="Account Details are updated successfully";
    }
    else {
      $errormessage="Account Details could not be updated !!";
    }
}

if(isset($_POST['deleteValue']))
{
  $account->setId($_POST['account_id']);
  if($account->delete())
  {
    $successmessage="Account is deleted successfully";
  }
  else {
    $errormessage="Account Information could not be deleted !!";
  }
}

$allaccounts  = $account->readAllAccounts();
?>

<!DOCTYPE html>
<html>
<head>
   <?php include_once("htmlheader.php"); ?>
   <title><?php echo $project->getProjectFName()?> | Account</title>

</head>

 <body onload="myFunction()" style="">
     <div id="loader"></div>

       <?php include_once("sidebar.php"); ?>

       <?php include_once("header.php"); ?>

       <div class="page">

      <!-- account modal -->
      <div id="account-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
        <div role="document" class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="exampleModalLabel" class="modal-title">Add Expense</h5>
                    <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
                </div>
                <div class="modal-body">
                  <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                    <form method="POST" action="accounts" accept-charset="UTF-8">
                      <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                      <input name="addNewValue" type="hidden">
                      <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Account No *</label>
                            <div class="btn-group bootstrap-select form-control">
                              <input type="number" name="accountno" id="accountno" step="any" required="" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Name *</label>
                            <input type="text" name="name" id="name" step="any" required="" class="form-control">
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Initial Balance *</label>
                            <input type="number" name="initial_balance" id="initial_balance" step="any" required="" class="form-control">
                        </div>
                      </div>
                      <div class="form-group">
                          <label>Note </label>
                          <textarea name="note" id="note" rows="3" class="form-control"></textarea>
                      </div>
                      <div class="form-group">
                          <button type="submit" class="btn btn-primary">Submit</button>
                      </div>
                    </form>
                </div>
            </div>
        </div>
      </div>

      <div style="display: block;" id="content" class="animate-bottom">

      <?php
      if(isset($successmessage))
      {
      ?>
      <div class="alert alert-success alert-dismissible text-center">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo $successmessage; ?>
      </div>
    <?php } ?>
    <?php
    if(isset($errormessage))
    {
    ?>
    <div class="alert alert-danger alert-dismissible text-center">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <?php echo $errormessage; ?>
    </div>
  <?php } ?>



<section>
    <div class="container-fluid">
        <button class="btn btn-info" data-toggle="modal" data-target="#account-modal"><i class="dripicons-plus"></i> Add Account</button>
    </div>
    <div class="table-responsive">
        <div id="account-table_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">

          <table id="account-table" class="table dataTable" role="grid" aria-describedby="account-table_info">
            <thead>
                <tr role="row">
                  <th class="not-exported dt-checkboxes-cell dt-checkboxes-select-all sorting_disabled" rowspan="1" colspan="1" style="width:10px;" data-col="0" aria-label="">
                    <div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>
                  </th>

                  <th class="sorting" tabindex="0" aria-controls="account-table" rowspan="1" colspan="1" aria-label="Account No" style="width: 150px;">Account No</th>
                  <th class="sorting" tabindex="0" aria-controls="account-table" rowspan="1" colspan="1" aria-label="Name: activate to sort column ascending" style="width: 0px;">Name</th>
                  <th class="sorting" tabindex="0" aria-controls="account-table" rowspan="1" colspan="1" aria-label="Initial Balance" style="width: 150px;">Initial Balance</th>
                  <th class="sorting" tabindex="0" aria-controls="account-table" rowspan="1" colspan="1" aria-label="Note" style="width: 150px;">Note</th>
                  <th class="not-exported sorting_disabled" rowspan="1" colspan="1" aria-label="Action" style="width: 130px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php

                foreach($allaccounts as $accountValue)
                {
                ?>
                <tr role="row" class="odd">
                    <td class="dt-checkboxes-cell">
                      <div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>
                    </td>

                    <td><?php echo $accountValue['account_no'];  ?></td>
                    <td><?php echo $accountValue['name'];  ?></td>
                    <td><?php echo $accountValue['initial_balance'];  ?></td>
                    <td><?php echo $accountValue['note'];  ?></td>
                    <td>
                        <div class="btn-group">
                          <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action
                              <span class="caret"></span>
                              <span class="sr-only">Toggle Dropdown</span>
                          </button>
                            <ul class="dropdown-menu edit-options dropdown-menu-right dropdown-default" user="menu">
                                <li>
                                  <button type="button" data-initial_balance="<?php echo $accountValue['initial_balance']; ?>" data-note="<?php echo $accountValue['note']; ?>" data-id="<?php echo $accountValue['id']; ?>" data-account_no="<?php echo $accountValue['account_no']; ?>" data-name="<?php echo $accountValue['name']; ?>"
                                     class="edit-btn btn btn-link" data-toggle="modal" data-target="#editModal"><i class="dripicons-document-edit"></i> Edit</button></li>

                                <li class="divider">
                                <form method="POST" action="accounts" accept-charset="UTF-8">
                                  <input name="deleteValue" type="hidden" value="DELETE">
                                  <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                                  <input name="account_id" type="hidden" value="<?php echo $accountValue['id']; ?>">
                                <li>
                                    <button type="submit" class="btn btn-link" onclick="return confirmDelete()"><i class="dripicons-trash"></i> Delete</button>
                                </li>
                                </form>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php
                }
                ?>
                <tfoot class="tfoot active">
                <tr>
                  <th rowspan="1" colspan="1"></th>
                  <th rowspan="1" colspan="1">Total</th>
                  <th rowspan="1" colspan="1"></th>
                  <th rowspan="1" colspan="1"></th>
                  <th rowspan="1" colspan="1"></th>
                  <th rowspan="1" colspan="1"></th>
                  </tr></tfoot>
                </tbody>
        </table>

      </div>
    </div>
</section>

<div id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
    <div role="document" class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="exampleModalLabel" class="modal-title">Update Account</h5>
                <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
            </div>
            <div class="modal-body">
              <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                <form method="POST" action="accounts" accept-charset="UTF-8">
                  <input type="hidden" name="account_id">
                  <input type="hidden" name="editValue" value="success">
                  <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                  <div class="row">
                    <div class="col-md-6 form-group">
                        <label>Account No *</label>
                        <div class="btn-group bootstrap-select form-control">
                          <input type="number" name="accountno" id="accountno" step="any" required="" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6 form-group">
                        <label>Name *</label>
                        <input type="text" name="name" id="name" step="any" required="" class="form-control">
                    </div>
                    <div class="col-md-6 form-group">
                        <label>Initial Balance *</label>
                        <input type="number" name="initial_balance" id="initial_balance" step="any" required="" class="form-control">
                    </div>
                  </div>
                  <div class="form-group">
                      <label>Note </label>
                      <textarea name="note" id="note" rows="3" class="form-control"></textarea>
                  </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">

    $("ul#account").siblings('a').attr('aria-expanded','true');
    $("ul#account").addClass("show");
    $("ul#account #account-list-menu").addClass("active");

    $('.edit-btn').on('click', function() {
        $("#editModal input[name='accountno']").val($(this).data('account_no'));
        $("#editModal input[name='name']").val($(this).data('name'));
        $("#editModal input[name='initial_balance']").val($(this).data('initial_balance'));
        $("#editModal textarea[name='note']").val($(this).data('note'));
        $("#editModal input[name='account_id']").val($(this).data('id') );
    });

    $('.default').on('change', function() {
        //off to on
        if ($(this).parent().hasClass("btn-success")) {
            var id = $(this).data('id');
            $('.default').not($(this)).parent().removeClass('btn-success');
            $('.default').not($(this)).parent().addClass('btn-danger off');
            $('.default').not($(this)).prop('checked', false);
            $(this).prop('checked', true);
            $.get('accounts/make-default/' + id, function(data) {
                alert(data);
            });
        }
        //on to off
        else {
            $(this).parent().removeClass('btn-danger off');
            $(this).parent().addClass('btn-success');
            $(this).prop('checked', true);
            alert('Please make another account default first!');
        }
    });

    function confirmDelete() {
        if (confirm("Are you sure want to delete?")) {
            return true;
        }
        return false;
    }
    var table = $('#account-table').DataTable( {
        "order": [],
        'language': {
            'lengthMenu': '_MENU_ records per page',
             "info":      '<small>Showing _START_ - _END_ (_TOTAL_)</small>',
            "search":  'Search',
            'paginate': {
                    'previous': '<i class="dripicons-chevron-left"></i>',
                    'next': '<i class="dripicons-chevron-right"></i>'
            }
        },
        'columnDefs': [
            {
                "orderable": false,
                'targets': [0, 5]
            },
            {
                'render': function(data, type, row, meta){
                    if(type === 'display'){
                        data = '<div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>';
                    }

                   return data;
                },
                'checkboxes': {
                   'selectRow': true,
                   'selectAllRender': '<div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>'
                },
                'targets': [0]
            }
        ],
        'select': { style: 'multi',  selector: 'td:first-child'},
        'lengthMenu': [[10, 25, 50, -1], [10, 25, 50, "All"]],
        dom: '<"row"lfB>rtip',
        buttons: [
            {
                extend: 'pdf',
                text: 'PDF',
                exportOptions: {
                    columns: ':visible:Not(.not-exported)',
                    rows: ':visible'
                },
                action: function(e, dt, button, config) {
                    datatable_sum(dt, true);
                    $.fn.dataTable.ext.buttons.pdfHtml5.action.call(this, e, dt, button, config);
                    datatable_sum(dt, false);
                },
                footer:true
            },
            {
                extend: 'csv',
                text: 'CSV',
                exportOptions: {
                    columns: ':visible:Not(.not-exported)',
                    rows: ':visible'
                },
                action: function(e, dt, button, config) {
                    datatable_sum(dt, true);
                    $.fn.dataTable.ext.buttons.csvHtml5.action.call(this, e, dt, button, config);
                    datatable_sum(dt, false);
                },
                footer:true
            },
            {
                extend: 'print',
                text: 'Print',
                exportOptions: {
                    columns: ':visible:Not(.not-exported)',
                    rows: ':visible'
                },
                action: function(e, dt, button, config) {
                    datatable_sum(dt, true);
                    $.fn.dataTable.ext.buttons.print.action.call(this, e, dt, button, config);
                    datatable_sum(dt, false);
                },
                footer:true
            },
            {
                extend: 'colvis',
                text: 'Column visibility',
                columns: ':gt(0)'
            },
        ],
        drawCallback: function () {
            var api = this.api();
            datatable_sum(api, false);
        }
    } );
    function datatable_sum(dt_selector, is_calling_first) {
        if (dt_selector.rows( '.selected' ).any() && is_calling_first) {
            var rows = dt_selector.rows( '.selected' ).indexes();
            $( dt_selector.column( 3 ).footer() ).html(dt_selector.cells( rows, 3, { page: 'current' } ).data().sum().toFixed(2));
        }
        else {
            $( dt_selector.column( 3 ).footer() ).html(dt_selector.cells( rows, 3, { page: 'current' } ).data().sum().toFixed(2));
        }
    }

</script>
      </div>

      <?php include_once("footer.php"); ?>
    </div>


<script type="text/javascript">
       if ($(window).outerWidth() > 1199) {
           $('nav.side-navbar').removeClass('shrink');
       }

       function myFunction() {
           setTimeout(showPage, 150);
       }
       function showPage() {
         document.getElementById("loader").style.display = "none";
         document.getElementById("content").style.display = "block";
       }

       $("div.alert").delay(3000).slideUp(750);

       function confirmDelete() {
           if (confirm("Are you sure want to delete?")) {
               return true;
           }
           return false;
       }

       $("a#add-expense").click(function(e){
         e.preventDefault();
         $('#expense-modal').modal();
       });

       $("a#add-account").click(function(e){
         e.preventDefault();
         $('#account-modal').modal();
       });

       $("a#account-statement").click(function(e){
         e.preventDefault();
         $('#account-statement-modal').modal();
       });

       $("a#profitLoss-link").click(function(e){
         e.preventDefault();
         $("#profitLoss-report-form").submit();
       });

       $("a#report-link").click(function(e){
         e.preventDefault();
         $("#product-report-form").submit();
       });

       $("a#purchase-report-link").click(function(e){
         e.preventDefault();
         $("#purchase-report-form").submit();
       });

       $("a#sale-report-link").click(function(e){
         e.preventDefault();
         $("#sale-report-form").submit();
       });

       $("a#payment-report-link").click(function(e){
         e.preventDefault();
         $("#payment-report-form").submit();
       });

       $("a#warehouse-report-link").click(function(e){
         e.preventDefault();
         $('#warehouse-modal').modal();
       });

       $("a#user-report-link").click(function(e){
         e.preventDefault();
         $('#user-modal').modal();
       });

       $("a#customer-report-link").click(function(e){
         e.preventDefault();
         $('#customer-modal').modal();
       });

       $("a#supplier-report-link").click(function(e){
         e.preventDefault();
         $('#supplier-modal').modal();
       });

       $("a#due-report-link").click(function(e){
         e.preventDefault();
         $("#due-report-form").submit();
       });

       $(".daterangepicker-field").daterangepicker({
           callback: function(startDate, endDate, period){
             var start_date = startDate.format('YYYY-MM-DD');
             var end_date = endDate.format('YYYY-MM-DD');
             var title = start_date + ' To ' + end_date;
             $(this).val(title);
             $('#account-statement-modal input[name="start_date"]').val(start_date);
             $('#account-statement-modal input[name="end_date"]').val(end_date);
           }
       });

       $('.selectpicker').selectpicker({
           style: 'btn-link',
       });
     </script>


</body>
</html>
