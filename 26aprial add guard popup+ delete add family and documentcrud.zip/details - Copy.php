<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/Employee.php");
require_once("businessLogic/FamilyMember.php");  // family details add
require_once("businessLogic/FamilyDocument.php"); // family documents added


$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="guards";
session_start();

$database = new Database();
$db = $database->getConnection();
$employee = new Employee($db);
$familymember = new FamilyMember($db);  // family memeber data
$familydocument = new FamilyDocument($db); // family document

if(isset($_SESSION["username"]))
{
  // $member->getMemberDetails($_SESSION['memberId']);
  $username = $_SESSION['username'];
}
else {
  // $memberId="Not logged in";
  header("location: ".$project->getProjectUrl()."index");
  exit;
}


if(isset($_POST['addfamilydata']))
{
  $familymember->setName($_POST['name']);
  $familymember->setAge($_POST['age']);
  $familymember->setRelation($_POST['relation']);
  $familymember->setRemark($_POST['remark']);

   if($familymember->create())
   {
       $successmessage="family mamber added successfully";
   }
   else {
      $errormessage ="Family member details cannot be added";
   }

}

if(isset($_POST['update_family']))
{
  $familymember->setFamilyMemberId($_POST['family_id']);
  $familymember->setName($_POST['name']);
  $familymember->setAge($_POST['age']);
  $familymember->setRelation($_POST['relation']);
  $familymember->setRemark($_POST['remark']);


     if($familymember->update())
     {

      $successmessage=" Family Memeber  Information is updated successfully";
     }
    else {
       $errormessage="family Member Information could not be updated !!";
     }
}

if(isset($_POST['delete_family']))
{
  $familymember->setFamilyMemberId($_POST['family_id']);
  if($familymember->delete())
  {
   $successmessage="Family Member  Information is deleted successfully";
  }
  else {
    $errormessage="Family Member Information could not be deleted !!";
  }
}


///// add document  ======================================================///
if(isset($_POST['adddocument']))
{
  $familydocument->setDocumentName($_POST['documentname']);
  $familydocument->setDocumentDescription($_POST['docdescription']);
  $familydocument->setAuthority($_POST['docauthority']);
  $familydocument->setDocumentIssudate($_POST['docissudate']);


   if($familydocument->create())
   {
       $successmessage="family mamber document added successfully";
   }
   else {
      $errormessage ="Family member document details cannot be added";
   }
 }

 if(isset($_POST['editdocument'])) /// family  documents  detils edit
 {
   $familydocument->setDocumentId($_POST['doc_id']);
   $familydocument->setDocumentName($_POST['documentname']);
   $familydocument->setDocumentDescription($_POST['docdescription']);
   $familydocument->setAuthority($_POST['docauthority']);
   $familydocument->setDocumentIssudate($_POST['docissudate']);

      if($familydocument->update())
      {

       $successmessage=" Family Memeber Document  Information is updated successfully";
      }
     else {
        $errormessage="family Member Document Information could not be updated !!";
      }
 }


 if(isset($_POST['deletedocumentdata'])) /// delete family details
 {

    $familydocument->setDocumentID($_POST['doc_id']);
    if($familydocument->delete())
    {
     $successmessage="Family Member  Document Information is deleted successfully";
    }
    else {
      $errormessage="Family Member Document Information could not be deleted !!";
    }
 }

 //adddocument

if(isset($_GET['id']))
{
  $employee->getEmployeeByID($_GET['id']);
  $familymember->getFamilyMemberByID($_GET['id']);  //family memeber
  $familydocument->getDocumentByID($_GET['id']);   //document
}
else {
  header("location:". $project->getProjectUrl()."guards");
  exit;
}
$allfamilymember  = $familymember->readAllFamilyMember();
$allfamilydocument  = $familydocument->readAllDocument();
?>


<!DOCTYPE html>
<html>
<head>
   <?php include_once("htmlheader.php"); ?>
   <title><?php echo $project->getProjectFName()?> | Guard Details</title>

</head>

 <body onload="myFunction()" style="">
     <div id="loader"></div>

       <?php include_once("sidebar.php"); ?>

       <?php include_once("header.php"); ?>

       <div class="page">

      <!-- account modal -->
      <div id="member-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
        <div role="document" class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="exampleModalLabel" class="modal-title">Add Family Member</h5>
                    <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
                </div>
                <div class="modal-body">
                  <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                    <form method="POST" action="" accept-charset="UTF-8">
                      <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                      <input name="addfamilydata" type="hidden">
                      <div class="form-group">
                          <label>Name *</label>
                          <input type="text" name="name" id="name" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>Age *</label>
                          <input type="number" name="age" id="age" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>Relation *</label>
                          <input type="text" name="relation" id="relation" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>Remarks</label>
                          <input type="text" name="remark" id="remark" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <button type="submit" class="btn btn-primary">Submit</button>
                      </div>
                    </form>
                </div>
            </div>
        </div>
      </div>

      <div id="document-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
        <div role="document" class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="exampleModalLabel" class="modal-title">Add Document</h5>
                    <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
                </div>
                <div class="modal-body">
                  <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                    <form method="POST" action="" accept-charset="UTF-8">
                      <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                      <input name="adddocument" type="hidden">
                      <div class="form-group">
                          <label>Document *</label>
                          <input type="text" name="documentname" id="documentname" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>Description *</label>
                          <input type="text" name="docdescription" id="docdescription" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>Authority</label>
                          <input type="text" name="docauthority" id="docauthority" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>Issue Date</label>
                          <input type="date" name="docissudate" id="docissudate" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <button type="submit" class="btn btn-primary">Submit</button>
                      </div>
                    </form>
                </div>
            </div>
        </div>
      </div>


      <div style="display: block;" id="content" class="animate-bottom">

      <?php
      if(isset($successmessage))
      {
      ?>
      <div class="alert alert-success alert-dismissible text-center">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo $successmessage; ?>
      </div>
    <?php } ?>
    <?php
    if(isset($errormessage))
    {
    ?>
    <div class="alert alert-danger alert-dismissible text-center">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <?php echo $errormessage; ?>
    </div>
  <?php } ?>



<section class="forms">
  <div class="container-fluid">
      <div class="row">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-header d-flex align-items-center">
                      <h4>Guard Details</h4>
                  </div>
                  <div class="card-body">
                      <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                      <form method="POST" action="details?id=<?php echo $_GET['id']; ?>" accept-charset="UTF-8" class="payment-form" enctype="multipart/form-data"><input name="_token" type="hidden" value="fYe3holiUMMCtMHKBwiFIIgC8If0Icvqd75v8XuD">
                      <div class="row">
                          <div class="col-md-12">
                              <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong>Employee Code</strong>
                                        </label>
                                        <input type="text" value="<?php echo $employee->getEmployeeCode(); ?>" name="employeecode" readonly id="employeecode" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>FirstName</label>
                                        <input type="text" value="<?php echo $employee->getFirstName(); ?>" name="first_name" id="first_name" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Middle Name</label>
                                        <input type="text" value="<?php echo $employee->getMName(); ?>" name="middle_name" id="middle_name" class="form-control" step="any">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>SurName</label>
                                        <input type="text" value="<?php echo $employee->getSurname(); ?>" name="sur_name" id="sur_name" class="form-control" step="any">
                                    </div>
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-md-12">
                                  <hr/>
                                </div>
                              </div>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-md-12">
                            <!-- Start of the Tabs -->

                              <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
                                <li class="nav-item">
                                  <a class="nav-link active" id="custom-content-below-home-tab" data-toggle="pill" href="#custom-content-below-home" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Personal</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" id="custom-content-below-profile-tab" data-toggle="pill" href="#custom-content-below-profile" role="tab" aria-controls="custom-content-below-profile" aria-selected="false">Provident Fund</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" id="custom-content-below-nominee-tab" data-toggle="pill" href="#custom-content-below-nominee" role="tab" aria-controls="custom-content-below-nominee" aria-selected="false">Nominee</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" id="custom-content-below-address-tab" data-toggle="pill" href="#custom-content-below-address" role="tab" aria-controls="custom-content-below-address" aria-selected="false">Address</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" id="custom-content-below-body-tab" data-toggle="pill" href="#custom-content-below-body" role="tab" aria-controls="custom-content-below-body" aria-selected="false">Body Details</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" id="custom-content-below-others-tab" data-toggle="pill" href="#custom-content-below-others" role="tab" aria-controls="custom-content-below-others" aria-selected="false">Others</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" id="custom-content-below-posting-tab" data-toggle="pill" href="#custom-content-below-posting" role="tab" aria-controls="custom-content-below-posting" aria-selected="false">Posting</a>
                                </li>
                              </ul>
                              <div class="tab-content" id="custom-content-below-tabContent">
                                <div class="tab-pane fade show active" id="custom-content-below-home" role="tabpanel" aria-labelledby="custom-content-below-home-tab">
                                  <br/>
                                  <div class="row">
                                      <div class="col-md-12">
                                        <div class="row">
                                          <div class="col-md-12">
                                            <label><strong>Personal</strong></label>
                                          </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Date of Birth</label>
                                                  <input type="date" value="<?php echo $employee->getBirthDate(); ?>" name="date_of_birth" id="date_of_birth" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Age</label>
                                                  <input type="text" value="<?php echo $employee->getAge(); ?>" name="age" id="age" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Gender</label>
                                                  <select name="age" id="age" class="form-control" step="any">
                                                    <option value="">Select</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                  </select>
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Education</label>
                                                  <input type="text" value="<?php echo $employee->getEducation(); ?>" name="education" id="education" class="form-control" step="any">
                                              </div>
                                          </div>
                                        </div>
                                        <hr/>
                                        <div class="row">
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Joining Date</label>
                                                  <input type="date" value="<?php echo $employee->getJoiningDate(); ?>" name="joiningdate" id="joiningdate" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Confirmation Date</label>
                                                  <input type="date" value="<?php echo $employee->getConfirmationDate(); ?>" name="confirmationdate" id="confirmationdate" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Icard Issue Date</label>
                                                  <input type="date" value="<?php echo $employee->getIcardIssueDate(); ?>" name="icardissuedate" id="icardissuedate" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Renewal Date</label>
                                                  <input type="date" value="<?php echo $employee->getRenewalDate(); ?>" name="renewaldate" id="renewaldate" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Tr Deposit</label>
                                                  <input type="checkbox" value="<?php echo $employee->getTRDeposit(); ?>" name="tr_deposit" id="tr_deposit" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Smart Card Issued</label>
                                                  <input type="checkbox" value="<?php echo $employee->getSmartcardIssued(); ?>" name="smartcard_issued" id="smartcard_issued" class="form-control" step="any">
                                              </div>
                                          </div>

                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>ESI</label>
                                                  <input type="checkbox" value="<?php echo $employee->getESI(); ?>" name="esi" id="esi" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>ESI Number</label>
                                                  <input type="text" value="<?php echo $employee->getESINumber(); ?>" name="esiNumber" id="esiNumber" class="form-control" step="any">
                                              </div>
                                          </div>
                                        </div>
                                        <hr/>
                                        <div class="row">
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Left Date</label>
                                                  <input type="date" value="<?php echo $employee->getLeftDate(); ?>" name="leftDate" id="leftDate" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Reason of Leaving</label>
                                                  <input type="text" value="<?php echo $employee->getReasonofLeaving(); ?>" name="reasonOfLeaving" id="reasonOfLeaving" class="form-control" step="any">
                                              </div>
                                          </div>

                                        </div>

                                      </div>
                                  </div>
                                </div>

                                <div class="tab-pane fade" id="custom-content-below-profile" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
                                  <br/>
                                  <div class="row">
                                      <div class="col-md-12">
                                        <div class="row">
                                          <div class="col-md-12">
                                            <label><strong>Provident Fund</strong></label>
                                          </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Provident Fund</label>
                                                  <input type="checkbox" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Provident Fund Number</label>
                                                  <input type="text" value="<?php echo $employee->getPFNumber(); ?>" name="providentfundnumber" id="providentfundnumber" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Provident UID Number</label>
                                                  <input type="text" value="<?php echo $employee->getUidNo(); ?>" name="providentUidNumber" id="providentUidNumber" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Provident Member Id</label>
                                                  <input type="text" value="<?php echo $employee->getPFMemberId(); ?>" name="pf_memberId" id="pf_memberId" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Name PF</label>
                                                  <input type="text" value="<?php echo $employee->getPFName(); ?>" name="pf_name" id="pf_name" class="form-control" step="any">
                                              </div>
                                          </div>
                                        </div>
                                        <hr/>
                                        <div class="row">
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Provident Fund Withdrawal</label>
                                                  <input type="checkbox" name="chk_providentfund" id="chk_providentfund" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>PF Withdrawal Date</label>
                                                  <input type="date" value="<?php echo $employee->getPFWithdrawalDate(); ?>" name="pfwithdrawaldate" id="pfwithdrawaldate" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Submission Date</label>
                                                  <input type="date" value="<?php echo $employee->getSubmissionDate(); ?>" name="submissiondate" id="submissiondate" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>PF Settlement Date</label>
                                                  <input type="date" value="<?php echo $employee->getSettlementDate(); ?>" name="settlementdate" id="settlementdate" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>PF Cheque Number</label>
                                                  <input type="text" value="<?php echo $employee->getChequeNumber(); ?>" name="chequenumber" id="chequenumber" class="form-control" step="any">
                                              </div>
                                          </div>
                                        </div>
                                      </div>
                                  </div>

                                </div>

                                <div class="tab-pane fade" id="custom-content-below-nominee" role="tabpanel" aria-labelledby="custom-content-below-nominee-tab">
                                  <br/>
                                  <div class="row">
                                      <div class="col-md-12">
                                        <div class="row">
                                          <div class="col-md-12">
                                            <label><strong>Nominee Details</strong></label>
                                          </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Nominee</label>
                                                  <input type="text" value="<?php echo $employee->getNominee(); ?>" name="nominee" id="nominee" class="form-control" step="any">
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Nominee Age</label>
                                                  <select name="nominee_age" id="nominee_age" class="form-control" step="any">
                                                  <option value="">Select</option>
                                                  <?php
                                                  for($f=10;$f<60;$f++)
                                                  {
                                                    if($employee->getNomineeAge()==$f)
                                                    {
                                                        echo "<option selected value=\".$f.\">".$f." Years</option>";
                                                    }
                                                    else {
                                                      echo "<option value=\".$f.\">".$f." Years</option>";
                                                    }

                                                  }
                                                  ?>
                                                  </select>
                                              </div>
                                          </div>
                                          <div class="col-md-4">
                                              <div class="form-group">
                                                  <label>Nominee Relation
                                                  </label>
                                                  <input type="text" value="<?php echo $employee->getNomineeRelation(); ?>" name="nominee_relation" id="nominee_relation" class="form-control" step="any">
                                              </div>
                                          </div>
                                        </div>

                                      </div>
                                  </div>
                                </div>

                                <div class="tab-pane fade" id="custom-content-below-address" role="tabpanel" aria-labelledby="custom-content-below-address-tab">
                                    <br/>
                                    <div class="row">
                                      <div class="col-md-12">
                                        <div class="row">
                                          <div class="col-md-12">
                                              <label><strong>Present Address</strong></label>
                                          </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Address</label>
                                                <input type="text" value="" name="address" id="address" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Address1</label>
                                                <input type="text" value="" name="address1" id="address1" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Address2</label>
                                                <input type="text" value="" name="address2" id="address2" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>City</label>
                                                <input type="text" value="" name="city" id="city" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Pincode</label>
                                                <input type="text" value="" name="pincode" id="pincode" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>State</label>
                                                <input type="text" value="" name="state" id="state" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Country</label>
                                                <input type="text" value="" name="country" id="country" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Post Office</label>
                                                <input type="text" value="" name="postoffice" id="postoffice" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Police Station</label>
                                                <input type="text" value="" name="ploicestation" id="policestation" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Mobile Number</label>
                                                <input type="text" value="" name="mobilenumber" id="mobilenumber" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Phone 2</label>
                                                <input type="text" value="" name="phone2" id="phone2" class="form-control" step="any">
                                            </div>
                                          </div>
                                        </div>

                                        <div class="row">
                                          <div class="col-md-12">
                                              <label><strong>Permanent Address</strong></label>
                                          </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Address</label>
                                                <input type="text" value="" name="paddress" id="paddress" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Address1</label>
                                                <input type="text" value="" name="paddress1" id="paddress1" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Address2</label>
                                                <input type="text" value="" name="paddress2" id="paddress2" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>City</label>
                                                <input type="text" value="" name="pcity" id="pcity" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Pincode</label>
                                                <input type="text" value="" name="ppincode" id="ppincode" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>State</label>
                                                <input type="text" value="" name="pstate" id="pstate" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Country</label>
                                                <input type="text" value="" name="pcountry" id="pcountry" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Post Office</label>
                                                <input type="text" value="" name="ppostoffice" id="ppostoffice" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Police Station</label>
                                                <input type="text" value="" name="ppolicestation" id="ppolicestation" class="form-control" step="any">
                                            </div>
                                          </div>
                                        </div>

                                      </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="custom-content-below-body" role="tabpanel" aria-labelledby="custom-content-below-body-tab">
                                    <br/>
                                    <div class="row">
                                      <div class="col-md-12">
                                        <div class="row">
                                          <div class="col-md-12">
                                              <label><strong>Body Details</strong></label>
                                          </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Id Mark 1</label>
                                                <input type="text" value="" name="idmark1" id="idmark1" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Id Mark 2</label>
                                                <input type="text" value="" name="idmark2" id="idmark2" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Hair Colour</label>
                                                <input type="text" value="" name="haircolour" id="haircolour" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Eye Colour</label>
                                                <input type="text" value="" name="eyecolour" id="eyecolour" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Face General</label>
                                                <input type="text" value="" name="facegeneral" id="facegeneral" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Face Shape</label>
                                                <input type="text" value="" name="faceshape" id="faceshape" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Height</label>
                                                <input type="text" value="" name="height" id="height" class="form-control" step="any">
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <div class="form-group">
                                              <label>Weight</label>
                                                <input type="text" value="" name="weight" id="weight" class="form-control" step="any">
                                            </div>
                                          </div>
                                        </div>

                                      </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="custom-content-below-others" role="tabpanel" aria-labelledby="custom-content-below-others-tab">
                                  <br/>
                                  <div class="row">
                                    <div class="col-md-12">
                                      <div class="row">
                                        <div class="col-md-12">
                                          <label><strong>Previous Job Details</strong></label>
                                        </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label>Particular of Previous Job</label>
                                              <input type="text" value="" name="previousjob" id="previousjob" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label>Reason of Leaving</label>
                                              <input type="text" value="" name="reasonofleaving" id="reasonofleaving" class="form-control" step="any">
                                          </div>
                                        </div>
                                      </div>

                                      <div class="row">
                                        <div class="col-md-12">
                                          <label><strong>Name and address of two Responsible Persons</strong></label>
                                        </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Name</label>
                                              <input type="text" value="" name="previousjob" id="previousjob" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Address</label>
                                              <input type="text" value="" name="reasonofleaving" id="reasonofleaving" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Tel Nos</label>
                                              <input type="text" value="" name="reasonofleaving" id="reasonofleaving" class="form-control" step="any">
                                          </div>
                                        </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Name</label>
                                              <input type="text" value="" name="previousjob" id="previousjob" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Address</label>
                                              <input type="text" value="" name="reasonofleaving" id="reasonofleaving" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Tel Nos</label>
                                              <input type="text" value="" name="reasonofleaving" id="reasonofleaving" class="form-control" step="any">
                                          </div>
                                        </div>
                                      </div>

                                  </div>
                                  </div>
                                </div>

                                <div class="tab-pane fade" id="custom-content-below-posting" role="tabpanel" aria-labelledby="custom-content-below-posting-tab">
                                  <br/>
                                  <div class="row">
                                    <div class="col-md-12">
                                      <div class="row">
                                        <div class="col-md-12">
                                          <label><strong>Client Details</strong></label>
                                        </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label>Client Name</label>
                                              <select name="clientname" id="clientname" class="form-control">
                                                <option value="">Select</option>
                                                <option value="1">Testing</option>
                                                <option value="2">Testing</option>
                                              </select>
                                          </div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label>Grade</label>
                                            <select name="clientgrade" id="clientgrade" class="form-control">
                                              <option>Select</option>
                                              <option value="1">I</option>
                                              <option value="2">II</option>
                                              <option value="3">III</option>
                                              <option value="4">IV</option>
                                            </select>
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Designation</label>
                                              <input type="text" value="" name="designation" id="designation" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Basic Rate</label>
                                              <input type="text" value="" name="basicrate" id="basicrate" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Field Officer</label>
                                              <input type="text" value="" name="fieldofficer" id="fieldofficer" class="form-control" step="any">
                                          </div>
                                        </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-md-12">
                                          <hr/>
                                        </div>
                                      </div>
                                      <div class="row">

                                        <div class="col-md-12">
                                          <label><strong>Bank Details</strong></label>
                                        </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label>Bank Name</label>
                                              <input type="text" value="" name="bankName" id="bankName" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label>Branch</label>
                                              <input type="text" value="" name="bankbranch" id="bankbranch" class="form-control" step="any">
                                          </div>
                                        </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label>Bank A/C No</label>
                                              <input type="text" value="" name="bankacNumber" id="bankacNumber" class="form-control" step="any">
                                          </div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <label>Bank IFSC Code No</label>
                                              <input type="text" value="" name="bankifsccode" id="bankifsccode" class="form-control" step="any">
                                          </div>
                                        </div>

                                      </div>

                                  </div>
                                  </div>
                                </div>
                              </div>

                            <!-- End of the Tabs -->
                          </div>
                      </div>

                      <div class="row">
                          <div class="col-md-12">
                            <hr/>
                            <div class="form-group">
                                <input type="submit" value="Update" class="btn btn-primary" id="submit-button">
                                <input type="hidden" name="editValue" value="success">
                            </div>
                          </div>
                      </div>
                      </form>

                      <div class="row">
                          <div class="col-md-12">
                            <br/>
                            <hr/>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-md-12">
                            <!-- Start of Nav -->
                                <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
                                  <li class="nav-item">
                                    <a class="nav-link active" id="custom-content-below-family-tab" data-toggle="pill" href="#custom-content-below-family" role="tab" aria-controls="custom-content-below-family" aria-selected="true">Family Members</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" id="custom-content-below-document-tab" data-toggle="pill" href="#custom-content-below-document" role="tab" aria-controls="custom-content-below-document" aria-selected="false">Documents</a>
                                  </li>

                                </ul>
                                <div class="tab-content" id="custom-content-below-tabContent">
                                  <div class="tab-pane fade show active" id="custom-content-below-family" role="tabpanel" aria-labelledby="custom-content-below-family-tab">
                                    <div class="row">
                                        <div class="col-md-12">
                                          <div class="row mt-5">
                                                  <div class="col-md-12">
                                                      <button class="btn btn-sm btn-info float-right" data-toggle="modal" data-target="#member-modal"><i class="dripicons-plus"></i>Add Member</button>
                                                      <h5>Family Members</h5>
                                                      <div class="table-responsive mt-3">
                                                          <table id="myTable" class="table table-hover order-list">
                                                              <thead>
                                                                  <tr>
                                                                      <th>Family Member Name</th>
                                                                      <th>Age</th>
                                                                      <th>Relation</th>
                                                                      <th>Remark</th>
                                                                      <th><i class="dripicons-trash"></i></th>
                                                                  </tr>
                                                              </thead>
                                                              <tbody>

                                                                <?php

                                                                foreach($allfamilymember as $familyValue)
                                                                //foreach($allguards as $guardValue)
                                                                {
                                                                  ?>
                                                                  <tr>
                                                                      <td>N
                                                                        <button type="button" data-family_id="<?php echo $familyValue['id']; ?>" data-name="<?php echo $familyValue['name']; ?>"  data-age="<?php echo $familyValue['age']; ?>" data-relation="<?php echo $familyValue['relation']; ?>"
                                                                           data-remark="<?php echo $familyValue['remark']; ?>" class="edit-btnfamily btn btn-link" data-toggle="modal" data-target="#editfamily">
                                                                          <i class="dripicons-document-edit"></i> Edit</button>
                                                                      <!--  <button type="button" class="edit-product btn btn-link" data-toggle="modal" data-target="#editModal"><i class="dripicons-document-edit"></i></button>-->
                                                                        <!-- <input type="hidden" class="product-type" value="standard"></td> -->
                                                                          <input type="hidden" class="family-type" value="standard"></td>
                                                                          <td><?php echo $familyValue['name'];  ?></td>
                                                                          <td><?php echo $familyValue['age'];  ?></td>
                                                                          <td><?php echo $familyValue['relation'];  ?></td>
                                                                          <td><?php echo $familyValue['remark'];  ?></td>
                                                                      <!-- <td>32</td>
                                                                      <td>Wife</td>
                                                                      <td class="net_unit_price"> </td> -->
                                                                      <td>

                                                                        <form method="POST" action="" accept-charset="UTF-8">
                                                                          <input name="delete_family" type="hidden" value="DELETE">
                                                                          <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                                                                          <input name="family_id" type="hidden" value="<?php echo $familyValue['id']; ?>">

                                                                            <button type="submit" class="ibtnDel btn btn-sm btn-danger" onclick="return confirmDeleteFamily()" > Delete</button>

                                                                        </form>

                                                                      </td>

                                                                  </tr>

                                                                  <?php
                                                                  }
                                                                  ?>

                                                                  </tbody>

                                                          </table>
                                                      </div>
                                                  </div>
                                              </div>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="tab-pane fade" id="custom-content-below-document" role="tabpanel" aria-labelledby="custom-content-below-document-tab">
                                    <div class="row">
                                        <div class="col-md-12">
                                          <div class="row mt-5">
                                                  <div class="col-md-12">
                                                      <button class="btn btn-sm btn-info float-right" data-toggle="modal" data-target="#document-modal"><i class="dripicons-plus"></i>Add Document</button>
                                                      <h5>Documents</h5>
                                                      <div class="table-responsive mt-3">
                                                          <table id="myTable" class="table table-hover order-list">
                                                              <thead>
                                                                  <tr>
                                                                      <th>Document</th>
                                                                      <th>Description</th>
                                                                      <th>Authority</th>
                                                                      <th>Issue Date</th>
                                                                      <th><i class="dripicons-trash"></i></th>
                                                                  </tr>
                                                              </thead>
                                                              <tbody>

                                                                <?php

                                                                foreach($allfamilydocument as $familyDocument)
                                                                //foreach($allguards as $guardValue)
                                                                {
                                                                ?>
                                                                  <tr>
                                                                      <td>..
                                                                        <button type="button" data-doc_id="<?php echo $familyDocument['id']; ?>" data-documentname="<?php echo $familyDocument['documentname']; ?>"data-docdesc="<?php echo $familyDocument['docdescription']; ?>"data-authority="<?php echo $familyDocument['docauthority']; ?>"
                                                                           data-issudate="<?php echo $familyDocument['docissudate']; ?>"
                                                                           class="edit-btndocument btn btn-link" data-toggle="modal" data-target="#editDocument"><i class="dripicons-document-edit"></i> Edit Doc</button>
                                                                        <!-- <button type="button" class="edit-product btn btn-link" data-toggle="modal" data-target="#editDocument"><i class="dripicons-document-edit"></i></button> -->
                                                                        <input type="hidden" class="product-type" value="standard"></td>

                                                                        <td><?php echo $familyDocument['documentname'];  ?> </td>
                                                                        <td><?php echo $familyDocument['docdescription'];  ?></td>
                                                                        <td><?php echo $familyDocument['docauthority'];  ?></td>
                                                                        <td><?php echo $familyDocument['docissudate'];  ?></td>
                                                                      <td> </td>
                                                                      <td>
                                                                        <form method="POST" action="" accept-charset="UTF-8">
                                                                          <input name="deletedocumentdata" type="hidden" value="DELETE">
                                                                          <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                                                                          <input name="doc_id" type="hidden" value="<?php echo $familyDocument['id']; ?>">

                                                                            <button type="submit" class="ibtnDel btn btn-sm btn-danger" onclick="return confirmDeleteDocument()">
                                                                           Delete </button>

                                                                        </form>

                                                                      </td>

                                                                  </tr>
                                                                  <?php
                                                                }
                                                              ?>
                                                                  </tbody>

                                                          </table>
                                                      </div>
                                                  </div>
                                              </div>
                                        </div>
                                    </div>

                                  </div>
                                </div>
                            <!-- End of Nav Tab -->
                          </div>
                      </div>

                  </div>
              </div>
          </div>
      </div>
  </div>

  <div id="editfamily" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
      <div role="document" class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 id="modal_header" class="modal-title">Update Family Member</h5>
                  <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
              </div>
              <div class="modal-body">
                  <form method="POST" action="">
                  <input name="family_id" type="hidden" >
                      <div class="form-group">
                          <label>Name</label>
                          <input type="text" name="name" class="form-control" step="any">
                      </div>
                      <div class="form-group">
                          <label>Age</label>
                          <input type="number" name="age" class="form-control" step="any">
                      </div>
                      <div class="form-group">
                          <label>Relation</label>
                          <input type="text" name="relation" class="form-control" step="any">
                      </div>
                      <div class="form-group">
                          <label>Remarks</label>
                          <input type="text" name="remark" class="form-control" step="any">
                      </div>
                      <button type="submit" name="update_family" class="btn btn-primary">Update</button>
                  </form>
              </div>
          </div>
      </div>
  </div>

  <div id="editDocument" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
      <div role="document" class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 id="modal_header" class="modal-title">Update Document</h5>
                  <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
              </div>
              <div class="modal-body">
                  <form method="POST" action="#">
                    <input type="hidden" name="doc_id">
                      <div class="form-group">
                          <label>Document</label>
                          <input type="text" name="documentname" class="form-control" step="any">
                      </div>
                      <div class="form-group">
                          <label>Description</label>
                          <input type="text" name="docdescription" class="form-control" step="any">
                      </div>
                      <div class="form-group">
                          <label>Authority</label>
                          <input type="text" name="docauthority" class="form-control" step="any">
                      </div>
                      <div class="form-group">
                          <label>Issue Date</label>
                          <input type="date" name="docissudate" class="form-control" step="any">
                      </div>
                      <button type="submit" name="editdocument" class="btn btn-primary">Update</button>
                  </form>
              </div>
          </div>
      </div>
  </div>

  <!-- <a href="<?php echo $project->getProjectUrl(); ?>#" class="btn-shadow back-to-top btn-back-to-top"></a> -->
</section>

    </div>

      <?php include_once("footer.php"); ?>
    </div>


<script type="text/javascript">

//////////////////////////////////////////////declare variable for edit family info  //////////////
       $('.edit-btnfamily').on('click', function() {
           $("#editfamily input[name='name']").val( $(this).data('name') );
           $("#editfamily input[name='age']").val( $(this).data('age') );
           $("#editfamily input[name='relation']").val( $(this).data('relation') );
           $("#editfamily input[name='remark']").val( $(this).data('remark') );
           $("#editfamily input[name='family_id']").val( $(this).data('family_id') );
       });


       function confirmDeleteFamily() {
           if (confirm("Are you sure want to delete family data?")) {
               return true;
           }
           return false;
       }
///////////////////////////////////////////////delare varible for edit family info/////////////

//////////////////////////////////////////////declare variable for edit family document  //////////////////////////
       $('.edit-btndocument').on('click', function() {
         $("#editDocument input[name='doc_id']").val( $(this).data('doc_id') );
           $("#editDocument input[name='documentname']").val( $(this).data('documentname') );
          $("#editDocument input[name='docdescription']").val( $(this).data('docdesc') );
          $("#editDocument input[name='docauthority']").val( $(this).data('authority') );
          $("#editDocument input[name='docissudate']").val( $(this).data('issudate') );

       });


       function confirmDeleteDocument() {
           if (confirm("Are you sure want to delete document?")) {
               return true;
           }
           return false;
       }
////////////////////////////////////////delare varible for edit family document/////////////////////////////////////



       if ($(window).outerWidth() > 1199) {
           $('nav.side-navbar').removeClass('shrink');
       }

       function myFunction() {
           setTimeout(showPage, 150);
       }
       function showPage() {
         document.getElementById("loader").style.display = "none";
         document.getElementById("content").style.display = "block";
       }

       $("div.alert").delay(3000).slideUp(750);

       function confirmDelete() {
           if (confirm("Are you sure want to delete?")) {
               return true;
           }
           return false;
       }

       $("a#add-expense").click(function(e){
         e.preventDefault();
         $('#expense-modal').modal();
       });

       $("a#add-account").click(function(e){
         e.preventDefault();
         $('#account-modal').modal();
       });

       $("a#account-statement").click(function(e){
         e.preventDefault();
         $('#account-statement-modal').modal();
       });

       $("a#profitLoss-link").click(function(e){
         e.preventDefault();
         $("#profitLoss-report-form").submit();
       });

       $("a#report-link").click(function(e){
         e.preventDefault();
         $("#product-report-form").submit();
       });

       $("a#purchase-report-link").click(function(e){
         e.preventDefault();
         $("#purchase-report-form").submit();
       });

       $("a#sale-report-link").click(function(e){
         e.preventDefault();
         $("#sale-report-form").submit();
       });

       $("a#payment-report-link").click(function(e){
         e.preventDefault();
         $("#payment-report-form").submit();
       });

       $("a#warehouse-report-link").click(function(e){
         e.preventDefault();
         $('#warehouse-modal').modal();
       });

       $("a#user-report-link").click(function(e){
         e.preventDefault();
         $('#user-modal').modal();
       });

       $("a#customer-report-link").click(function(e){
         e.preventDefault();
         $('#customer-modal').modal();
       });

       $("a#supplier-report-link").click(function(e){
         e.preventDefault();
         $('#supplier-modal').modal();
       });

       $("a#due-report-link").click(function(e){
         e.preventDefault();
         $("#due-report-form").submit();
       });

       $(".daterangepicker-field").daterangepicker({
           callback: function(startDate, endDate, period){
             var start_date = startDate.format('YYYY-MM-DD');
             var end_date = endDate.format('YYYY-MM-DD');
             var title = start_date + ' To ' + end_date;
             $(this).val(title);
             $('#account-statement-modal input[name="start_date"]').val(start_date);
             $('#account-statement-modal input[name="end_date"]').val(end_date);
           }
       });

       $('.selectpicker').selectpicker({
           style: 'btn-link',
       });
     </script>

     <script type="text/javascript">

     $("#card-element").hide();
     $("#cheque").hide();

     // array data depend on warehouse
     var lims_product_array = [];
     var product_code = [];
     var product_name = [];
     var product_qty = [];
     var product_type = [];
     var product_id = [];
     var product_list = [];
     var qty_list = [];

     // array data with selection
     var product_price = [];
     var product_discount = [];
     var tax_rate = [];
     var tax_name = [];
     var tax_method = [];
     var unit_name = [];
     var unit_operator = [];
     var unit_operation_value = [];

     // temporary array
     var temp_unit_name = [];
     var temp_unit_operator = [];
     var temp_unit_operation_value = [];

     var exist_type = [];
     var exist_code = [];
     var exist_qty = [];
     var rowindex;
     var customer_group_rate;
     var row_product_price;
     var currency = {"id":1,"name":"US Dollar","code":"USD","exchange_rate":1,"created_at":"2020-10-31 19:22:58","updated_at":"2020-10-31 19:34:55"};
     var role_id = 1;

     var rownumber = $('table.order-list tbody tr:last').index();

     for(rowindex  =0; rowindex <= rownumber; rowindex++){
         product_price.push(parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.product-price').val()));
         exist_code.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(2)').text());
         exist_type.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.product-type').val());
         var total_discount = parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(5)').text());
         var quantity = parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val());
         exist_qty.push(quantity);
         product_discount.push((total_discount / quantity).toFixed(2));
         tax_rate.push(parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-rate').val()));
         tax_name.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-name').val());
         tax_method.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-method').val());
         temp_unit_name = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit').val().split(',');
         unit_name.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit').val());
         unit_operator.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit-operator').val());
         unit_operation_value.push($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit-operation-value').val());
         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit').val(temp_unit_name[0]);
     }

     $('.selectpicker').selectpicker({
         style: 'btn-link',
     });

     $('[data-toggle="tooltip"]').tooltip();

     //assigning value
     $('select[name="customer_id"]').val($('input[name="customer_id_hidden"]').val());
     $('select[name="warehouse_id"]').val($('input[name="warehouse_id_hidden"]').val());
     $('select[name="biller_id"]').val($('input[name="biller_id_hidden"]').val());
     $('select[name="sale_status"]').val($('input[name="sale_status_hidden"]').val());
     $('select[name="order_tax_rate"]').val($('input[name="order_tax_rate_hidden"]').val());
     $('.selectpicker').selectpicker('refresh');

     $('#item').text($('input[name="item"]').val() + '(' + $('input[name="total_qty"]').val() + ')');
     $('#subtotal').text(parseFloat($('input[name="total_price"]').val()).toFixed(2));
     $('#order_tax').text(parseFloat($('input[name="order_tax"]').val()).toFixed(2));
     if(!$('input[name="order_discount"]').val())
         $('input[name="order_discount"]').val('0.00');
     $('#order_discount').text(parseFloat($('input[name="order_discount"]').val()).toFixed(2));
     if(!$('input[name="shipping_cost"]').val())
         $('input[name="shipping_cost"]').val('0.00');
     $('#shipping_cost').text(parseFloat($('input[name="shipping_cost"]').val()).toFixed(2));
     $('#grand_total').text(parseFloat($('input[name="grand_total"]').val()).toFixed(2));

     var id = $('select[name="customer_id"]').val();
     $.get('../getcustomergroup/' + id, function(data) {
         customer_group_rate = (data / 100);
     });

     var id = $('select[name="warehouse_id"]').val();
     $.get('../getproduct/' + id, function(data) {
         lims_product_array = [];
         product_code = data[0];
         product_name = data[1];
         product_qty = data[2];
         product_type = data[3];
         product_id = data[4];
         product_list = data[5];
         qty_list = data[6];
         product_warehouse_price = data[7];

         $.each(product_code, function(index) {
             if(exist_code.includes(product_code[index])) {
                 pos = exist_code.indexOf(product_code[index]);
                 product_qty[index] = product_qty[index] + exist_qty[pos];
                 exist_code.splice(pos, 1);
                 exist_qty.splice(pos, 1);
             }
             lims_product_array.push(product_code[index] + ' (' + product_name[index] + ')');
         });
         $.each(exist_code, function(index) {
             product_type.push(exist_type[index]);
             product_code.push(exist_code[index]);
             product_qty.push(exist_qty[index]);
         });
     });

     isCashRegisterAvailable(id);

     $('select[name="customer_id"]').on('change', function() {
         var id = $(this).val();
         $.get('../getcustomergroup/' + id, function(data) {
             customer_group_rate = (data / 100);
         });
     });

     $('select[name="warehouse_id"]').on('change', function() {
         var id = $(this).val();
         $.get('../getproduct/' + id, function(data) {
             lims_product_array = [];
             product_code = data[0];
             product_name = data[1];
             product_qty = data[2];
             product_type = data[3];
             product_id = data[4];
             product_list = data[5];
             qty_list = data[6];
             product_warehouse_price = data[7];
             $.each(product_code, function(index) {
                 lims_product_array.push(product_code[index] + ' (' + product_name[index] + ')');
             });
         });
         isCashRegisterAvailable(id);
     });

     var lims_productcodeSearch = $('#lims_productcodeSearch');
     lims_productcodeSearch.autocomplete({
         source: function(request, response) {
             var matcher = new RegExp(".?" + $.ui.autocomplete.escapeRegex(request.term), "i");
             response($.grep(lims_product_array, function(item) {
                 return matcher.test(item);
             }));
         },
         response: function(event, ui) {
             if (ui.content.length == 1) {
                 var data = ui.content[0].value;
                 $(this).autocomplete( "close" );
                 productSearch(data);
             };
         },
         select: function(event, ui) {
             var data = ui.item.value;
             productSearch(data);
         }
     });

     //Change quantity
     $("#myTable").on('input', '.qty', function() {
         rowindex = $(this).closest('tr').index();
         if($(this).val() < 1 && $(this).val() != '') {
           $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ') .qty').val(1);
           alert("Quantity can't be less than 1");
         }
         checkQuantity($(this).val(), true);
     });


     //Delete product
     $("table.order-list tbody").on("click", ".ibtnDel", function(event) {
       alert("testing");
         rowindex = $(this).closest('tr').index();
         product_price.splice(rowindex, 1);
         product_discount.splice(rowindex, 1);
         tax_rate.splice(rowindex, 1);
         tax_name.splice(rowindex, 1);
         tax_method.splice(rowindex, 1);
         unit_name.splice(rowindex, 1);
         unit_operator.splice(rowindex, 1);
         unit_operation_value.splice(rowindex, 1);
         $(this).closest("tr").remove();
         // calculateTotal();
     });

     //Edit product
     $("table.order-list").on("click", ".edit-product", function() {
         rowindex = $(this).closest('tr').index();
         edit();
     });

     //Update product
     $('button[name="update_btn"]').on("click", function() {
         var edit_discount = $('input[name="edit_discount"]').val();
         var edit_qty = $('input[name="edit_qty"]').val();
         var edit_unit_price = $('input[name="edit_unit_price"]').val();

         if (parseFloat(edit_discount) > parseFloat(edit_unit_price)) {
             alert('Invalid Discount Input!');
             return;
         }

         if(edit_qty < 1) {
             $('input[name="edit_qty"]').val(1);
             edit_qty = 1;
             alert("Quantity can't be less than 1");
         }

         var tax_rate_all = [0,10,15,20];
         tax_rate[rowindex] = parseFloat(tax_rate_all[$('select[name="edit_tax_rate"]').val()]);
         tax_name[rowindex] = $('select[name="edit_tax_rate"] option:selected').text();
         if(product_type[pos] == 'standard'){
             var row_unit_operator = unit_operator[rowindex].slice(0, unit_operator[rowindex].indexOf(","));
             var row_unit_operation_value = unit_operation_value[rowindex].slice(0, unit_operation_value[rowindex].indexOf(","));
             if (row_unit_operator == '*') {
                 product_price[rowindex] = $('input[name="edit_unit_price"]').val() / row_unit_operation_value;
             } else {
                 product_price[rowindex] = $('input[name="edit_unit_price"]').val() * row_unit_operation_value;
             }
             var position = $('select[name="edit_unit"]').val();
             var temp_operator = temp_unit_operator[position];
             var temp_operation_value = temp_unit_operation_value[position];
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.sale-unit').val(temp_unit_name[position]);
             temp_unit_name.splice(position, 1);
             temp_unit_operator.splice(position, 1);
             temp_unit_operation_value.splice(position, 1);

             temp_unit_name.unshift($('select[name="edit_unit"] option:selected').text());
             temp_unit_operator.unshift(temp_operator);
             temp_unit_operation_value.unshift(temp_operation_value);

             unit_name[rowindex] = temp_unit_name.toString() + ',';
             unit_operator[rowindex] = temp_unit_operator.toString() + ',';
             unit_operation_value[rowindex] = temp_unit_operation_value.toString() + ',';
         }
         product_discount[rowindex] = $('input[name="edit_discount"]').val();
         checkQuantity(edit_qty, false);
     });

     function isCashRegisterAvailable(warehouse_id) {
         $.ajax({
             url: '../../cash-register/check-availability/'+warehouse_id,
             type: "GET",
             success:function(data) {
                 if(data == 'false') {
                     $('#cash-register-modal select[name=warehouse_id]').val(warehouse_id);
                     $('.selectpicker').selectpicker('refresh');
                     if(role_id <= 2){
                         $("#cash-register-modal .warehouse-section").removeClass('d-none');
                     }
                     else {
                         $("#cash-register-modal .warehouse-section").addClass('d-none');
                     }
                     $("#cash-register-modal").modal('show');
                 }
             }
         });
     }

     function productSearch(data){
         $.ajax({
             type: 'GET',
             url: '../lims_product_search',
             data: {
                 data: data
             },
             success: function(data) {
                 var flag = 1;
                 $(".product-code").each(function(i) {
                     if ($(this).val() == data[1]) {
                         rowindex = i;
                         var qty = parseFloat($('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ') .qty').val()) + 1;
                         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ') .qty').val(qty);
                         checkQuantity(String(qty), true);
                         flag = 0;
                     }
                 });
                 $("input[name='product_code_name']").val('');
                 if (flag) {
                     var newRow = $("<tr>");
                     var cols = '';
                     temp_unit_name = (data[6]).split(',');
                     cols += '<td>' + data[0] + '<button type="button" class="edit-product btn btn-link" data-toggle="modal" data-target="#editModal"> <i class="dripicons-document-edit"></i></button></td>';
                     cols += '<td>' + data[1] + '</td>';
                     cols += '<td><input type="number" class="form-control qty" name="qty[]" value="1" step="any" required/></td>';
                     cols += '<td class="net_unit_price"></td>';
                     cols += '<td class="discount">0.00</td>';
                     cols += '<td class="tax"></td>';
                     cols += '<td class="sub-total"></td>';
                     cols += '<td><button type="button" class="ibtnDel btn btn-md btn-danger">Delete</button></td>';
                     cols += '<input type="hidden" class="product-code" name="product_code[]" value="' + data[1] + '"/>';
                     cols += '<input type="hidden" name="product_id[]" value="' + data[9] + '"/>';
                     cols += '<input type="hidden" name="product_variant_id[]" value="' + data[10] + '"/>';
                     cols += '<input type="hidden" class="sale-unit" name="sale_unit[]" value="' + temp_unit_name[0] + '"/>';
                     cols += '<input type="hidden" class="net_unit_price" name="net_unit_price[]" />';
                     cols += '<input type="hidden" class="discount-value" name="discount[]" />';
                     cols += '<input type="hidden" class="tax-rate" name="tax_rate[]" value="' + data[3] + '"/>';
                     cols += '<input type="hidden" class="tax-value" name="tax[]" />';
                     cols += '<input type="hidden" class="subtotal-value" name="subtotal[]" />';

                     newRow.append(cols);
                     $("table.order-list tbody").prepend(newRow);
                     rowindex = newRow.index();
                     pos = product_code.indexOf(data[1]);
                     if(!data[11] && product_warehouse_price[pos]) {
                         product_price.splice(rowindex, 0, parseFloat(product_warehouse_price[pos] * currency['exchange_rate']) + parseFloat(product_warehouse_price[pos] * currency['exchange_rate'] * customer_group_rate));
                     }
                     else {
                         product_price.splice(rowindex, 0, parseFloat(data[2] * currency['exchange_rate']) + parseFloat(data[2] * currency['exchange_rate'] * customer_group_rate));
                     }

                     product_discount.splice(rowindex, 0, '0.00');
                     tax_rate.splice(rowindex, 0, parseFloat(data[3]));
                     tax_name.splice(rowindex, 0, data[4]);
                     tax_method.splice(rowindex, 0, data[5]);
                     unit_name.splice(rowindex, 0, data[6]);
                     unit_operator.splice(rowindex, 0, data[7]);
                     unit_operation_value.splice(rowindex, 0, data[8]);
                     checkQuantity(1, true);
                 }
             }
         });
     }

     function edit(){
         var row_product_name = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(1)').text();
         var row_product_code = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(2)').text();
         $('#modal_header').text(row_product_name + '(' + row_product_code + ')');

         var qty = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val();
         $('input[name="edit_qty"]').val(qty);

         $('input[name="edit_discount"]').val(parseFloat(product_discount[rowindex]).toFixed(2));

         var tax_name_all = ["No Tax","vat@10","vat@15","vat 20"];
         pos = tax_name_all.indexOf(tax_name[rowindex]);
         $('select[name="edit_tax_rate"]').val(pos);

         pos = product_code.indexOf(row_product_code);
         if(product_type[pos] == 'standard'){
             unitConversion();
             temp_unit_name = (unit_name[rowindex]).split(',');
             temp_unit_name.pop();
             temp_unit_operator = (unit_operator[rowindex]).split(',');
             temp_unit_operator.pop();
             temp_unit_operation_value = (unit_operation_value[rowindex]).split(',');
             temp_unit_operation_value.pop();
             $('select[name="edit_unit"]').empty();
             $.each(temp_unit_name, function(key, value) {
                 $('select[name="edit_unit"]').append('<option value="' + key + '">' + value + '</option>');
             });
             $("#edit_unit").show();
         }
         else{
             row_product_price = product_price[rowindex];
             $("#edit_unit").hide();
         }
         $('input[name="edit_unit_price"]').val(row_product_price.toFixed(2));
         $('.selectpicker').selectpicker('refresh');
     }

     function checkQuantity(sale_qty, flag) {
         var row_product_code = $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(2)').text();
         pos = product_code.indexOf(row_product_code);
         if(product_type[pos] == 'standard'){
             var operator = unit_operator[rowindex].split(',');
             var operation_value = unit_operation_value[rowindex].split(',');
             if(operator[0] == '*')
                 total_qty = sale_qty * operation_value[0];
             else if(operator[0] == '/')
                 total_qty = sale_qty / operation_value[0];
             if (total_qty > parseFloat(product_qty[pos])) {
                 alert('Quantity exceeds stock quantity!');
                 if (flag) {
                     sale_qty = sale_qty.substring(0, sale_qty.length - 1);
                     $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val(sale_qty);
                 }
                 else {
                     edit();
                     return;
                 }
             }
         }
         else if(product_type[pos] == 'combo'){
             child_id = product_list[pos].split(',');
             child_qty = qty_list[pos].split(',');
             $(child_id).each(function(index) {
                 var position = product_id.indexOf(parseInt(child_id[index]));
                 if( parseFloat(sale_qty * child_qty[index]) > product_qty[position] ) {
                     alert('Quantity exceeds stock quantity!');
                     if (flag) {
                         sale_qty = sale_qty.substring(0, sale_qty.length - 1);
                         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val(sale_qty);
                     }
                     else {
                         edit();
                         flag = true;
                         return false;
                     }
                 }
             });
         }

         if(!flag){
             $('#editModal').modal('hide');
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.qty').val(sale_qty);
         }

         calculateRowProductData(sale_qty);
     }

     function calculateRowProductData(quantity) {
         if(product_type[pos] == 'standard')
             unitConversion();
         else
             row_product_price = product_price[rowindex];

         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(5)').text((product_discount[rowindex] * quantity).toFixed(2));
         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.discount-value').val((product_discount[rowindex] * quantity).toFixed(2));
         $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-rate').val(tax_rate[rowindex].toFixed(2));

         if (tax_method[rowindex] == 1) {
             var net_unit_price = row_product_price - product_discount[rowindex];
             var tax = net_unit_price * quantity * (tax_rate[rowindex] / 100);
             var sub_total = (net_unit_price * quantity) + tax;

             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(4)').text(net_unit_price.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.net_unit_price').val(net_unit_price.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(6)').text(tax.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-value').val(tax.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(7)').text(sub_total.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.subtotal-value').val(sub_total.toFixed(2));
         } else {
             var sub_total_unit = row_product_price - product_discount[rowindex];
             var net_unit_price = (100 / (100 + tax_rate[rowindex])) * sub_total_unit;
             var tax = (sub_total_unit - net_unit_price) * quantity;
             var sub_total = sub_total_unit * quantity;

             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(4)').text(net_unit_price.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.net_unit_price').val(net_unit_price.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(6)').text(tax.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.tax-value').val(tax.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('td:nth-child(7)').text(sub_total.toFixed(2));
             $('table.order-list tbody tr:nth-child(' + (rowindex + 1) + ')').find('.subtotal-value').val(sub_total.toFixed(2));
         }

         calculateTotal();
     }

     function unitConversion() {
         var row_unit_operator = unit_operator[rowindex].slice(0, unit_operator[rowindex].indexOf(","));
         var row_unit_operation_value = unit_operation_value[rowindex].slice(0, unit_operation_value[rowindex].indexOf(","));

         if (row_unit_operator == '*') {
             row_product_price = product_price[rowindex] * row_unit_operation_value;
         } else {
             row_product_price = product_price[rowindex] / row_unit_operation_value;
         }
     }

     function calculateTotal() {
         //Sum of quantity
         var total_qty = 0;
         $(".qty").each(function() {

             if ($(this).val() == '') {
                 total_qty += 0;
             } else {
                 total_qty += parseFloat($(this).val());
             }
         });
         $("#total-qty").text(total_qty);
         $('input[name="total_qty"]').val(total_qty);

         //Sum of discount
         var total_discount = 0;
         $(".discount").each(function() {
             total_discount += parseFloat($(this).text());
         });
         $("#total-discount").text(total_discount.toFixed(2));
         $('input[name="total_discount"]').val(total_discount.toFixed(2));

         //Sum of tax
         var total_tax = 0;
         $(".tax").each(function() {
             total_tax += parseFloat($(this).text());
         });
         $("#total-tax").text(total_tax.toFixed(2));
         $('input[name="total_tax"]').val(total_tax.toFixed(2));

         //Sum of subtotal
         var total = 0;
         $(".sub-total").each(function() {
             total += parseFloat($(this).text());
         });
         $("#total").text(total.toFixed(2));
         $('input[name="total_price"]').val(total.toFixed(2));

         calculateGrandTotal();
     }

     function calculateGrandTotal() {

         var item = $('table.order-list tbody tr:last').index();

         var total_qty = parseFloat($('#total-qty').text());
         var subtotal = parseFloat($('#total').text());
         var order_tax = parseFloat($('select[name="order_tax_rate"]').val());
         var order_discount = parseFloat($('input[name="order_discount"]').val());
         var shipping_cost = parseFloat($('input[name="shipping_cost"]').val());

         if (!order_discount)
             order_discount = 0.00;
         if (!shipping_cost)
             shipping_cost = 0.00;

         item = ++item + '(' + total_qty + ')';
         order_tax = (subtotal - order_discount) * (order_tax / 100);
         var grand_total = (subtotal + order_tax + shipping_cost) - order_discount;
         $('input[name="grand_total"]').val(grand_total.toFixed(2));
         if($('input[name="coupon_active"]').val()) {
             couponDiscount();
             var coupon_discount = parseFloat($('input[name="coupon_discount"]').val());
             if (!coupon_discount)
                 coupon_discount = 0.00;
             grand_total -= coupon_discount;
         }

         $('#item').text(item);
         $('input[name="item"]').val($('table.order-list tbody tr:last').index() + 1);
         $('#subtotal').text(subtotal.toFixed(2));
         $('#order_tax').text(order_tax.toFixed(2));
         $('input[name="order_tax"]').val(order_tax.toFixed(2));
         $('#order_discount').text(order_discount.toFixed(2));
         $('#shipping_cost').text(shipping_cost.toFixed(2));
         $('#grand_total').text(grand_total.toFixed(2));
         $('input[name="grand_total"]').val(grand_total.toFixed(2));
     }

     function couponDiscount() {
         var rownumber = $('table.order-list tbody tr:last').index();
         if (rownumber < 0) {
             alert("Please insert product to order table!")
         }
         else{
             if($('input[name="coupon_type"]').val() == 'fixed'){
                 if( $('input[name="grand_total"]').val() >= $('input[name="coupon_minimum_amount"]').val() ) {
                     $('input[name="grand_total"]').val( $('input[name="grand_total"]').val() - $('input[name="coupon_amount"]').val() );
                 }
                 else
                     alert('Grand Total is not sufficient for discount! Required '+ currency['code'] + ' ' +$('input[name="coupon_minimum_amount"]').val());
             }
             else{
                 var grand_total = $('input[name="grand_total"]').val();
                 var coupon_discount = grand_total * (parseFloat($('input[name="coupon_amount"]').val()) / 100);
                 grand_total = grand_total - coupon_discount;
                 $('input[name="grand_total"]').val(grand_total);
                 $('input[name="coupon_discount"]').val(coupon_discount);
                 $('#coupon-text').text(parseFloat(coupon_discount).toFixed(2));
             }
         }
     }

     $('input[name="order_discount"]').on("input", function() {
         calculateGrandTotal();
     });

     $('input[name="shipping_cost"]').on("input", function() {
         calculateGrandTotal();
     });

     $('select[name="order_tax_rate"]').on("change", function() {
         calculateGrandTotal();
     });

     $(window).keydown(function(e){
         if (e.which == 13) {
             var $targ = $(e.target);
             if (!$targ.is("textarea") && !$targ.is(":button,:submit")) {
                 var focusNext = false;
                 $(this).find(":input:visible:not([disabled],[readonly]), a").each(function(){
                     if (this === e.target) {
                         focusNext = true;
                     }
                     else if (focusNext){
                         $(this).focus();
                         return false;
                     }
                 });
                 return false;
             }
         }
     });

     $('#payment-form').on('submit',function(e){
         var rownumber = $('table.order-list tbody tr:last').index();
         if (rownumber < 0) {
             alert("Please insert product to order table!")
             e.preventDefault();
         }
     });
     </script>




</body>
</html>
