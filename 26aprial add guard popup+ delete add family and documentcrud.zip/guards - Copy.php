<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/Employee.php");

$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="guards";
session_start();

$database = new Database();
$db = $database->getConnection();
$employee = new Employee($db);

if(isset($_SESSION["username"]))
{
  // $member->getMemberDetails($_SESSION['memberId']);
  $username = $_SESSION['username'];
}
else {
  // $memberId="Not logged in";
  header("location: ".$project->getProjectUrl()."index");
  exit;
}


if(isset($_POST['addNewValue']))
{
      $employee->setEmployeeCode($_POST['employee_code']);
      $employee->setEmployeeType($_POST['employee_type']);
      $employee->setSurname($_POST['fd_surname']);
      $employee->setFirstName($_POST['first_name']);
      $employee->setMName($_POST['middle_name']);
      $employee->setBirthDate($_POST['birthdate']);
      $employee->setAge($_POST['age']);
      $employee->setEducation($_POST['education']);
      $employee->setNominee($_POST['nominee']);
      $employee->setNomineeAge($_POST['nominee_age']);
      $employee->setNomineeRelation($_POST['nomineerelation']);
      $employee->setLeftDate($_POST['leftdate']);
      $employee->setReasonofLeaving($_POST['reasonofleaving']);
      $employee->setNameInBank($_POST['nameInBank']);
      $employee->setPFName($_POST['pfname']);
      $employee->setPFMemberId($_POST['pfmemberId']);
      $employee->setJoiningDate($_POST['joiningdate']);
      $employee->setConfirmationDate($_POST['confirmationdate']);
      $employee->setIcardIssueDate($_POST['icardissuedate']);
      $employee->setRenewalDate($_POST['renewaldate']);
      $employee->setTRDeposit($_POST['trdeposit']);
       $employee->setESI($_POST['esi']);
       $employee->setESINumber($_POST['esinumber']);
       $employee->setSmartcardIssued($_POST['smartcardissued']);
       $employee->setUidNo($_POST['uidno']);
       $employee->setSex($_POST['sex']);
       $employee->setRejoining($_POST['rejoining']);
       $employee->setBankACClosed($_POST['bankacclosed']);
       $employee->setMLWF($_POST['mlwf']);
       $employee->setPF($_POST['fd_pf']);
       $employee->setPFNumber($_POST['fd_pfnumber']);
      $employee->setPFWithdrawal($_POST['pf_withdrawal']);
       $employee->setPFWithdrawalDate($_POST['pf_withdrawaldate']);
       $employee->setSubmissionDate($_POST['submissiondate']);
       $employee->setSettlementDate($_POST['settlementdate']);
       $employee->setChequeNumber($_POST['chequenumber']);
       $employee->setPTax($_POST['p_tax']);
       $employee->setAadharNameMismatch($_POST['aadharnamemismatch']);
      $employee->setAadharBirthdateYearOnly($_POST['aadharbirthdateyearonly']);

      if($employee->create())
      {
          $successmessage="guards is created successfully";
      }
      else {
          $errormessage ="guards Group cannot be added";
      }


    // $customergroup->setName($_POST['input_name']);
    // $customergroup->setSummary($_POST['input_summary']);
    // if($customergroup->create())
    // {
    //     $successmessage="Customer Group is created successfully";
    // }
    // else {
    //     $errormessage ="Customer Group cannot be added";
    // }

}

// if(isset($_POST['editValue']))
// {
//      $employee->setEmployeeId($_POST['employeeid']);
//      $employee->setSurname($_POST['sur_name']);
//
//      if($employee->update())
//      {
//        $successmessage="guards Information is updated successfully";
//      }
//      else {
//        $errormessage="Guards  Information could not be updated !!";
//      }
// }

if(isset($_POST['deleteValue']))
{

  $employee->setEmployeeId($_POST['fd_employee_id']);
    if($employee->delete())
    {
   $successmessage="guards details is  deleted  successfully";
    }
  else {
      $errormessage="guards details Information could not be deleted !!";
    }
  // $customergroup->setId($_POST['customer_group_id']);
  // if($customergroup->delete())
  // {
  //   $successmessage="Customer Group is deleted successfully";
  // }
  // else {
  //   $errormessage="Customer Group Information could not be deleted !!";
  // }
}

$allguards  = $employee->readAllGuards();
?>

<!DOCTYPE html>
<html>
<head>
   <?php include_once("htmlheader.php"); ?>
   <title><?php echo $project->getProjectFName()?> | Guards</title>

</head>

 <body onload="myFunction()" style="">
     <div id="loader"></div>

       <?php include_once("sidebar.php"); ?>

       <?php include_once("header.php"); ?>

       <div class="page">

      <!-- account modal -->
      <div id="account-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
        <div role="document" class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="exampleModalLabel" class="modal-title">Add Guards</h5>
                    <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
                </div>
                <div class="modal-body">
                  <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                    <form method="POST" action="guards" accept-charset="UTF-8">
                      <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                      <input name="addNewValue" type="hidden">
                      <div class="form-group">
                          <label>Employee Code</label>
                          <input type="text" name="employee_code" id="employee_code" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>Employee Type</label>
                          <input type="text" name="employee_type" id="employee_type" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>SurName </label>
                          <input type="text" name="fd_surname" id="fd_surname" required="" class="form-control">
                      </div>
                      <div class="form-group">
                          <label>FristName </label>
                          <input type="text" name="first_name" id="first_name" required="" class="form-control">
                      </div>
                     <div class="form-group">
                          <label>MiddleName </label>
                          <input type="text" name="middle_name" id="middle_name" required="" class="form-control">
                      </div>
                      <div class="form-group">
                           <label>Birthdate </label>
                           <input type="text" name="birthdate" id="birthdate" required="" class="form-control">
                       </div>
                       <div class="form-group">
                            <label>Age </label>
                            <input type="number" name="age" id="age" required="" class="form-control">
                        </div>
                        <div class="form-group">
                             <label>Education </label>
                             <input type="text" name="education" id="education" required="" class="form-control">
                         </div>
                         <div class="form-group">
                              <label>Nominee </label>
                              <input type="text" name="nominee" id="nominee" required="" class="form-control">
                          </div>
                          <div class="form-group">
                               <label>Nominee Age</label>
                               <input type="number" name="nominee_age" id="nominee_age" required="" class="form-control">
                           </div>
                           <div class="form-group">
                                <label>Nominee Relation</label>
                                <input type="text" name="nomineerelation" id="nomineerelation" required="" class="form-control">
                            </div>

                            <div class="form-group">
                                 <label>Left Date</label>
                                 <input type="text" name="leftdate" id="leftdate" required="" class="form-control">
                             </div>

                             <div class="form-group">
                                  <label>Resson Of Leaving</label>
                                  <input type="text" name="reasonofleaving" id="reasonofleaving" required="" class="form-control">
                              </div>
                              <div class="form-group">
                                   <label>Name In Bank</label>
                                   <input type="text" name="nameInBank" id="nameInBank" required="" class="form-control">
                               </div>
                               <div class="form-group">
                                    <label>PF Name</label>
                                    <input type="text" name="pfname" id="pfname" required="" class="form-control">
                                </div>
                                <div class="form-group">
                                     <label>PF MemberID</label>
                                     <input type="text" name="pfmemberId" id="pfmemberId" required="" class="form-control">
                                 </div>
                                 <div class="form-group">
                                      <label>Joining Date</label>
                                      <input type="text" name="joiningdate" id="joiningdate" required="" class="form-control">
                                  </div>
                                  <div class="form-group">
                                       <label>Confirmation  Date</label>
                                       <input type="text" name="confirmationdate" id="confirmationdate" required="" class="form-control">
                                   </div>
                                    <div class="form-group">
                                        <label>ID Card Issuedate  Date</label>
                                        <input type="text" name="icardissuedate" id="icardissuedate" required="" class="form-control">
                                    </div>
                                    <div class="form-group">
                                         <label>Renewal Date</label>
                                         <input type="text" name="renewaldate" id="renewaldate" required="" class="form-control">
                                     </div>
                                     <div class="form-group">
                                          <label>TR Deposit</label>
                                          <input type="text" name="trdeposit" id="trdeposit" required="" class="form-control">
                                      </div>
                                      <div class="form-group">
                                           <label>ESI</label>
                                           <input type="text" name="esi" id="esi" required="" class="form-control">
                                       </div>
                                       <div class="form-group">
                                            <label>ESI Number</label>
                                            <input type="number" name="esinumber" id="esinumber" required="" class="form-control">
                                        </div>
                                        <div class="form-group">
                                             <label>Smartcard Issued</label>
                                             <input type="text" name="smartcardissued" id="smartcardissued" required="" class="form-control">
                                         </div>
                                         <div class="form-group">
                                              <label>Uid No</label>
                                              <input type="number" name="uidno" id="uidno" required="" class="form-control">
                                          </div>
                                         <div class="form-group">
                                               <label>Gender</label>
                                               <input type="text" name="sex" id="sex" required="" class="form-control">
                                           </div>
                                         <div class="form-group">
                                                <label>Rejoining</label>
                                                <input type="number" name="rejoining" id="rejoining" required="" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                 <label>Bank Acc Closed</label>
                                                 <input type="text" name="bankacclosed" id="bankacclosed" required="" class="form-control">
                                             </div>
                                             <div class="form-group">
                                                  <label>MlWF</label>
                                                  <input type="number" name="mlwf" id="mlwf" required="" class="form-control">
                                              </div>
                                              <div class="form-group">
                                                   <label>PF</label>
                                                   <input type="number" name="fd_pf" id="fd_pf" required="" class="form-control">
                                               </div>
                                               <div class="form-group">
                                                    <label>PF Number</label>
                                                    <input type="text" name="fd_pfnumber" id="fd_pfnumber" required="" class="form-control">
                                                </div>
                                              <div class="form-group">
                                                     <label>PF Withdrawal</label>
                                                     <input type="text" name="pf_withdrawal" id="pf_withdrawal" required="" class="form-control">
                                                 </div>

                                                 <div class="form-group">
                                                      <label>PF Withdrawal Date</label>
                                                      <input type="text" name="pf_withdrawaldate" id="pf_withdrawaldate" required="" class="form-control">
                                                  </div>
                                                  <div class="form-group">
                                                       <label>Submission Date</label>
                                                       <input type="text" name="submissiondate" id="submissiondate" required="" class="form-control">
                                                   </div>

                                                    <div class="form-group">
                                                         <label>Settlement Date</label>
                                                         <input type="text" name="settlementdate" id="settlementdate" required="" class="form-control">
                                                     </div>
                                                   <div class="form-group">
                                                          <label>Cheque Number</label>
                                                          <input type="text" name="chequenumber" id="chequenumber" required="" class="form-control">
                                                      </div>
                                                      <div class="form-group">
                                                           <label>P Tax</label>
                                                           <input type="text" name="p_tax" id="p_tax" required="" class="form-control">
                                                       </div>

                                                       <div class="form-group">
                                                            <label>Aadhar Namemismatch</label>
                                                            <input type="text" name="aadharnamemismatch" id="aadharnamemismatch" required="" class="form-control">
                                                        </div>
                                                        <div class="form-group">
                                                             <label>Aadhar Birthdate Yearly</label>
                                                             <input type="text" name="aadharbirthdateyearonly" id="aadharbirthdateyearonly" required="" class="form-control">
                                                         </div>
                      <!-- <div class="form-group">
                          <label>Summery *</label>

                          <textarea name="input_summary" id="input_summary" rows="3" class="form-control"></textarea>
                      </div> -->
                      <div class="form-group">
                          <button type="submit" class="btn btn-primary">Submit</button>
                      </div>
                    </form>
                </div>
            </div>
        </div>
      </div>


      <div style="display: block;" id="content" class="animate-bottom">

      <?php
      if(isset($successmessage))
      {
      ?>
      <div class="alert alert-success alert-dismissible text-center">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo $successmessage; ?>
      </div>
    <?php } ?>
    <?php
    if(isset($errormessage))
    {
    ?>
    <div class="alert alert-danger alert-dismissible text-center">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <?php echo $errormessage; ?>
    </div>
  <?php } ?>



<section>
    <div class="container-fluid">
        <button class="btn btn-info" data-toggle="modal" data-target="#account-modal"><i class="dripicons-plus"></i> Add Guards</button>
    </div>
    <div class="table-responsive">
        <div id="account-table_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">

          <table id="account-table" class="table dataTable" role="grid" aria-describedby="account-table_info">
            <thead>
                <tr role="row">
                  <th class="not-exported dt-checkboxes-cell dt-checkboxes-select-all sorting_disabled" rowspan="1" colspan="1" style="width:10px;" data-col="0" aria-label="">
                    <div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>
                  </th>
                  <th class="sorting" tabindex="0" aria-controls="account-table" rowspan="1" colspan="1" aria-label="Employee Code" style="width: 150px;">Employee Code</th>
                  <th class="sorting" tabindex="0" aria-controls="account-table" rowspan="1" colspan="1" aria-label="Surname: activate to sort column ascending" style="width: 0px;">Surname</th>
                  <th class="sorting" tabindex="0" aria-controls="account-table" rowspan="1" colspan="1" aria-label="Firstname: activate to sort column ascending" style="width: 0px;">Firstname</th>
                  <th class="sorting" tabindex="0" aria-controls="account-table" rowspan="1" colspan="1" aria-label="Firstname: activate to sort column ascending" style="width: 0px;">status</th>
                  <th class="not-exported sorting_disabled" rowspan="1" colspan="1" aria-label="Action" style="width: 130px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php

                foreach($allguards as $guardValue)
                {
                ?>
                <tr role="row" class="odd">
                    <td class="dt-checkboxes-cell">
                      <div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>
                    </td>
                    <td><?php echo $guardValue['fd_employee_code'];  ?></td>
                    <td><?php echo $guardValue['fd_surname'];  ?></td>
                    <td><?php echo $guardValue['fd_firstname'];  ?></td>
                    <td>
                      <button type="button" class="btn btn-block btn-success btn-xs">
                        <?php echo $guardValue['fd_status'];  ?></button>
                    </td>

                    <td>
                        <div class="btn-group">
                          <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action
                              <span class="caret"></span>
                              <span class="sr-only">Toggle Dropdown</span>
                          </button>
                            <ul class="dropdown-menu edit-options dropdown-menu-right dropdown-default" user="menu">


                                <li><a href="edit_garddetails?id=<?php echo $guardValue['fd_employee_id']; ?>"class="edit-btn btn btn-link" data-toggle1="modal" data-target1="#editModal">
                                  <i class="dripicons-document-edit"></i> Edit Guards Details </a></li>



                                <li class="divider"></li>
                                <form method="POST" action="guards" accept-charset="UTF-8">
                                  <input name="deleteValue" type="hidden" value="DELETE">
                                  <input name="_token" type="hidden" value="XYYjjamO1aW94qFJZGPbZRSDfRySAqOIjRMo2mRO">
                                  <input name="fd_employee_id" type="hidden" value="<?php echo $guardValue['fd_employee_id']; ?>">
                                <li>
                                  <button type="submit"  class="btn btn-link" onclick="return confirmDelete()"><i class="dripicons-trash"></i> Delete</button>
                                </li>
                                </form>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php
                }
                ?>
                </tbody>
        </table>

      </div>
    </div>
</section>



<script type="text/javascript">

    $("ul#account").siblings('a').attr('aria-expanded','true');
    $("ul#account").addClass("show");
    $("ul#account #account-list-menu").addClass("active");

    $('.edit-btn').on('click', function() {
        //$("#editModal input[name='fd_surname']").val( $(this).data('sur_name') );
      //  $("#editModal textarea[name='summary']").val( $(this).data('summary') );
      //  $("#editModal input[name='fd_employee_id']").val( $(this).data('fd_employee_id') );
    });

    $('.default').on('change', function() {
        //off to on
        if ($(this).parent().hasClass("btn-success")) {
            var id = $(this).data('id');
            $('.default').not($(this)).parent().removeClass('btn-success');
            $('.default').not($(this)).parent().addClass('btn-danger off');
            $('.default').not($(this)).prop('checked', false);
            $(this).prop('checked', true);
            $.get('accounts/make-default/' + id, function(data) {
                alert(data);
            });
        }
        //on to off
        else {
            $(this).parent().removeClass('btn-danger off');
            $(this).parent().addClass('btn-success');
            $(this).prop('checked', true);
            alert('Please make another account default first!');
        }
    });

    function confirmDelete() {
        if (confirm("Are you sure want to delete?")) {
            return true;
        }
        return false;
    }
    var table = $('#account-table').DataTable( {
        "order": [],
        'language': {
            'lengthMenu': '_MENU_ records per page',
             "info":      '<small>Showing _START_ - _END_ (_TOTAL_)</small>',
            "search":  'Search',
            'paginate': {
                    'previous': '<i class="dripicons-chevron-left"></i>',
                    'next': '<i class="dripicons-chevron-right"></i>'
            }
        },
        'columnDefs': [
            {
                "orderable": false,
                'targets': [0, 3]
            },
            {
                'render': function(data, type, row, meta){
                    if(type === 'display'){
                        data = '<div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>';
                    }

                   return data;
                },
                'checkboxes': {
                   'selectRow': true,
                   'selectAllRender': '<div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>'
                },
                'targets': [0]
            }
        ],
        'select': { style: 'multi',  selector: 'td:first-child'},
        'lengthMenu': [[10, 25, 50, -1], [10, 25, 50, "All"]],
        dom: '<"row"lfB>rtip',
        buttons: [
            {
                extend: 'pdf',
                text: 'PDF',
                exportOptions: {
                    columns: ':visible:Not(.not-exported)',
                    rows: ':visible'
                },
                action: function(e, dt, button, config) {
                    datatable_sum(dt, true);
                    $.fn.dataTable.ext.buttons.pdfHtml5.action.call(this, e, dt, button, config);
                    datatable_sum(dt, false);
                },
                footer:true
            },
            {
                extend: 'csv',
                text: 'CSV',
                exportOptions: {
                    columns: ':visible:Not(.not-exported)',
                    rows: ':visible'
                },
                action: function(e, dt, button, config) {
                    datatable_sum(dt, true);
                    $.fn.dataTable.ext.buttons.csvHtml5.action.call(this, e, dt, button, config);
                    datatable_sum(dt, false);
                },
                footer:true
            },
            {
                extend: 'print',
                text: 'Print',
                exportOptions: {
                    columns: ':visible:Not(.not-exported)',
                    rows: ':visible'
                },
                action: function(e, dt, button, config) {
                    datatable_sum(dt, true);
                    $.fn.dataTable.ext.buttons.print.action.call(this, e, dt, button, config);
                    datatable_sum(dt, false);
                },
                footer:true
            },
            {
                extend: 'colvis',
                text: 'Column visibility',
                columns: ':gt(0)'
            },
        ],
        drawCallback: function () {
            var api = this.api();
            datatable_sum(api, false);
        }
    } );
    function datatable_sum(dt_selector, is_calling_first) {
        if (dt_selector.rows( '.selected' ).any() && is_calling_first) {
            var rows = dt_selector.rows( '.selected' ).indexes();
            $( dt_selector.column( 3 ).footer() ).html(dt_selector.cells( rows, 3, { page: 'current' } ).data().sum().toFixed(2));
        }
        else {
            $( dt_selector.column( 3 ).footer() ).html(dt_selector.cells( rows, 3, { page: 'current' } ).data().sum().toFixed(2));
        }
    }

</script>
      </div>

      <?php include_once("footer.php"); ?>
    </div>


<script type="text/javascript">
       if ($(window).outerWidth() > 1199) {
           $('nav.side-navbar').removeClass('shrink');
       }

       function myFunction() {
           setTimeout(showPage, 150);
       }
       function showPage() {
         document.getElementById("loader").style.display = "none";
         document.getElementById("content").style.display = "block";
       }

       $("div.alert").delay(3000).slideUp(750);

       function confirmDelete() {
           if (confirm("Are you sure want to delete?")) {
               return true;
           }
           return false;
       }

       $("a#add-expense").click(function(e){
         e.preventDefault();
         $('#expense-modal').modal();
       });

       $("a#add-account").click(function(e){
         e.preventDefault();
         $('#account-modal').modal();
       });

       $("a#account-statement").click(function(e){
         e.preventDefault();
         $('#account-statement-modal').modal();
       });

       $("a#profitLoss-link").click(function(e){
         e.preventDefault();
         $("#profitLoss-report-form").submit();
       });

       $("a#report-link").click(function(e){
         e.preventDefault();
         $("#product-report-form").submit();
       });

       $("a#purchase-report-link").click(function(e){
         e.preventDefault();
         $("#purchase-report-form").submit();
       });

       $("a#sale-report-link").click(function(e){
         e.preventDefault();
         $("#sale-report-form").submit();
       });

       $("a#payment-report-link").click(function(e){
         e.preventDefault();
         $("#payment-report-form").submit();
       });

       $("a#warehouse-report-link").click(function(e){
         e.preventDefault();
         $('#warehouse-modal').modal();
       });

       $("a#user-report-link").click(function(e){
         e.preventDefault();
         $('#user-modal').modal();
       });

       $("a#customer-report-link").click(function(e){
         e.preventDefault();
         $('#customer-modal').modal();
       });

       $("a#supplier-report-link").click(function(e){
         e.preventDefault();
         $('#supplier-modal').modal();
       });

       $("a#due-report-link").click(function(e){
         e.preventDefault();
         $("#due-report-form").submit();
       });

       $(".daterangepicker-field").daterangepicker({
           callback: function(startDate, endDate, period){
             var start_date = startDate.format('YYYY-MM-DD');
             var end_date = endDate.format('YYYY-MM-DD');
             var title = start_date + ' To ' + end_date;
             $(this).val(title);
             $('#account-statement-modal input[name="start_date"]').val(start_date);
             $('#account-statement-modal input[name="end_date"]').val(end_date);
           }
       });

       $('.selectpicker').selectpicker({
           style: 'btn-link',
       });
     </script>


</body>
</html>
