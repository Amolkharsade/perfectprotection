<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/User.php");

$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="home";
session_start();

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

if(isset($_SESSION["username"]))
{
  // $member->getMemberDetails($_SESSION['memberId']);
  $username = $_SESSION['username'];
  $user->getUserByEmail($_SESSION['username']);
}
else {
  // $memberId="Not logged in";
  header("location: ".$project->getProjectUrl()."index");
  exit;
}


 ?>

<!DOCTYPE html>
<html>
<head>
   <?php include_once("htmlheader.php"); ?>
   <title><?php echo $project->getProjectFName()?> | Home</title>

</head>

 <body onload="myFunction()" style="">
     <div id="loader"></div>

       <?php include_once("sidebar.php"); ?>

       <?php include_once("header.php"); ?>

     <div class="page">


       <div style="display: block;" id="content" class="animate-bottom">
           <!-- this portion is for demo only -->
 <!-- <style type="text/css">

   nav.navbar a.menu-btn {
     padding: 12 !important;
   }
   .color-switcher {
       background-color: #fff;
       border: 1px solid #e5e5e5;
       border-radius: 2px;
       padding: 10px;
       position: fixed;
       top: 150px;
       transition: all 0.4s ease 0s;
       width: 150px;
       z-index: 99999;
   }
   .hide-color-switcher {
       right: -150px;
   }
   .show-color-switcher {
       right: -1px;
   }
   .color-switcher a.switcher-button {
       background: #fff;
       border-top: #e5e5e5;
       border-right: #e5e5e5;
       border-bottom: #e5e5e5;
       border-left: #e5e5e5;
       border-style: solid solid solid solid;
       border-width: 1px 1px 1px 1px;
       border-radius: 2px;
       color: #161616;
       cursor: pointer;
       font-size: 22px;
       width: 45px;
       height: 45px;
       line-height: 43px;
       position: absolute;
       top: 24px;
       left: -44px;
       text-align: center;
   }
   .color-switcher a.switcher-button i {
     line-height: 40px
   }
   .color-switcher .color-switcher-title {
       color: #666;
       padding: 0px 0 8px;
   }
   .color-switcher .color-switcher-title:after {
       content: "";
       display: block;
       height: 1px;
       margin: 14px 0 0;
       position: relative;
       width: 20px;
   }
   .color-switcher .color-list a.color {
       cursor: pointer;
       display: inline-block;
       height: 30px;
       margin: 10px 0 0 1px;
       width: 28px;
   }
   .purple-theme {
       background-color: #7c5cc4;
   }
   .green-theme {
       background-color: #1abc9c;
   }
   .blue-theme {
       background-color: #3498db;
   }
   .dark-theme {
       background-color: #34495e;
   }
 </style>
 <div class="color-switcher hide-color-switcher">
     <a class="switcher-button"><i class="fa fa-cog fa-spin"></i></a>
     <h5>Theme</h5>
     <div class="color-list">
         <a class="color purple-theme" title="purple" data-color="default.css"></a>
         <a class="color green-theme" title="green" data-color="green.css"></a>
         <a class="color blue-theme" title="blue" data-color="blue.css"></a>
         <a class="color dark-theme" title="dark" data-color="dark.css"></a>
     </div>
 </div> -->
       <div class="row">
         <div class="container-fluid">
           <div class="col-md-12">
             <div class="brand-text float-left mt-4">
                 <h3>Welcome <span><?php echo $user->getName(); ?></span> </h3>
             </div>
             <!-- <div class="filter-toggle btn-group">
               <button class="btn btn-secondary date-btn" data-start_date="2021-03-11" data-end_date="2021-03-11">Today</button>
               <button class="btn btn-secondary date-btn" data-start_date="2021-03-04" data-end_date="2021-03-11">Last 7 Days</button>
               <button class="btn btn-secondary date-btn active" data-start_date="2021-03-01" data-end_date="2021-03-11">This Month</button>
               <button class="btn btn-secondary date-btn" data-start_date="2021-01-01" data-end_date="2021-12-31">This Year</button>
             </div> -->
           </div>
         </div>
       </div>
       <!-- Counts Section -->
       <section class="dashboard-counts">
         <div class="container-fluid">
           <div class="row">
             <div class="col-md-12 form-group">
               <div class="row">
                 <!-- Count item widget-->
                 <div class="col-sm-3">
                   <div class="wrapper count-title text-center">
                     <div class="icon"><i class="dripicons-user" style="color: #733686"></i></div>
                     <div class="name"><strong style="color: #733686">Client</strong></div>
                     <div class="count-number revenue-data">540</div>
                   </div>
                 </div>
                 <!-- Count item widget-->
                 <div class="col-sm-3">
                   <div class="wrapper count-title text-center">
                     <div class="icon"><i class="dripicons-user" style="color: #ff8952"></i></div>
                     <div class="name"><strong style="color: #ff8952">Guards</strong></div>
                     <div class="count-number return-data">1230</div>
                   </div>
                 </div>
                 <!-- Count item widget-->
                 <div class="col-sm-3">
                   <div class="wrapper count-title text-center">
                     <div class="icon"><i class="dripicons-user" style="color: #00c689"></i></div>
                     <div class="name"><strong style="color: #00c689">Staff</strong></div>
                     <div class="count-number purchase_return-data">12</div>
                   </div>
                 </div>
                 <!-- Count item widget-->
                 <div class="col-sm-3">
                   <div class="wrapper count-title text-center">
                     <div class="icon"><i class="dripicons-user" style="color: #297ff9"></i></div>
                     <div class="name"><strong style="color: #297ff9">User</strong></div>
                     <div class="count-number profit-data">5</div>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
<!--
         <div class="container-fluid">
           <div class="row">
             <div class="col-md-12">
               <div class="card">
                 <div class="card-header d-flex align-items-center">
                   <h4>Yearly Report</h4>
                 </div>
                 <div class="card-body"><div class="chartjs-size-monitor" style="position: absolute; inset: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>
                   <canvas id="saleChart" data-sale_chart_value="[&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;]" data-purchase_chart_value="[&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;,&quot;0.00&quot;]" data-label1="Purchased Amount" data-label2="Sold Amount" height="511" class="chartjs-render-monitor" width="1023" style="display: block; width: 1023px; height: 511px;"></canvas>
                 </div>
               </div>
             </div>
             <div class="col-md-7">
               <div class="card">
                 <div class="card-header d-flex justify-content-between align-items-center">
                   <h4>Recent Transaction</h4>
                   <div class="right-column">
                     <div class="badge badge-primary">Latest 5</div>
                   </div>
                 </div>
                 <ul class="nav nav-tabs" role="tablist">
                   <li class="nav-item">
                     <a class="nav-link active" href="http://localhost/erp/#sale-latest" role="tab" data-toggle="tab">Sale</a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="http://localhost/erp/#purchase-latest" role="tab" data-toggle="tab">Purchase</a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="http://localhost/erp/#quotation-latest" role="tab" data-toggle="tab">Quotation</a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="http://localhost/erp/#payment-latest" role="tab" data-toggle="tab">Payment</a>
                   </li>
                 </ul>

                 <div class="tab-content">
                   <div role="tabpanel" class="tab-pane fade show active" id="sale-latest">
                       <div class="table-responsive">
                         <table class="table">
                           <thead>
                             <tr>
                               <th>Date</th>
                               <th>Reference</th>
                               <th>Customer</th>
                               <th>Status</th>
                               <th>Grand Total</th>
                             </tr>
                           </thead>
                           <tbody>
                                                                                     <tr>
                               <td>06/04/2020</td>
                               <td>posr-20200406-074024</td>
                               <td>walk-in-customer</td>
                                                             <td><div class="badge badge-success">Completed</div></td>
                                                             <td>644</td>
                             </tr>
                                                                                     <tr>
                               <td>11/03/2020</td>
                               <td>sr-20200311-045230</td>
                               <td>dhiman</td>
                                                             <td><div class="badge badge-success">Completed</div></td>
                                                             <td>120</td>
                             </tr>
                                                                                     <tr>
                               <td>11/03/2020</td>
                               <td>posr-20200311-044641</td>
                               <td>walk-in-customer</td>
                                                             <td><div class="badge badge-success">Completed</div></td>
                                                             <td>352</td>
                             </tr>
                                                                                     <tr>
                               <td>02/03/2020</td>
                               <td>posr-20200302-115741</td>
                               <td>walk-in-customer</td>
                                                             <td><div class="badge badge-success">Completed</div></td>
                                                             <td>40</td>
                             </tr>
                                                                                     <tr>
                               <td>02/03/2020</td>
                               <td>posr-20200302-115414</td>
                               <td>walk-in-customer</td>
                                                             <td><div class="badge badge-success">Completed</div></td>
                                                             <td>350</td>
                             </tr>
                                                       </tbody>
                         </table>
                       </div>
                   </div>
                   <div role="tabpanel" class="tab-pane fade" id="purchase-latest">
                       <div class="table-responsive">
                         <table class="table">
                           <thead>
                             <tr>
                               <th>Date</th>
                               <th>Reference</th>
                               <th>Supplier</th>
                               <th>Status</th>
                               <th>Grand Total</th>
                             </tr>
                           </thead>
                           <tbody>
                                                                                     <tr>
                               <td>02/03/2020</td>
                               <td>pr-20200302-115603</td>
                                                               <td>abdullah</td>
                                                                                           <td><div class="badge badge-success">Recieved</div></td>
                                                             <td>50</td>
                             </tr>
                                                                                     <tr>
                               <td>02/03/2020</td>
                               <td>pr-20200302-115510</td>
                                                               <td>N/A</td>
                                                                                           <td><div class="badge badge-success">Recieved</div></td>
                                                             <td>50</td>
                             </tr>
                                                                                     <tr>
                               <td>04/02/2020</td>
                               <td>pr-20200204-110041</td>
                                                               <td>abdullah</td>
                                                                                           <td><div class="badge badge-success">Recieved</div></td>
                                                             <td>300</td>
                             </tr>
                                                                                     <tr>
                               <td>01/01/2020</td>
                               <td>pr-20200101-022402</td>
                                                               <td>N/A</td>
                                                                                           <td><div class="badge badge-success">Recieved</div></td>
                                                             <td>1650</td>
                             </tr>
                                                                                     <tr>
                               <td>01/01/2020</td>
                               <td>pr-20200101-010631</td>
                                                               <td>abdullah</td>
                                                                                           <td><div class="badge badge-success">Recieved</div></td>
                                                             <td>60</td>
                             </tr>
                                                       </tbody>
                         </table>
                       </div>
                   </div>
                   <div role="tabpanel" class="tab-pane fade" id="quotation-latest">
                       <div class="table-responsive">
                         <table class="table">
                           <thead>
                             <tr>
                               <th>Date</th>
                               <th>Reference</th>
                               <th>Customer</th>
                               <th>Status</th>
                               <th>Grand Total</th>
                             </tr>
                           </thead>
                           <tbody>
                                                                                     <tr>
                               <td>23/10/2018</td>
                               <td>qr-20181023-061249</td>
                               <td>walk-in-customer</td>
                                                             <td><div class="badge badge-success">Sent</div></td>
                                                             <td>453</td>
                             </tr>
                                                                                     <tr>
                               <td>04/09/2018</td>
                               <td>qr-20180904-040257</td>
                               <td>dhiman</td>
                                                             <td><div class="badge badge-danger">Pending</div></td>
                                                             <td>77.1</td>
                             </tr>
                                                                                     <tr>
                               <td>09/08/2018</td>
                               <td>qr-20180809-055250</td>
                               <td>tariq</td>
                                                             <td><div class="badge badge-success">Sent</div></td>
                                                             <td>6913</td>
                             </tr>
                                                       </tbody>
                         </table>
                       </div>
                   </div>
                   <div role="tabpanel" class="tab-pane fade" id="payment-latest">
                       <div class="table-responsive">
                         <table class="table">
                           <thead>
                             <tr>
                               <th>Date</th>
                               <th>Reference</th>
                               <th>Amount</th>
                               <th>Paid By</th>
                             </tr>
                           </thead>
                           <tbody>
                                                         <tr>
                               <td>06/12/2020</td>
                               <td>ppr-20201206-062315</td>
                               <td>5000</td>
                               <td>Cash</td>
                             </tr>
                                                         <tr>
                               <td>06/04/2020</td>
                               <td>spr-20200406-074201</td>
                               <td>144</td>
                               <td>Cash</td>
                             </tr>
                                                         <tr>
                               <td>06/04/2020</td>
                               <td>spr-20200406-074024</td>
                               <td>500</td>
                               <td>Cash</td>
                             </tr>
                                                         <tr>
                               <td>11/03/2020</td>
                               <td>spr-20200311-044642</td>
                               <td>352</td>
                               <td>Cash</td>
                             </tr>
                                                         <tr>
                               <td>02/03/2020</td>
                               <td>ppr-20200302-115820</td>
                               <td>50</td>
                               <td>Cash</td>
                             </tr>
                                                       </tbody>
                         </table>
                       </div>
                   </div>
                 </div>
               </div>
             </div>
             <div class="col-md-5">
               <div class="card">
                 <div class="card-header d-flex justify-content-between align-items-center">
                   <h4>Best Seller March</h4>
                   <div class="right-column">
                     <div class="badge badge-primary">Top 5</div>
                   </div>
                 </div>
                 <div class="table-responsive">
                     <table class="table">
                       <thead>
                         <tr>
                           <th>SL No</th>
                           <th>Product Details</th>
                           <th>Qty</th>
                         </tr>
                       </thead>
                       <tbody>
                                               </tbody>
                     </table>
                   </div>
               </div>
             </div>
             <div class="col-md-6">
               <div class="card">
                 <div class="card-header d-flex justify-content-between align-items-center">
                   <h4>Best Seller 2021(Qty)</h4>
                   <div class="right-column">
                     <div class="badge badge-primary">Top 5</div>
                   </div>
                 </div>
                 <div class="table-responsive">
                     <table class="table">
                       <thead>
                         <tr>
                           <th>SL No</th>
                           <th>Product Details</th>
                           <th>Qty</th>
                         </tr>
                       </thead>
                       <tbody>
                                               </tbody>
                     </table>
                   </div>
               </div>
             </div>
             <div class="col-md-6">
               <div class="card">
                 <div class="card-header d-flex justify-content-between align-items-center">
                   <h4>Best Seller 2021(Price)</h4>
                   <div class="right-column">
                     <div class="badge badge-primary">Top 5</div>
                   </div>
                 </div>
                 <div class="table-responsive">
                     <table class="table">
                       <thead>
                         <tr>
                           <th>SL No</th>
                           <th>Product Details</th>
                           <th>Grand Total</th>
                         </tr>
                       </thead>
                       <tbody>
                                               </tbody>
                     </table>
                   </div>
               </div>
             </div>
           </div>
         </div> -->
       </section>

 <script type="text/javascript">
     // Show and hide color-switcher
     $(".color-switcher .switcher-button").on('click', function() {
         $(".color-switcher").toggleClass("show-color-switcher", "hide-color-switcher", 300);
     });

     // Color Skins
     $('a.color').on('click', function() {
         /*var title = $(this).attr('title');
         $('#style-colors').attr('href', 'css/skin-' + title + '.css');
         return false;*/
         $.get('setting/general_setting/change-theme/' + $(this).data('color'), function(data) {
         });
         var style_link= $('#custom-style').attr('href').replace(/([^-]*)$/, $(this).data('color') );
         $('#custom-style').attr('href', style_link);
     });

     $(".date-btn").on("click", function() {
         $(".date-btn").removeClass("active");
         $(this).addClass("active");
         var start_date = $(this).data('start_date');
         var end_date = $(this).data('end_date');
         $.get('dashboard-filter/' + start_date + '/' + end_date, function(data) {
             dashboardFilter(data);
         });
     });

     function dashboardFilter(data){
         $('.revenue-data').hide();
         $('.revenue-data').html(parseFloat(data[0]).toFixed(2));
         $('.revenue-data').show(500);

         $('.return-data').hide();
         $('.return-data').html(parseFloat(data[1]).toFixed(2));
         $('.return-data').show(500);

         $('.profit-data').hide();
         $('.profit-data').html(parseFloat(data[2]).toFixed(2));
         $('.profit-data').show(500);

         $('.purchase_return-data').hide();
         $('.purchase_return-data').html(parseFloat(data[3]).toFixed(2));
         $('.purchase_return-data').show(500);
     }
 </script>
       </div>

       <?php include_once("footer.php"); ?>

     </div>

<script type="text/javascript">
       if ($(window).outerWidth() > 1199) {
           $('nav.side-navbar').removeClass('shrink');
       }

       function myFunction() {
           setTimeout(showPage, 150);
       }
       function showPage() {
         document.getElementById("loader").style.display = "none";
         document.getElementById("content").style.display = "block";
       }

       $("div.alert").delay(3000).slideUp(750);

       function confirmDelete() {
           if (confirm("Are you sure want to delete?")) {
               return true;
           }
           return false;
       }

       $("a#add-expense").click(function(e){
         e.preventDefault();
         $('#expense-modal').modal();
       });

       $("a#add-account").click(function(e){
         e.preventDefault();
         $('#account-modal').modal();
       });

       $("a#account-statement").click(function(e){
         e.preventDefault();
         $('#account-statement-modal').modal();
       });

       $("a#profitLoss-link").click(function(e){
         e.preventDefault();
         $("#profitLoss-report-form").submit();
       });

       $("a#report-link").click(function(e){
         e.preventDefault();
         $("#product-report-form").submit();
       });

       $("a#purchase-report-link").click(function(e){
         e.preventDefault();
         $("#purchase-report-form").submit();
       });

       $("a#sale-report-link").click(function(e){
         e.preventDefault();
         $("#sale-report-form").submit();
       });

       $("a#payment-report-link").click(function(e){
         e.preventDefault();
         $("#payment-report-form").submit();
       });

       $("a#warehouse-report-link").click(function(e){
         e.preventDefault();
         $('#warehouse-modal').modal();
       });

       $("a#user-report-link").click(function(e){
         e.preventDefault();
         $('#user-modal').modal();
       });

       $("a#customer-report-link").click(function(e){
         e.preventDefault();
         $('#customer-modal').modal();
       });

       $("a#supplier-report-link").click(function(e){
         e.preventDefault();
         $('#supplier-modal').modal();
       });

       $("a#due-report-link").click(function(e){
         e.preventDefault();
         $("#due-report-form").submit();
       });

       $(".daterangepicker-field").daterangepicker({
           callback: function(startDate, endDate, period){
             var start_date = startDate.format('YYYY-MM-DD');
             var end_date = endDate.format('YYYY-MM-DD');
             var title = start_date + ' To ' + end_date;
             $(this).val(title);
             $('#account-statement-modal input[name="start_date"]').val(start_date);
             $('#account-statement-modal input[name="end_date"]').val(end_date);
           }
       });

       $('.selectpicker').selectpicker({
           style: 'btn-link',
       });
     </script>


</body>
</html>
