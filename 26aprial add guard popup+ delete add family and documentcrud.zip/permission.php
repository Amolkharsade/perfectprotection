<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/Role.php");

$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="role";
session_start();

$database = new Database();
$db = $database->getConnection();

$role = new Role($db);

if(isset($_SESSION["username"]))
{
  $username = $_SESSION['username'];
}
else {
  header("location: ".$project->getProjectUrl()."index");
  exit;
}

if(isset($_GET['id']))
{
  $role->getRoleByID($_GET['id']);
}
else {
  header("location:". $project->getProjectUrl()."role");
  exit;
}

?>

<!DOCTYPE html>
<html>
<head>
   <?php include_once("htmlheader.php"); ?>
   <title><?php echo $project->getProjectFName()?> | Permission</title>

</head>

 <body onload="myFunction()" style="">
     <div id="loader"></div>

       <?php include_once("sidebar.php"); ?>

       <?php include_once("header.php"); ?>

       <div class="page">

      <!-- account modal -->
      <div id="account-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
              <div role="document" class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h5 id="exampleModalLabel" class="modal-title">Add Account</h5>
                          <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true"><i class="dripicons-cross"></i></span></button>
                      </div>
                      <div class="modal-body">
                        <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                          <form method="POST" action="http://localhost/erp/accounts" accept-charset="UTF-8"><input name="_token" type="hidden" value="wb3zINYrrsuqhBihgGZGTZLjyNd8VhJhnLm8jc5m">
                            <div class="form-group">
                                <label>Account No *</label>
                                <input type="text" name="account_no" required="" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Name *</label>
                                <input type="text" name="name" required="" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Initial Balance</label>
                                <input type="number" name="initial_balance" step="any" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Note</label>
                                <textarea name="note" rows="3" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                          </form>
                      </div>
                  </div>
              </div>
            </div>

      <div style="display: block;" id="content" class="animate-bottom">
      <section class="forms">
          <div class="container-fluid">
              <div class="row">
                  <div class="col-md-12">
                      <div class="card">
                          <div class="card-header d-flex align-items-center">
                              <h4>Group Permission</h4>
                          </div>
                          <form method="POST" action="#" accept-charset="UTF-8">
                            <input name="_token" type="hidden" value="wb3zINYrrsuqhBihgGZGTZLjyNd8VhJhnLm8jc5m">
                            <div class="card-body">
                          	<input type="hidden" name="role_id" value="5">

                            <div class="table-responsive">
              						    <table class="table table-bordered permission-table">
              						        <thead>
              						        <tr>
              						            <th colspan="5" class="text-center"><?php echo $role->getName(); ?> Group Permission</th>
              						        </tr>
              						        <tr>
              						            <th rowspan="2" class="text-center">Module Name</th>
              						            <th colspan="4" class="text-center">
              						            	<div class="checkbox">
              						            		<input type="checkbox" id="select_all">
              						            		<label for="select_all">Permissions</label>
              						            	</div>
              						            </th>
              						        </tr>
              						        <tr>
              						            <th class="text-center">View</th>
              						            <th class="text-center">Add</th>
              						            <th class="text-center">Edit</th>
              						            <th class="text-center">Delete</th>
              						        </tr>
              						        </thead>
              						        <tbody>
              						        <tr>
              						            <td>Product</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="products-index" name="products-index">
              								                								                <label for="products-index"></label>
              							            	</div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="products-add" name="products-add">
              								                								                <label for="products-add"></label>
              							                </div>
              							            </div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="products-edit" name="products-edit">
              								                								                <label for="products-edit"></label>
              							                </div>
              							            </div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="products-delete" name="products-delete">
              								                								                <label for="products-delete"></label>
              							                </div>
              							            </div>
              						            </td>
              						        </tr>

              						        <tr>
              						            <td>Purchase</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="purchases-index" name="purchases-index">
              								                								                <label for="purchases-index"></label>
              							                </div>
              							            </div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="purchases-add" name="purchases-add">
              								                								                <label for="purchases-add"></label>
              							                </div>
              							            </div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="purchases-edit" name="purchases-edit">
              								                								                <label for="purchases-edit"></label>
              							                </div>
              							            </div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="purchases-delete" name="purchases-delete">
              								                								                <label for="purchases-delete"></label>
              							            	</div>
              						            	</div>
              						            </td>
              						        </tr>

              						        <tr>
              						            <td>Sale</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="sales-index" name="sales-index">
              								                								                <label for="sales-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="sales-add" name="sales-add">
              								                								                <label for="sales-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="sales-edit" name="sales-edit">
              								                								                <label for="sales-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="sales-delete" name="sales-delete">
              								                								                <label for="sales-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>

              						        <tr>
              						            <td>Expense</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="expenses-index" name="expenses-index">
              								                								                <label for="expenses-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="expenses-add" name="expenses-add">
              								                								                <label for="expenses-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="expenses-edit" name="expenses-edit">
              								                								                <label for="expenses-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="expenses-delete" name="expenses-delete">
              								                								                <label for="expenses-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>

              						        <tr>
              						            <td>Quotation</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="quotes-index" name="quotes-index">
              								                								                <label for="quotes-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="quotes-add" name="quotes-add">
              								                								                <label for="quotes-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="quotes-edit" name="quotes-edit">
              								                								                <label for="quotes-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="quotes-delete" name="quotes-delete">
              								                								                <label for="quotes-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>

              						        <tr>
              						            <td>Transfer</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="transfers-index" name="transfers-index">
              								                								                <label for="transfers-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="transfers-add" name="transfers-add">
              								                								                <label for="transfers-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="transfers-edit" name="transfers-edit">
              								                								                <label for="transfers-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="transfers-delete" name="transfers-delete">
              								                								                <label for="transfers-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>

              						        <tr>
              						            <td>Sale Return</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="returns-index" name="returns-index">
              								                								                <label for="returns-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="returns-add" name="returns-add">
              								                								                <label for="returns-add"></label>
              							                </div>
              							            </div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="returns-edit" name="returns-edit">
              								                								                <label for="returns-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="returns-delete" name="returns-delete">
              								                								                <label for="returns-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>

              						        <tr>
              						            <td>Purchase Return</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="purchase-return-index" name="purchase-return-index">
              								                								                <label for="purchase-return-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="purchase-return-add" name="purchase-return-add">
              								                								                <label for="purchase-return-add"></label>
              								            </div>
              						                </div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="purchase-return-edit" name="purchase-return-edit">
              								                								                <label for="purchase-return-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              						                	<div class="checkbox">
              								                								                <input type="checkbox" value="1" id="purchase-return-delete" name="purchase-return-delete">
              								                								                <label for="purchase-return-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>Employee</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="employees-index" name="employees-index">
              								                								                <label for="employees-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="employees-add" name="employees-add">
              								                								                <label for="employees-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="employees-edit" name="employees-edit">
              								                								                <label for="employees-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="employees-delete" name="employees-delete">
              								                								                <label for="employees-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>User</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="users-index" name="users-index">
              								                								                <label for="users-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="users-add" name="users-add">
              								                								                <label for="users-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="users-edit" name="users-edit">
              								                								                <label for="users-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="users-delete" name="users-delete">
              								                								                <label for="users-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>Customer</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="customers-index" name="customers-index">
              								                								                <label for="customers-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="customers-add" name="customers-add">
              								                								                <label for="customers-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="customers-edit" name="customers-edit">
              								                								                <label for="customers-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="customers-delete" name="customers-delete">
              								                								                <label for="customers-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>Biller</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="billers-index" name="billers-index">
              								                								                <label for="billers-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="billers-add" name="billers-add">
              								                								                <label for="billers-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue checked" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="billers-edit" name="billers-edit">
              								                								                <label for="billers-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="billers-delete" name="billers-delete">
              								                								                <label for="billers-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>Supplier</td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="suppliers-index" name="suppliers-index">
              								                								                <label for="suppliers-index"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="suppliers-add" name="suppliers-add">
              								                								                <label for="suppliers-add"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="suppliers-edit" name="suppliers-edit">
              								                								                <label for="suppliers-edit"></label>
              								            </div>
              						            	</div>
              						            </td>
              						            <td class="text-center">
              						                <div class="icheckbox_square-blue" aria-checked="false" aria-disabled="false">
              							                <div class="checkbox">
              								                								                <input type="checkbox" value="1" id="suppliers-delete" name="suppliers-delete">
              								                								                <label for="suppliers-delete"></label>
              								            </div>
              						            	</div>
              						            </td>
              						        </tr>
              						        						        <tr>
              						            <td>Accounting</td>
              						            <td class="report-permissions" colspan="5">
              						            	<span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="account-index" name="account-index">
              							                    									                    <label for="account-index" class="padding05">Account &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="money-transfer" name="money-transfer">
              							                    									                    <label for="money-transfer" class="padding05">Money Transfer &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="balance-sheet" name="balance-sheet">
              							                    									                    <label for="balance-sheet" class="padding05">Balance Sheet &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              						                    	<div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="account-statement" name="account-statement">
              							                    									                    <label for="account-statement" class="padding05">Account Statement &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>HRM</td>
              						            <td class="report-permissions" colspan="5">
              						            	<span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="department" name="department">
              							                    									                    <label for="department" class="padding05">Department &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="attendance" name="attendance">
              							                    									                    <label for="attendance" class="padding05">Attendance &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="payroll" name="payroll">
              							                    									                    <label for="payroll" class="padding05">Payroll &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="holiday" name="holiday">
              							                    									                    <label for="holiday" class="padding05">Holiday Approve &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>Reports</td>
              						            <td class="report-permissions" colspan="5">
              						            	<span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="profit-loss" name="profit-loss">
              							                    									                    <label for="profit-loss" class="padding05">Summary Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="best-seller" name="best-seller">
              							                    									                    <label for="best-seller" class="padding05">Best Seller &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="daily-sale" name="daily-sale">
              							                    									                    <label for="daily-sale" class="padding05">Daily Sale &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="monthly-sale" name="monthly-sale">
              							                    									                    <label for="monthly-sale" class="padding05">Monthly Sale &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="daily-purchase" name="daily-purchase">
              							                    									                    <label for="daily-purchase" class="padding05">Daily Purchase &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              						                    	<div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="monthly-purchase" name="monthly-purchase">
              							                    									                    <label for="monthly-purchase" class="padding05">Monthly Purchase &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="product-report" name="product-report">
              							                    									                    <label for="product-report" class="padding05">Product Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="payment-report" name="payment-report">
              							                    									                    <label for="payment-report" class="padding05">Payment Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="purchase-report" name="purchase-report">
              							                    									                    <label for="purchase-report" class="padding05"> Purchase Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="sale-report" name="sale-report">
              							                    									                    <label for="sale-report" class="padding05">Sale Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              						                    	<div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="warehouse-report" name="warehouse-report">
              							                    									                    <label for="warehouse-report" class="padding05">Warehouse Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              						                    	<div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="warehouse-stock-report" name="warehouse-stock-report">
              							                    									                    <label for="warehouse-stock-report" class="padding05">Warehouse Stock Chart &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              						                    	<div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="product-qty-alert" name="product-qty-alert">
              							                    														<label for="product-qty-alert" class="padding05">Product Quantity Alert &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              								        </span>
              								        <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="user-report" name="user-report">
              							                    									                    <label for="user-report" class="padding05">User Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="customer-report" name="customer-report">
              							                    									                    <label for="customer-report" class="padding05">Customer Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="supplier-report" name="supplier-report">
              							                    									                    <label for="Supplier-report" class="padding05">Supplier Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="due-report" name="due-report">
              							                    									                    <label for="due-report" class="padding05">Due Report &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>Settings</td>
              						            <td class="report-permissions" colspan="5">
              						            	<span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="warehouse" name="warehouse">
              							                    									                    <label for="warehouse" class="padding05">Warehouse &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						            	<span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="customer_group" name="customer_group">
              							                    									                    <label for="customer_group" class="padding05">Customer Group &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              								            <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="brand" name="brand">
              							                    									                    <label for="brand" class="padding05">Brand &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              								            <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="unit" name="unit">
              							                    									                    <label for="unit" class="padding05">Unit &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              								            <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="tax" name="tax">
              							                    									                    <label for="tax" class="padding05">Tax &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						            	<span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="general_setting" name="general_setting">
              							                    									                    <label for="general_setting" class="padding05">General Setting &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="mail_setting" name="mail_setting">
              							                    									                    <label for="mail_setting" class="padding05">Mail Setting &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="sms_setting" name="sms_setting">
              							                    									                    <label for="sms_setting" class="padding05">SMS Setting &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="create_sms" name="create_sms">
              							                    									                    <label for="create_sms" class="padding05">Create SMS &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="pos_setting" name="pos_setting">
              							                    									                    <label for="pos_setting" class="padding05">POS Setting &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="hrm_setting" name="hrm_setting">
              							                    									                    <label for="hrm_setting" class="padding05">HRM Setting &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						            </td>
              						        </tr>
              						        <tr>
              						            <td>Miscellaneous</td>
              						            <td class="report-permissions" colspan="5">
              						            	<span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="stock_count" name="stock_count">
              							                    									                    <label for="stock_count" class="padding05">Stock Count &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="adjustment" name="adjustment">
              							                    									                    <label for="adjustment" class="padding05">Adjustment &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="gift_card" name="gift_card">
              							                    									                    <label for="gift_card" class="padding05">Gift Card &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="coupon" name="coupon">
              							                    									                    <label for="coupon" class="padding05">Coupon &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="print_barcode" name="print_barcode">
              							                    									                    <label for="print_barcode" class="padding05">Print Barcode &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						                <span>
              						                    <div aria-checked="false" aria-disabled="false">
              								                <div class="checkbox">
              							                    								                    	<input type="checkbox" value="1" id="empty_database" name="empty_database">
              							                    									                    <label for="empty_database" class="padding05">Empty Database &nbsp;&nbsp;</label>
              								                </div>
              								            </div>
              						                </span>
              						            </td>
              						        </tr>
              						        </tbody>
              						    </table>
              						  </div>
        						          <div class="form-group">
        	                        <input type="submit" value="Submit" class="btn btn-primary">
                                  <a href="role" class="btn btn-warning">Cancel</a>
        	                    </div>
                            </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
      </section>

      <script type="text/javascript">

      	$("ul#setting").siblings('a').attr('aria-expanded','true');
          $("ul#setting").addClass("show");
          $("ul#setting #role-menu").addClass("active");

      	$("#select_all").on( "change", function() {
      	    if ($(this).is(':checked')) {
      	        $("tbody input[type='checkbox']").prop('checked', true);
      	    }
      	    else {
      	        $("tbody input[type='checkbox']").prop('checked', false);
      	    }
      	});
      </script>
            </div>


                  <?php include_once("footer.php"); ?>
          </div>
    <script type="text/javascript">
            if ($(window).outerWidth() > 1199) {
                $('nav.side-navbar').removeClass('shrink');
            }

            function myFunction() {
                setTimeout(showPage, 150);
            }
            function showPage() {
              document.getElementById("loader").style.display = "none";
              document.getElementById("content").style.display = "block";
            }

            $("div.alert").delay(3000).slideUp(750);

            function confirmDelete() {
                if (confirm("Are you sure want to delete?")) {
                    return true;
                }
                return false;
            }

            $("a#add-expense").click(function(e){
              e.preventDefault();
              $('#expense-modal').modal();
            });

            $("a#add-account").click(function(e){
              e.preventDefault();
              $('#account-modal').modal();
            });

            $("a#account-statement").click(function(e){
              e.preventDefault();
              $('#account-statement-modal').modal();
            });

            $("a#profitLoss-link").click(function(e){
              e.preventDefault();
              $("#profitLoss-report-form").submit();
            });

            $("a#report-link").click(function(e){
              e.preventDefault();
              $("#product-report-form").submit();
            });

            $("a#purchase-report-link").click(function(e){
              e.preventDefault();
              $("#purchase-report-form").submit();
            });

            $("a#sale-report-link").click(function(e){
              e.preventDefault();
              $("#sale-report-form").submit();
            });

            $("a#payment-report-link").click(function(e){
              e.preventDefault();
              $("#payment-report-form").submit();
            });

            $("a#warehouse-report-link").click(function(e){
              e.preventDefault();
              $('#warehouse-modal').modal();
            });

            $("a#user-report-link").click(function(e){
              e.preventDefault();
              $('#user-modal').modal();
            });

            $("a#customer-report-link").click(function(e){
              e.preventDefault();
              $('#customer-modal').modal();
            });

            $("a#supplier-report-link").click(function(e){
              e.preventDefault();
              $('#supplier-modal').modal();
            });

            $("a#due-report-link").click(function(e){
              e.preventDefault();
              $("#due-report-form").submit();
            });

            $(".daterangepicker-field").daterangepicker({
                callback: function(startDate, endDate, period){
                  var start_date = startDate.format('YYYY-MM-DD');
                  var end_date = endDate.format('YYYY-MM-DD');
                  var title = start_date + ' To ' + end_date;
                  $(this).val(title);
                  $('#account-statement-modal input[name="start_date"]').val(start_date);
                  $('#account-statement-modal input[name="end_date"]').val(end_date);
                }
            });

            $('.selectpicker').selectpicker({
                style: 'btn-link',
            });
          </script>



</html>
