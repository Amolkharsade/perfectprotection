<?php
require_once("businessLogic/Project.php");
require_once("businessLogic/Database.php");
require_once("businessLogic/User.php");


$project = new Project();
if($project->getMaintainenceFlag()=="true")
{
  header("location: maintenance");
  exit;
}
$page="userprofile";
session_start();

$database = new Database();
$db = $database->getConnection();
$user= new User($db);

if(isset($_SESSION["username"]))
{
  $username = $_SESSION['username'];

  $user->getUserByEmail($_SESSION['username']);
}
else {
  header("location: ".$project->getProjectUrl()."index");
  exit;
}

if(isset($_POST['editOther']))
{
    $user->setId($user->getId());
    $user->setName($_POST['name']);
    $user->setPhone($_POST['phone']);
    if($user->updateOther())
    {
      $successmessage="User Information is updated successfully";
    }
    else {
      $errormessage="User Information could not be updated !!";
    }
}

if(isset($_POST['changepassword']))
{

  $oldpassword=$_POST['current_pass'];
  $newPassword=$_POST['new_pass'];
  $confirmPassword =$_POST['confirm_pass'];

  $value = $user->emaillogin($user->getEmail(), $oldpassword);
  if($value==1)
  {
    if($newPassword==$confirmPassword)
    {
      $user->setId($user->getId());
      $user->setPassword($_POST['new_pass']);
      if($user->updatePassword())
      {
        $successmessage="User Password is updated successfully";
      }
      else {
        $errormessage="User Password could not be updated !!";
      }
    }
    else {
      $errormessage="New password and confirm password are not matching !!";
    }

  }
  else {
      $errormessage="Current Password is not matching !!";
  }



}

?>
<!DOCTYPE html>
<html>
<head>
   <?php include_once("htmlheader.php"); ?>
   <title><?php echo $project->getProjectFName()?> | User Profile</title>

</head>

 <body onload="myFunction()" style="">
     <div id="loader"></div>

       <?php include_once("sidebar.php"); ?>

       <?php include_once("header.php"); ?>

       <div class="page">

       <div style="display: block;" id="content" class="animate-bottom">

               <?php
               if(isset($successmessage))
               {
               ?>
               <div class="alert alert-success alert-dismissible text-center">
                 <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                 <?php echo $successmessage; ?>
               </div>
             <?php } ?>
             <?php
             if(isset($errormessage))
             {
             ?>
             <div class="alert alert-danger alert-dismissible text-center">
               <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
               <?php echo $errormessage; ?>
             </div>
           <?php } ?>


           <section class="forms">
               <div class="container-fluid">
                   <div class="row">
                       <div class="col-md-6">
                           <div class="card">
                               <div class="card-header d-flex align-items-center">
                                   <h4>Update User Profile</h4>
                               </div>
                               <div class="card-body">
                                   <p class="italic"><small>The field labels marked with * are required input fields.</small></p>
                                   <form method="POST" action="userprofile" accept-charset="UTF-8"><input name="_method" type="hidden" value="PUT"><input name="_token" type="hidden" value="wb3zINYrrsuqhBihgGZGTZLjyNd8VhJhnLm8jc5m">
                                   <div class="row">
                                       <div class="col-md-12">
                                           <div class="form-group">
                                               <label>Email * </label>
                                               <input readonly type="email" name="email" value="<?php echo $user->getEmail(); ?>" required="" class="form-control">
                                           </div>
                                           <div class="form-group">
                                               <label>Name * </label>
                                               <input type="text" name="name" value="<?php echo $user->getName(); ?>" required="" class="form-control">
                                           </div>
                                           <div class="form-group">
                                               <label>Phone Number * </label>
                                               <input type="text" name="phone" value="<?php echo $user->getPhone(); ?>" required="" class="form-control">
                                           </div>
                                           <div class="form-group">
                                               <input type="submit" value="Submit" class="btn btn-primary">
                                               <input type="hidden" name="editOther" value="success">
                                           </div>
                                       </div>
                                   </div>
                                   </form>
                               </div>
                           </div>
                       </div>

                       <div class="col-md-6">
                           <div class="card">
                               <div class="card-header d-flex align-items-center">
                                   <h4>Change Password</h4>
                               </div>
                               <div class="card-body">
                                   <form method="POST" action="userprofile" accept-charset="UTF-8"><input name="_method" type="hidden" value="PUT"><input name="_token" type="hidden" value="wb3zINYrrsuqhBihgGZGTZLjyNd8VhJhnLm8jc5m">
                                   <div class="row">
                                       <div class="col-md-12">
                                           <div class="form-group">
                                               <label>Current Password * </label>
                                               <input type="password" name="current_pass" required="" class="form-control">
                                           </div>
                                           <div class="form-group">
                                               <label>New Password * </label>
                                               <input type="password" name="new_pass" required="" class="form-control">
                                           </div>
                                           <div class="form-group">
                                               <label>Confirm Password * </label>
                                               <input type="password" name="confirm_pass" id="confirm_pass" required="" class="form-control">
                                           </div>
                                           <div class="form-group">
                                               <div class="registrationFormAlert" id="divCheckPasswordMatch">
                                               </div>
                                           </div>
                                           <div class="form-group">
                                               <input type="submit" value="Submit" class="btn btn-primary">
                                               <input type="hidden" name="changepassword" value="success">
                                           </div>
                                       </div>
                                   </div>
                                   </form>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </section>

           <script type="text/javascript">
               $("ul#setting").siblings('a').attr('aria-expanded','true');
               $("ul#setting").addClass("show");
               $("ul#setting #user-menu").addClass("active");


               $('#confirm_pass').on('input', function(){

                   if($('input[name="new_pass"]').val() != $('input[name="confirm_pass"]').val())
                       $("#divCheckPasswordMatch").html("Password doesn't match!");
                   else
                       $("#divCheckPasswordMatch").html("Password matches!");

               });
           </script>
       </div>

             <?php include_once("footer.php"); ?>

           </div>
      <script type="text/javascript">
             if ($(window).outerWidth() > 1199) {
                 $('nav.side-navbar').removeClass('shrink');
             }

             function myFunction() {
                 setTimeout(showPage, 150);
             }
             function showPage() {
               document.getElementById("loader").style.display = "none";
               document.getElementById("content").style.display = "block";
             }

             $("div.alert").delay(3000).slideUp(750);

             function confirmDelete() {
                 if (confirm("Are you sure want to delete?")) {
                     return true;
                 }
                 return false;
             }

             $("a#add-expense").click(function(e){
               e.preventDefault();
               $('#expense-modal').modal();
             });

             $("a#add-account").click(function(e){
               e.preventDefault();
               $('#account-modal').modal();
             });

             $("a#account-statement").click(function(e){
               e.preventDefault();
               $('#account-statement-modal').modal();
             });

             $("a#profitLoss-link").click(function(e){
               e.preventDefault();
               $("#profitLoss-report-form").submit();
             });

             $("a#report-link").click(function(e){
               e.preventDefault();
               $("#product-report-form").submit();
             });

             $("a#purchase-report-link").click(function(e){
               e.preventDefault();
               $("#purchase-report-form").submit();
             });

             $("a#sale-report-link").click(function(e){
               e.preventDefault();
               $("#sale-report-form").submit();
             });

             $("a#payment-report-link").click(function(e){
               e.preventDefault();
               $("#payment-report-form").submit();
             });

             $("a#warehouse-report-link").click(function(e){
               e.preventDefault();
               $('#warehouse-modal').modal();
             });

             $("a#user-report-link").click(function(e){
               e.preventDefault();
               $('#user-modal').modal();
             });

             $("a#customer-report-link").click(function(e){
               e.preventDefault();
               $('#customer-modal').modal();
             });

             $("a#supplier-report-link").click(function(e){
               e.preventDefault();
               $('#supplier-modal').modal();
             });

             $("a#due-report-link").click(function(e){
               e.preventDefault();
               $("#due-report-form").submit();
             });

             $(".daterangepicker-field").daterangepicker({
                 callback: function(startDate, endDate, period){
                   var start_date = startDate.format('YYYY-MM-DD');
                   var end_date = endDate.format('YYYY-MM-DD');
                   var title = start_date + ' To ' + end_date;
                   $(this).val(title);
                   $('#account-statement-modal input[name="start_date"]').val(start_date);
                   $('#account-statement-modal input[name="end_date"]').val(end_date);
                 }
             });

             $('.selectpicker').selectpicker({
                 style: 'btn-link',
             });
           </script>

</body>

</html>
