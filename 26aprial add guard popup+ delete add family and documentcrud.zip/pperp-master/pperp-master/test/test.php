<?php

echo date("Ymd");

 ?>
