<?php

 ?>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="images/Perfect Protection Shield.png">

  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="all,follow">
  <meta name="csrf-token" content="Xt6DcvPxsnWjvof7wzfPPxRdJCMelG5nVmqwnOpy">

  <!-- Bootstrap CSS-->
  <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="css/bootstrap-toggle.min.css" type="text/css">
  <link rel="stylesheet" href="css/bootstrap-datepicker.min.css" type="text/css">
  <link rel="stylesheet" href="css/jquery.timepicker.min.css" type="text/css">
  <link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css" type="text/css">
  <link rel="stylesheet" href="css/bootstrap-select.min.css" type="text/css">
  <!-- Font Awesome CSS-->
  <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
  <!-- Drip icon font-->
  <link rel="stylesheet" href="css/webfont.css" type="text/css">
  <!-- Google fonts - Roboto -->
  <link rel="stylesheet" href="css/css">
  <!-- jQuery Circle-->
  <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css" type="text/css">
  <!-- Custom Scrollbar-->
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css" type="text/css">
  <!-- virtual keybord stylesheet-->
  <link rel="stylesheet" href="css/keyboard.css" type="text/css">
  <!-- date range stylesheet-->
  <link rel="stylesheet" href="css/daterangepicker.min.css" type="text/css">
  <!-- table sorter stylesheet-->
  <link rel="stylesheet" type="text/css" href="css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" type="text/css" href="css/fixedHeader.bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.bootstrap.min.css">
  <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet" type="text/css">
  <link id="new-stylesheet" rel="stylesheet">
  <link rel="stylesheet" href="css/dropzone.css">
  <link rel="stylesheet" href="css/style.css">
  <!-- Tweaks for older IEs--><!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-datepicker.min.js"></script>
  <script type="text/javascript" src="js/jquery.timepicker.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js">
  </script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-toggle.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-select.min.js"></script>
  <script type="text/javascript" src="js/jquery.keyboard.js"></script>
  <script type="text/javascript" src="js/jquery.keyboard.extension-autocomplete.js"></script>
  <script type="text/javascript" src="js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
  <script type="text/javascript" src="js/jquery.cookie.js">
  </script>
  <script type="text/javascript" src="js/Chart.min.js"></script><style type="text/css">/* Chart.js */
 @-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style>
  <script type="text/javascript" src="js/jquery.validate.min.js"></script>
  <script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
  <script type="text/javascript" src="js/charts-custom.js"></script>
  <script type="text/javascript" src="js/front.js"></script>
  <script type="text/javascript" src="js/moment.min.js"></script>
  <script type="text/javascript" src="js/knockout-3.4.2.js"></script>
  <script type="text/javascript" src="js/daterangepicker.min.js"></script>
  <script type="text/javascript" src="js/tinymce.min.js"></script>
  <script type="text/javascript" src="js/dropzone.js"></script>

  <!-- table sorter js-->
  <script type="text/javascript" src="js/pdfmake.min.js"></script>
  <script type="text/javascript" src="js/vfs_fonts.js"></script>
  <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
  <script type="text/javascript" src="js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="js/buttons.bootstrap4.min.js"></script>
  <script type="text/javascript" src="js/buttons.colVis.min.js"></script>
  <script type="text/javascript" src="js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="js/buttons.print.min.js"></script>

  <script type="text/javascript" src="js/sum().js"></script>
  <script type="text/javascript" src="js/dataTables.checkboxes.min.js"></script>
  <script type="text/javascript" src="js/dataTables.fixedHeader.min.js"></script>
  <script type="text/javascript" src="js/dataTables.responsive.min.js"></script>
  <script type="text/javascript" src="js/responsive.bootstrap.min.js"></script>
  <!-- Custom stylesheet - for your changes-->
  <link rel="stylesheet" href="css/custom-default.css" type="text/css" id="custom-style">
