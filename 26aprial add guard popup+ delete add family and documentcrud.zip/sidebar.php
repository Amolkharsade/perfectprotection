<?php

?>

<!-- Side Navbar -->
<nav class="side-navbar mCustomScrollbar _mCS_1 mCS_no_scrollbar" style="top: 63px;">
  <div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: none;" tabindex="0">
    <div id="mCSB_1_container" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position: relative; top: 0px; left: 0px;" dir="ltr">
      <div class="side-navbar-wrapper">
        <!-- Sidebar Header    -->
        <!-- Sidebar Navigation Menus-->
        <div class="main-menu">
          <ul id="side-main-menu" class="side-menu list-unstyled">
            <li>
              <a href="home"> <i class="dripicons-meter"></i><span>Dashboard</span></a>
            </li>
            <li>
              <a href="#product" <?php if($page=='category'||$page=='products'||$page=='addproduct'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse" class="collapsed"><i class="dripicons-list"></i><span>Inventory</span><span></span>
              </a>
              <ul id="product" <?php if($page=='category'||$page=='products'||$page=='addproduct'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?> style="">
                <li id="category-menu" <?php if($page=='category'){ echo 'class="active"'; }?>><a href="category">Category</a></li>
                <li id="product-list-menu" <?php if($page=='products'){ echo 'class="active"'; }?>><a href="products">Product List</a></li>
                <li id="product-create-menu" <?php if($page=='addproduct'){ echo 'class="active"'; }?>><a href="addproduct">Add Product</a></li>
                <!-- <li id="printBarcode-menu"><a href="#/products/print_barcode">Print Barcode</a></li> -->
                <!-- <li id="stock-count-menu"><a href="#/stock-count">Stock Count</a></li> -->
                <!-- <li id="purchase-list-menu"><a href="#/purchases">Purchase List</a></li> -->
                <!-- <li id="purchase-create-menu"><a href="#/purchases/create">Add Purchase</a></li> -->
                <!-- <li id="purchase-import-menu"><a href="#/purchases/purchase_by_csv">Import Purchase By CSV</a></li> -->
              </ul>
            </li>
            <li>
              <a href="#expense" <?php if($page=='expense_categories'||$page=='expenses'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse"> <i class="dripicons-wallet"></i><span>Expense</span>
              </a>
              <ul id="expense" <?php if($page=='expense_categories'||$page=='expenses'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?>>
                <li id="exp-cat-menu" <?php if($page=='expense_categories'){ echo 'class="active"'; }?>><a href="expense_categories">Expense Category</a></li>
                <li id="exp-list-menu" <?php if($page=='expenses'){ echo 'class="active"'; }?>><a href="expenses">Expense List</a></li>
              </ul>
            </li>
            <li><a href="#company" <?php if($page=='company'||$page=='branch'||$page=='designation'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse"> <i class="dripicons-export"></i><span>Company</span></a>
              <ul id="company" <?php if($page=='company'||$page=='branch'||$page=='designation'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?>>
                <li id="company-list-menu" <?php if($page=='company'){ echo 'class="active"'; }?>><a href="company">Company List</a></li>
                <li id="branch-list-menu" <?php if($page=='branch'){ echo 'class="active"'; }?>><a href="branch">Branch List</a></li>
                <li id="designation-list-menu" <?php if($page=='designation'){ echo 'class="active"'; }?>><a href="designation">Designation</a></li>
              </ul>
            </li>
            <li><a href="#client" <?php if($page=='client'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse"> <i class="dripicons-user-group"></i><span>Client</span></a>
              <ul id="client" <?php if($page=='client'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?> style="">
                <li id="sale-list-menu" <?php if($page=='client'){ echo 'class="active"'; }?>><a href="client">Client Master</a></li>

              </ul>
            </li>
            <li><a href="#employee" <?php if($page=='staff'||$page=='guards'||$page=='cleaners'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse"> <i class="dripicons-user-group"></i><span>Employee</span></a>
              <ul id="employee" <?php if($page=='staff'||$page=='guards'||$page=='cleaners'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?> class="collapse list-unstyled ">
                <li id="staff" <?php if($page=='staff'){ echo 'class="active"'; }?>><a href="staff">Staff</a></li>
                <li id="gaurds" <?php if($page=='guards'){ echo 'class="active"'; }?>><a href="guards">Guards</a></li>
                <li id="gaurds" <?php if($page=='guards'){ echo 'class="active"'; }?>><a href="details">Add Guards</a></li>
                <li id="cleaners" <?php if($page=='cleaners'){ echo 'class="active"'; }?>><a  href="cleaners">Cleaners</a></li>
              </ul>
            </li>

            <li><a href="#crm" <?php if($page=='customerpage'||$page=='customergroup'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?>  data-toggle="collapse"> <i class="dripicons-archive"></i><span>CRM</span></a>
              <ul id="crm" <?php if($page=='customerpage'||$page=='customergroup'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?> >
                <li id="customers-menu" <?php if($page=='customerpage'){ echo 'class="active"'; }?> ><a href="customers">Customers</a></li>
                <li id="customer-group-menu" <?php if($page=='customergroup'){ echo 'class="active"'; }?>><a href="customers-group">Customer Group</a></li>
              </ul>
            </li>

            <li><a href="#quotation" <?php if($page=='quotations'||$page=='createquotation'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse"> <i class="dripicons-document"></i><span>Quotation</span><span></span></a>
              <ul id="quotation" <?php if($page=='quotations'||$page=='createquotation'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?>>
                <li id="quotation-list-menu" <?php if($page=='quotations'){ echo 'class="active"'; }?>><a href="quotations">Quotation List</a></li>
                <li id="quotation-create-menu" <?php if($page=='createquotation'){ echo 'class="active"'; }?>><a href="createquotation">Add Quotation</a></li>
              </ul>
            </li>
            <li class="">
              <a href="#account1" <?php if($page=='accounts'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse"> <i class="dripicons-briefcase"></i><span>Finance</span></a>
              <ul id="account1" <?php if($page=='accounts'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?> >
                <li id="account-list-menu" <?php if($page=='accounts'){ echo 'class="active"'; }?> ><a href="accounts">Account List</a></li>
                <li id="money-transfer-menu"><a href="#/money-transfers">Money Transfer</a></li>
                <!-- <li id="balance-sheet-menu"><a href="#/accounts/balancesheet">Balance Sheet</a></li>
                <li id="account-statement-menu"><a id="account-statement" href="#/">Account Statement</a></li> -->
              </ul>
            </li>
            <li class=""><a href="#hrm" aria-expanded="false" data-toggle="collapse"> <i class="dripicons-user-group"></i><span>HRM</span></a>
              <ul id="hrm" class="collapse list-unstyled ">
                <!-- <li id="dept-menu"><a href="#/departments">Department</a></li> -->
                <!-- <li id="employee-menu"><a href="#/employees">Employee</a></li> -->
                <li id="attendance-menu"><a href="#/attendance">Attendance</a></li>
                <li id="payroll-menu"><a href="#/payroll">Payroll</a></li>
                <li id="holiday-menu"><a href="#/holidays">Holiday</a></li>
              </ul>
            </li>
            <li><a href="#people" <?php if($page=='user'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse"> <i class="dripicons-user"></i><span>People</span></a>
              <ul id="people" <?php if($page=='user'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?>>
                <li id="user-list-menu" <?php if($page=='user'){ echo 'class="active"'; }?>><a href="users">User List</a></li>
                <li id="user-create-menu" <?php if($page=='user'){ echo 'class="active"'; }?>><a href="adduser">Add User</a></li>
                <!-- <li id="supplier-list-menu"><a href="#/supplier">Supplier List</a></li>
                <li id="supplier-create-menu"><a href="#/supplier/create">Add Supplier</a></li> -->
              </ul>
            </li>
            <li><a href="#report" aria-expanded="false" data-toggle="collapse"> <i class="dripicons-document-remove"></i><span>Reports</span></a>
              <ul id="report" class="collapse list-unstyled ">
                <li id="profit-loss-report-menu">
                  <form method="POST" action="#/report/profit_loss" accept-charset="UTF-8" id="profitLoss-report-form"><input name="_token" type="hidden" value="Xt6DcvPxsnWjvof7wzfPPxRdJCMelG5nVmqwnOpy">
                  <input type="hidden" name="start_date" value="2021-03-01" />
                  <input type="hidden" name="end_date" value="2021-03-11" />
                  <a id="profitLoss-link" href="">Summary Report</a>
                  </form>
                </li>
                <li id="product-report-menu">
                  <form method="POST" action="#/report/product_report" accept-charset="UTF-8" id="product-report-form"><input name="_token" type="hidden" value="Xt6DcvPxsnWjvof7wzfPPxRdJCMelG5nVmqwnOpy">
                  <input type="hidden" name="start_date" value="1988-04-18" />
                  <input type="hidden" name="end_date" value="2021-03-11" />
                  <input type="hidden" name="warehouse_id" value="0" />
                  <a id="report-link" href="">Product Report</a>
                  </form>
                </li>

                <li id="payment-report-menu">
                  <form method="POST" action="#/report/payment_report_by_date" accept-charset="UTF-8" id="payment-report-form"><input name="_token" type="hidden" value="Xt6DcvPxsnWjvof7wzfPPxRdJCMelG5nVmqwnOpy">
                  <input type="hidden" name="start_date" value="1988-04-18">
                  <input type="hidden" name="end_date" value="2021-03-11">
                  <a id="payment-report-link" href="#/">Payment Report</a>
                  </form>
                </li>
                <li id="purchase-report-menu">
                  <form method="POST" action="#/report/purchase" accept-charset="UTF-8" id="purchase-report-form"><input name="_token" type="hidden" value="Xt6DcvPxsnWjvof7wzfPPxRdJCMelG5nVmqwnOpy">
                  <input type="hidden" name="start_date" value="1988-04-18">
                  <input type="hidden" name="end_date" value="2021-03-11">
                  <input type="hidden" name="warehouse_id" value="0">
                  <a id="purchase-report-link" href="#/">Purchase Report</a>
                  </form>
                </li>
                <li id="user-report-menu">
                  <a id="user-report-link" href="#/">User Report</a>
                </li>
                <li id="customer-report-menu">
                  <a id="customer-report-link" href="#/">Client Report</a>
                </li>
                <!-- <li id="supplier-report-menu">
                  <a id="supplier-report-link" href="#/">Supplier Report</a>
                </li> -->

              </ul>
            </li>
            <li><a href="#setting" <?php if($page=='role'||$page=='document'||$page=='tax'||$page=='userprofile'){ echo 'aria-expanded="true"'; }else{ echo 'aria-expanded="false"'; } ?> data-toggle="collapse" class="collapsed"> <i class="dripicons-gear"></i><span>Settings</span></a>
              <ul id="setting" <?php if($page=='role'||$page=='document'||$page=='tax'||$page=='userprofile'){ echo 'class="list-unstyled show"'; }else{ echo 'class="list-unstyled collapse"'; } ?> style="">
                      <li id="role-menu" <?php if($page=='role'){ echo 'class="active"'; }?>><a href="role">Role Permission</a></li>
                      <li id="document-menu" <?php if($page=='document'){ echo 'class="active"'; }?>><a href="document">Document</a></li>
                      <!-- <li id="brand-menu"><a href="#/brand">Brand</a></li> -->
                      <li id="unit-menu"><a href="#/unit">Unit</a></li>
                      <li id="tax-menu" <?php if($page=='tax'){ echo 'class="active"'; }?>><a href="tax">Tax</a></li>
                      <li id="user-menu" <?php if($page=='userprofile'){ echo 'class="active"'; }?>><a href="userprofile">User Profile</a></li>
                      <li id="general-setting-menu"><a href="#/setting/general_setting">General Setting</a></li>
                      <!-- <li id="mail-setting-menu"><a href="#/setting/mail_setting">Mail Setting</a></li> -->
                      <!-- <li id="hrm-setting-menu"><a href="#/setting/hrm_setting"> HRM Setting</a></li> -->
              </ul>
            </li>



            <li>
              <a href="#"><span>Version 1.1.0</span></a>
            </li>

          </ul>
        </div>
      </div>
    </div>
  </div>
</nav>
