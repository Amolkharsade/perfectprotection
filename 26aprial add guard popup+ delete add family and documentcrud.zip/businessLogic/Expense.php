<?php
require_once("Database.php");

class Expense
{
	// database connection and table name
    private $conn;
    private $table_name = "expenses";

    // property declaration
    private $id;
    private $reference_no;
    private $expense_category_id;
    private $account_id;
    private $user_id;
    private $amount;
    private $note;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getExpenseId()
    {
        return $this->id;
    }
    public function setExpenseId($id)
    {
        $this->id = $id;
    }
    public function getReferenceNo()
    {
        return $this->reference_no;
    }
    public function setReferenceNo($reference_no)
    {
        $this->reference_no = $reference_no;
    }
    public function getExpenseCategory()
    {
        return $this->expense_category_id;
    }
    public function setExpenseCategory($categoryId)
    {
        $this->expense_category_id = $categoryId;
    }
    public function getAccountId()
    {
        return $this->account_id;
    }
    public function setAccountId($account_id)
    {
        $this->account_id = $account_id;
    }
    public function getUserId()
    {
        return $this->user_id;
    }
    public function setUserId($userid)
    {
        $this->user_id = $userid;
    }
    public function getAmount()
    {
        return $this->amount;
    }
    public function setAmount($amount)
    {
        $this->amount = $amount;
    }
    public function getNote()
    {
        return $this->note;
    }
    public function setNote($note)
    {
        $this->note = $note;
    }
    public function getCreatedAt()
    {
        return $this->created_at;
    }
    public function setCreatedAt($createdat)
    {
        $this->created_at = $createdat;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }



    public function getExpenseByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setExpenseId($row['id']);
        $this->setReferenceNo($row['reference_no']);
        $this->setExpenseCategory($row['expense_category_id']);
        $this->setAccountId($row['account_id']);
        $this->setUserId($row['user_id']);
        $this->setAmount($row['amount']);
        $this->setNote($row['note']);
    }

	function readAllExpense()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      reference_no = :reference_no,
					            expense_category_id  = :expense_category_id,
                      account_id =:account_id,
                      user_id =:user_id,
                      amount =:amount,
                      note =:note
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->reference_no=htmlspecialchars(strip_tags($this->getReferenceNo()));
        $this->expense_category_id=htmlspecialchars(strip_tags($this->getExpenseCategory()));
        $this->account_id=htmlspecialchars(strip_tags($this->getAccountId()));
        $this->user_id=htmlspecialchars(strip_tags($this->getUserId()));
        $this->amount=htmlspecialchars(strip_tags($this->getAmount()));
        $this->note=htmlspecialchars(strip_tags($this->getNote()));

        // bind parameters
        $stmt->bindParam(':reference_no', $this->reference_no);
        $stmt->bindParam(':expense_category_id', $this->expense_category_id);
        $stmt->bindParam(':account_id', $this->account_id);
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':amount', $this->amount);
        $stmt->bindParam(':note', $this->note);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      expense_category_id  = :expense_category_id,
                      account_id =:account_id,
                      user_id =:user_id,
                      amount =:amount,
                      note =:note,
                      updated_at =:updateTimeStamp
                WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->expense_category_id=htmlspecialchars(strip_tags($this->getExpenseCategory()));
          $this->account_id=htmlspecialchars(strip_tags($this->getAccountId()));
          $this->user_id=htmlspecialchars(strip_tags($this->getUserId()));
          $this->amount=htmlspecialchars(strip_tags($this->getAmount()));
          $this->note=htmlspecialchars(strip_tags($this->getNote()));

          // bind parameters
          $stmt->bindParam(':expense_category_id', $this->expense_category_id);
          $stmt->bindParam(':account_id', $this->account_id);
          $stmt->bindParam(':user_id', $this->user_id);
          $stmt->bindParam(':amount', $this->amount);
          $stmt->bindParam(':note', $this->note);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Company
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
