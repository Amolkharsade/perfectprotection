<?php
require_once("Database.php");

class Document
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_document";

    // property declaration
    private $fd_document_id;
    private $fd_document;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getDocumentId()
    {
        return $this->fd_document_id;
    }
    public function setDocumentId($documentid)
    {
        $this->fd_document_id = $documentid;
    }
    public function getDocument()
    {
        return $this->fd_document;
    }
    public function setDocument($document)
    {
        $this->fd_document = $document;
    }

        public function getCreatedAt()
        {
            return $this->created_at;
        }
        public function setCreatedAt($created_at)
        {
            $this->created_at = $created_at;
        }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getDocumentVal($id)
    {

      if($this->validateId($id))
      {
        $query = "SELECT * FROM " . $this->table_name . " WHERE fd_document_id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['fd_document'];
      }
      else {
        return "";
      }
    }
    public function validateId($id)
    {
      $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_document_id";
      $stmt = $this->conn->prepare( $query );
      $stmt->execute();
      $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);

      foreach($rowvalues as $rowVal)
      {
        if($rowVal['fd_document_id']==$id)
        {
          return true;
        }
      }
      return false;

    }

    public function getDocumentByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE fd_document_id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setDocumentId($row['fd_document_id']);
        $this->setDocument($row['fd_document']);

    }

	function readAllDocument()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_document";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      fd_document = :document
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->fd_document=htmlspecialchars(strip_tags($this->getDocument()));

        // bind parameters
        $stmt->bindParam(':document', $this->fd_document);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      fd_document = :document,
                      updated_at =:updateTimeStamp
                WHERE
                      fd_document_id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->fd_document=htmlspecialchars(strip_tags($this->getDocument()));

          // bind parameters
          $stmt->bindParam(':document', $this->fd_document);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->fd_document_id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Company
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE fd_document_id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->fd_document_id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
