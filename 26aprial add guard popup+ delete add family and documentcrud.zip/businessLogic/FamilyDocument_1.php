<?php
require_once("Database.php");

class FamilyDocument
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_family_document";

    // property declaration
    private $fd_doc_id;
    private $fd_doc_name;
    private $fd_doc_description;
    private $fd_doc_authority;
    private $fd_doc_issuedate;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getDocumentId()
    {
        return $this->fd_doc_id;
    }
    public function setDocumentId($fd_doc_id)
    {
        $this->fd_doc_id = $fd_doc_id;
    }
    public function getDocument()
    {
        return $this->fd_doc_name;
    }
    public function setDocument($document)
    {
        $this->fd_doc_name = $document;
    }
    public function getDocumentDescription()
    {
        return $this->fd_doc_description;
    }
    public function setDocumentDescription($document_description)
    {
        $this->fd_doc_description = $document_description;
    }
    public function getAuthority()
    {
        return $this->fd_doc_authority;
    }
    public function setAuthority($document_authority)
    {
        $this->fd_doc_authority = $document_authority;
    }
    public function getDocumentIssudate()
    {
        return $this->fd_doc_issuedate;
    }
    public function setDocumentIssudate($document_issudate)
    {
        $this->fd_doc_issuedate = $document_issudate;
    }

        public function getCreatedAt()
        {
            return $this->created_at;
        }
        public function setCreatedAt($created_at)
        {
            $this->created_at = $created_at;
        }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getDocumentVal($id)
    {

      if($this->validateId($id))
      {
        $query = "SELECT * FROM " . $this->table_name . " WHERE fd_doc_id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['fd_doc_name'];
      }
      else {
        return "";
      }
    }
    public function validateId($id)
    {
      $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_doc_id";
      $stmt = $this->conn->prepare( $query );
      $stmt->execute();
      $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);

      foreach($rowvalues as $rowVal)
      {
        if($rowVal['fd_doc_id']==$id)
        {
          return true;
        }
      }
      return false;

    }

    public function getDocumentByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE fd_doc_id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setDocumentId($row['fd_doc_id']);
        $this->setDocument($row['fd_doc_name']);
        $this->setDocumentDescription($row['fd_doc_description']);
        $this->setAuthority($row['fd_doc_authority']);
        $this->setDocumentIssudate($row['fd_doc_issuedate']);
    }

	function readAllDocument()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_doc_id";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create1(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      fd_doc_name = :document,fd_doc_description =:document_description,
                      fd_doc_authority = :document_authority,fd_doc_issuedate = :document_issudate
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->fd_document=htmlspecialchars(strip_tags($this->getDocument()));
        $this->fd_doc_description=htmlspecialchars(strip_tags($this->getDocumentDescription()));
        $this->fd_doc_authority=htmlspecialchars(strip_tags($this->getAuthority()));
        $this->fd_doc_issuedate=htmlspecialchars(strip_tags($this->getDocumentIssudate()));
        // bind parameters
        $stmt->bindParam(':document', $this->fd_document);
        $stmt->bindParam(':document_description', $this->fd_doc_description);
        $stmt->bindParam(':document_authority', $this->fd_doc_authority);
        $stmt->bindParam(':document_issudate', $this->fd_doc_issuedate);
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      fd_doc_name = :document

                WHERE
                      fd_doc_id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->fd_doc_name=htmlspecialchars(strip_tags($this->getDocument()));

          // bind parameters
          $stmt->bindParam(':document', $this->fd_doc_name);

          //date_default_timezone_set("Asia/Kolkata");
        //  $this->updated_at = date('Y-m-d H:i:s');
        //  $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->fd_doc_id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Company
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE fd_doc_id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->fd_doc_id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
