<?php
require_once("Database.php");

class CustomerGroup
{
	// database connection and table name
    private $conn;
    private $table_name = "customer_groups";

    // property declaration
    private $id;
    private $name;
    private $summary;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
        $this->name = $name;
    }
    public function getSummary()
    {
        return $this->summary;
    }
    public function setSummary($summary)
    {
        $this->summary = $summary;
    }
    public function getCreatedAt()
    {
        return $this->created_at;
    }
    public function setCreatedAt($createdat)
    {
        $this->created_at = $createdat;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getCustomerGroup($id)
    {

      if($this->validateId($id))
      {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['name'];
      }
      else {
        return "";
      }
    }
    public function validateId($id)
    {
      $query = "SELECT * FROM " . $this->table_name . " ORDER BY id";
      $stmt = $this->conn->prepare( $query );
      $stmt->execute();
      $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);

      foreach($rowvalues as $rowVal)
      {
        if($rowVal['id']==$id)
        {
          return true;
        }
      }
      return false;

    }

    public function getCustomerGroupByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setId($row['id']);
        $this->setName($row['name']);
        $this->setSummary($row['summary']);
    }

	function readAllCustomerGroup()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      name = :name,
					            summary  = :summary
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->name=htmlspecialchars(strip_tags($this->getName()));
        $this->summary=htmlspecialchars(strip_tags($this->getSummary()));

        // bind parameters
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':summary', $this->summary);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      name=:name,
                      summary=:summary,
                      updated_at =:updateTimeStamp
                WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->name=htmlspecialchars(strip_tags($this->getName()));
          $this->summary=htmlspecialchars(strip_tags($this->getSummary()));

          // bind parameters
          $stmt->bindParam(':name', $this->name);
          $stmt->bindParam(':summary', $this->summary);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the user
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";

  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}

}
?>
