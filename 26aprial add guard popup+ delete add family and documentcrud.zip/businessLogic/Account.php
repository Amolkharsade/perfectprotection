<?php
require_once("Database.php");

class Account
{
	// database connection and table name
    private $conn;
    private $table_name = "accounts";

    // property declaration
    private $id;
    private $account_no;
    private $name;
    private $initial_balance;
    private $total_balance;
    private $note;
    private $is_default;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function getAccountNo()
    {
        return $this->account_no;
    }
    public function setAccountNo($account_no)
    {
        $this->account_no = $account_no;
    }
    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
        $this->name = $name;
    }
    public function getInitialBalance()
    {
        return $this->initial_balance;
    }
    public function setInitialBalance($initial_balance)
    {
        $this->initial_balance = $initial_balance;
    }
    public function getTotalBalance()
    {
        return $this->total_balance;
    }
    public function setTotalBalance($total_balance)
    {
        $this->total_balance = $total_balance;
    }
    public function getNote()
    {
        return $this->note;
    }
    public function setNote($note)
    {
        $this->note = $note;
    }
    public function getIsDefault()
    {
        return $this->is_default;
    }
    public function setIsDefault($is_default)
    {
        $this->is_default = $is_default;
    }
    public function getCreatedAt()
    {
        return $this->created_at;
    }
    public function setCreatedAt($createdat)
    {
        $this->created_at = $createdat;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }



    public function getAccountByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setId($row['id']);
        $this->setAccountNo($row['account_no']);
        $this->setName($row['name']);
        $this->setInitialBalance($row['initial_balance']);
        $this->setTotalBalance($row['total_balance']);
        $this->setNote($row['note']);
        $this->setIsDefault($row['is_default']);
    }

	function readAllAccounts()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      account_no =:account_no,
					            name  = :name,
                      initial_balance =:initial_balance,
                      total_balance =:total_balance,
                      note =:note
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->account_no=htmlspecialchars(strip_tags($this->getAccountNo()));
        $this->name=htmlspecialchars(strip_tags($this->getName()));
        $this->initial_balance=htmlspecialchars(strip_tags($this->getInitialBalance()));
        $this->total_balance=htmlspecialchars(strip_tags($this->getInitialBalance()));
        $this->note=htmlspecialchars(strip_tags($this->getNote()));

        // bind parameters
        $stmt->bindParam(':account_no', $this->account_no);
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':initial_balance', $this->initial_balance);
        $stmt->bindParam(':total_balance', $this->total_balance);
        $stmt->bindParam(':note', $this->note);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      account_no =:account_no,
                      name  = :name,
                      initial_balance =:initial_balance,
                      total_balance =:total_balance,
                      note =:note,
                      updated_at =:updateTimeStamp
                WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->account_no=htmlspecialchars(strip_tags($this->getAccountNo()));
          $this->name=htmlspecialchars(strip_tags($this->getName()));
          $this->initial_balance=htmlspecialchars(strip_tags($this->getInitialBalance()));
          $this->total_balance=htmlspecialchars(strip_tags($this->getInitialBalance()));
          $this->note=htmlspecialchars(strip_tags($this->getNote()));

          // bind parameters
          $stmt->bindParam(':account_no', $this->account_no);
          $stmt->bindParam(':name', $this->name);
          $stmt->bindParam(':initial_balance', $this->initial_balance);
          $stmt->bindParam(':total_balance', $this->total_balance);
          $stmt->bindParam(':note', $this->note);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Account
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
