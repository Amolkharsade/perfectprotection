<?php
require_once("Database.php");

class Customer
{
	// database connection and table name
    private $conn;
    private $table_name = "customers";

    // property declaration
    private $id;
    private $customer_group_id;
    private $name;
    private $company_name;
    private $email;
    private $phone_number;
    private $address;
    private $city;
    private $state;
    private $postal_code;
    private $country;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function getCustomerGroupId()
    {
        return $this->customer_group_id;
    }
    public function setCustomerGroupId($customer_group_id)
    {
      $this->customer_group_id  = $customer_group_id;
    }
    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
        $this->name = $name;
    }
    public function getCompanyName()
    {
        return $this->company_name;
    }
    public function setCompanyName($company_name)
    {
        $this->company_name = $company_name;
    }
    public function getEmail()
    {
        return $this->email;
    }
    public function setEmail($email)
    {
        $this->email = $email;
    }
    public function getPhoneNumber()
    {
        return $this->phone_number;
    }
    public function setPhoneNumber($phone_number)
    {
        $this->phone_number = $phone_number;
    }
    public function getAddress()
    {
        return $this->address;
    }
    public function setAddress($address)
    {
        $this->address = $address;
    }
    public function getCity()
    {
        return $this->city;
    }
    public function setCity($city)
    {
        $this->city = $city;
    }
    public function getState()
    {
        return $this->state;
    }
    public function setState($state)
    {
        $this->state = $state;
    }
    public function getPostalCode()
    {
        return $this->postal_code;
    }
    public function setPostalCode($postalCode)
    {
        $this->postal_code = $postalCode;
    }
    public function getCountry()
    {
        return $this->country;
    }
    public function setCountry($country)
    {
        $this->country = $country;
    }
    public function getCreatedAt()
    {
        return $this->created_at;
    }
    public function setCreatedAt($createdat)
    {
        $this->created_at = $createdat;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    //
    // public function getCustomerGroup($id)
    // {
    //
    //   if($this->validatId($id))
    //   {
    //     $query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
    //     $stmt = $this->conn->prepare( $query );
    //     $stmt->bindParam(1, $id);
    //     $stmt->execute();
    //     $row = $stmt->fetch(PDO::FETCH_ASSOC);
    //     return $row['name'];
    //   }
    //   else {
    //     return "";
    //   }
    // }
    // public function validateId($id)
    // {
    //   $query = "SELECT * FROM " . $this->table_name . " ORDER BY id";
    //   $stmt = $this->conn->prepare( $query );
    //   $stmt->execute();
    //   $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //
    //   foreach($rowvalues as $rowVal)
    //   {
    //     if($rowVal['id']==$id)
    //     {
    //       return true;
    //     }
    //   }
    //   return false;
    //
    // }

    public function getCustomerByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setId($row['id']);
        $this->setCustomerGroupId($row['customer_group_id']);
        $this->setName($row['name']);
        $this->setCompanyName($row['company_name']);
        $this->setEmail($row['email']);
        $this->setPhoneNumber($row['phone_number']);
        $this->setAddress($row['address']);
        $this->setCity($row['city']);
        $this->setState($row['state']);
        $this->setPostalCode($row['postal_code']);
        $this->setCountry($row['country']);
    }

	function readAllCustomers()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      name = :name,
					            customer_group_id  = :customergroupid,
                      company_name =:companyname,
                      email =:email,
                      phone_number =:phonenumber,
                      address =:address,
                      city =:city,
                      state =:state,
                      postal_code =:postalcode,
                      country =:country
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->name=htmlspecialchars(strip_tags($this->getName()));
        $this->customer_group_id=htmlspecialchars(strip_tags($this->getCustomerGroupId()));
        $this->company_name=htmlspecialchars(strip_tags($this->getCompanyName()));
        $this->email=htmlspecialchars(strip_tags($this->getEmail()));
        $this->phone_number=htmlspecialchars(strip_tags($this->getPhoneNumber()));
        $this->address=htmlspecialchars(strip_tags($this->getAddress()));
        $this->city=htmlspecialchars(strip_tags($this->getCity()));
        $this->state=htmlspecialchars(strip_tags($this->getState()));
        $this->postal_code=htmlspecialchars(strip_tags($this->getPostalCode()));
        $this->country=htmlspecialchars(strip_tags($this->getCountry()));

        // bind parameters
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':customergroupid', $this->customer_group_id);
        $stmt->bindParam(':companyname', $this->company_name);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phonenumber', $this->phone_number);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':city', $this->city);
        $stmt->bindParam(':state', $this->state);
        $stmt->bindParam(':postalcode', $this->postal_code);
        $stmt->bindParam(':country', $this->country);


        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      name = :name,
                      customer_group_id  = :customergroupid,
                      company_name =:companyname,
                      email =:email,
                      phone_number =:phonenumber,
                      address =:address,
                      city =:city,
                      state =:state,
                      postal_code =:postalcode,
                      country =:country,
                      updated_at =:updateTimeStamp
                WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->name=htmlspecialchars(strip_tags($this->getName()));
          $this->customer_group_id=htmlspecialchars(strip_tags($this->getCustomerGroupId()));
          $this->company_name=htmlspecialchars(strip_tags($this->getCompanyName()));
          $this->email=htmlspecialchars(strip_tags($this->getEmail()));
          $this->phone_number=htmlspecialchars(strip_tags($this->getPhoneNumber()));
          $this->address=htmlspecialchars(strip_tags($this->getAddress()));
          $this->city=htmlspecialchars(strip_tags($this->getCity()));
          $this->state=htmlspecialchars(strip_tags($this->getState()));
          $this->postal_code=htmlspecialchars(strip_tags($this->getPostalCode()));
          $this->country=htmlspecialchars(strip_tags($this->getCountry()));

          // bind parameters
          $stmt->bindParam(':name', $this->name);
          $stmt->bindParam(':customergroupid', $this->customer_group_id);
          $stmt->bindParam(':companyname', $this->company_name);
          $stmt->bindParam(':email', $this->email);
          $stmt->bindParam(':phonenumber', $this->phone_number);
          $stmt->bindParam(':address', $this->address);
          $stmt->bindParam(':city', $this->city);
          $stmt->bindParam(':state', $this->state);
          $stmt->bindParam(':postalcode', $this->postal_code);
          $stmt->bindParam(':country', $this->country);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the customer
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";

  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}

}
?>
