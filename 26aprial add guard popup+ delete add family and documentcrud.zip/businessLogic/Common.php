<?php
require_once("Database.php");
require_once("Settings.php");
require_once("Project.php");


class Common
{
  public function generateString($length )
  {
          $chars = '0123456789';

          $str = '';
          $max = strlen($chars) - 1;

          for ($i=0; $i < $length; $i++)
            $str .= $chars[rand(0, $max)];
          return $str;
  }

  public function generateOTP($length )
  {
          $chars =  '0123456789';

          $str = '';
          $max = strlen($chars) - 1;

          for ($i=0; $i < $length; $i++)
            $str .= $chars[rand(0, $max)];

          // $timevalue= date("YmdHis").gettimeofday()['usec'];

          return $str;
  }




}
