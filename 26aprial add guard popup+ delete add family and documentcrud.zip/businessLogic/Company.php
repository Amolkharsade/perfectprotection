<?php
require_once("Database.php");

class Company
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_company";

    // property declaration
    private $fd_company_id;
    private $fd_company_name;
    private $fd_address;
    private $fd_city;
    private $fd_state;
    private $fd_country;
    private $fd_pincode;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getCompanyId()
    {
        return $this->fd_company_id;
    }
    public function setCompanyId($company_id)
    {
        $this->fd_company_id = $company_id;
    }
    public function getCompanyName()
    {
        return $this->fd_company_name;
    }
    public function setCompanyName($companyname)
    {
        $this->fd_company_name = $companyname;
    }
    public function getAddress()
    {
        return $this->fd_address;
    }
    public function setAddress($address)
    {
        $this->fd_address = $address;
    }
    public function getCity()
    {
        return $this->fd_city;
    }
    public function setCity($city)
    {
        $this->fd_city = $city;
    }
    public function getState()
    {
        return $this->fd_state;
    }
    public function setState($state)
    {
        $this->fd_state = $state;
    }
    public function getCountry()
    {
        return $this->fd_country;
    }
    public function setCountry($country)
    {
        $this->fd_country = $country;
    }
    public function getPincode()
    {
        return $this->fd_pincode;
    }
    public function setPincode($pincode)
    {
        $this->fd_pincode = $pincode;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getCompany($id)
    {

      if($this->validateId($id))
      {
        $query = "SELECT * FROM " . $this->table_name . " WHERE fd_company_id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['fd_company_name'];
      }
      else {
        return "";
      }
    }
    public function validateId($id)
    {
      $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_company_id";
      $stmt = $this->conn->prepare( $query );
      $stmt->execute();
      $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);

      foreach($rowvalues as $rowVal)
      {
        if($rowVal['fd_company_id']==$id)
        {
          return true;
        }
      }
      return false;

    }

    public function getCompanyByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE fd_company_id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setCompanyId($row['fd_company_id']);
        $this->setCompanyName($row['fd_company_name']);
        $this->setAddress($row['fd_address']);
        $this->setCity($row['fd_city']);
        $this->setState($row['fd_state']);
        $this->setCountry($row['fd_country']);
        $this->setPincode($row['fd_pincode']);
    }

	function readAllCompany()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_company_id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      fd_company_name = :companyname,
					            fd_address  = :address,
                      fd_city =:city,
                      fd_state =:state,
                      fd_country =:country,
                      fd_pincode =:pincode
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->fd_company_name=htmlspecialchars(strip_tags($this->getCompanyName()));
        $this->fd_address=htmlspecialchars(strip_tags($this->getAddress()));
        $this->fd_city=htmlspecialchars(strip_tags($this->getCity()));
        $this->fd_state=htmlspecialchars(strip_tags($this->getState()));
        $this->fd_country=htmlspecialchars(strip_tags($this->getCountry()));
        $this->fd_pincode=htmlspecialchars(strip_tags($this->getPincode()));

        // bind parameters
        $stmt->bindParam(':companyname', $this->fd_company_name);
        $stmt->bindParam(':address', $this->fd_address);
        $stmt->bindParam(':city', $this->fd_city);
        $stmt->bindParam(':state', $this->fd_state);
        $stmt->bindParam(':country', $this->fd_country);
        $stmt->bindParam(':pincode', $this->fd_pincode);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      fd_company_name = :companyname,
                      fd_address  = :address,
                      fd_city =:city,
                      fd_state =:state,
                      fd_country =:country,
                      fd_pincode =:pincode,
                      updated_at =:updateTimeStamp
                WHERE
                      fd_company_id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->fd_company_name=htmlspecialchars(strip_tags($this->getCompanyName()));
          $this->fd_address=htmlspecialchars(strip_tags($this->getAddress()));
          $this->fd_city=htmlspecialchars(strip_tags($this->getCity()));
          $this->fd_state=htmlspecialchars(strip_tags($this->getState()));
          $this->fd_country=htmlspecialchars(strip_tags($this->getCountry()));
          $this->fd_pincode=htmlspecialchars(strip_tags($this->getPincode()));

          // bind parameters
          $stmt->bindParam(':companyname', $this->fd_company_name);
          $stmt->bindParam(':address', $this->fd_address);
          $stmt->bindParam(':city', $this->fd_city);
          $stmt->bindParam(':state', $this->fd_state);
          $stmt->bindParam(':country', $this->fd_country);
          $stmt->bindParam(':pincode', $this->fd_pincode);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->fd_company_id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Company
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE fd_company_id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->fd_company_id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
