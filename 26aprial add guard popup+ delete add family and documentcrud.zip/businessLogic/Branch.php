<?php
require_once("Database.php");

class Branch
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_branch";

    // property declaration
    private $fd_branch_id;

    private $fd_branch_name;
    private $fd_company_id;
    private $fd_address;
    private $fd_address1;
    private $fd_address2;

    private $fd_city;
    private $fd_state;
    private $fd_country;
    private $fd_pincode;
    private $fd_stdcode;

    private $fd_phone1;
    private $fd_phone2;
    private $fd_fax;
    private $fd_cpname;
    private $fd_mobile1;

    private $fd_mobile2;
    private $fd_email1;
    private $fd_email2;
    private $fd_url;
    private $fd_panno;

    private $fd_staxno;
    private $fd_pfcode;
    private $fd_esicode;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getBranchId()
    {
        return $this->fd_branch_id;
    }
    public function setBranchId($branch_id)
    {
        $this->fd_branch_id = $branch_id;
    }
    public function getBranchName()
    {
        return $this->fd_branch_name;
    }
    public function setBranchName($branchname)
    {
        $this->fd_branch_name = $branchname;
    }
    public function getCompanyId()
    {
        return $this->fd_company_id;
    }
    public function setCompanyId($company_id)
    {
        $this->fd_company_id = $company_id;
    }

    public function getAddress()
    {
        return $this->fd_address;
    }
    public function setAddress($address)
    {
        $this->fd_address = $address;
    }
    public function getAddress1()
    {
        return $this->fd_address1;
    }
    public function setAddress1($address1)
    {
        $this->fd_address1 = $address1;
    }
    public function getAddress2()
    {
        return $this->fd_address2;
    }
    public function setAddress2($address)
    {
        $this->fd_address2 = $address;
    }
    public function getCity()
    {
        return $this->fd_city;
    }
    public function setCity($city)
    {
        $this->fd_city = $city;
    }
    public function getState()
    {
        return $this->fd_state;
    }
    public function setState($state)
    {
        $this->fd_state = $state;
    }
    public function getCountry()
    {
        return $this->fd_country;
    }
    public function setCountry($country)
    {
        $this->fd_country = $country;
    }
    public function getPincode()
    {
        return $this->fd_pincode;
    }
    public function setPincode($pincode)
    {
        $this->fd_pincode = $pincode;
    }
    public function getStdcode()
    {
        return $this->fd_stdcode;
    }
    public function setStdcode($stdcode)
    {
        $this->fd_stdcode = $stdcode;
    }
    public function getPhone1()
    {
        return $this->fd_phone1;
    }
    public function setPhone1($phone)
    {
        $this->fd_phone1 = $phone;
    }
    public function getPhone2()
    {
        return $this->fd_phone2;
    }
    public function setPhone2($phone)
    {
        $this->fd_phone2 = $phone;
    }
    public function getFax()
    {
        return $this->fd_fax;
    }
    public function setFax($fax)
    {
        $this->fd_fax = $fax;
    }
    public function getCPName()
    {
        return $this->fd_cpname;
    }
    public function setCPName($cpname)
    {
        $this->fd_cpname = $cpname;
    }
    public function getMobile1()
    {
        return $this->fd_mobile1;
    }
    public function setMobile1($mobile)
    {
        $this->fd_mobile1 = $mobile;
    }
    public function getMobile2()
    {
        return $this->fd_mobile2;
    }
    public function setMobile2($mobile)
    {
        $this->fd_mobile2 = $mobile;
    }
    public function getEmail1()
    {
        return $this->fd_email1;
    }
    public function setEmail1($email)
    {
        $this->fd_email1 = $email;
    }
    public function getEmail2()
    {
        return $this->fd_email2;
    }
    public function setEmail2($email)
    {
        $this->fd_email2 = $email;
    }
    public function getUrl()
    {
        return $this->fd_url;
    }
    public function setUrl($url)
    {
        $this->fd_url = $url;
    }
    public function getPanNO()
    {
        return $this->fd_panno;
    }
    public function setPanNo($panno)
    {
        $this->fd_panno = $panno;
    }

    public function getSTaxNO()
    {
        return $this->fd_staxno;
    }
    public function setSTaxNo($staxno)
    {
        $this->fd_staxno = $staxno;
    }
    public function getPFCode()
    {
        return $this->fd_pfcode;
    }
    public function setPFCode($pfcode)
    {
        $this->fd_pfcode = $pfcode;
    }
    public function getESICode()
    {
        return $this->fd_esicode;
    }
    public function setESICode($esicode)
    {
        $this->fd_esicode =$esicode;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getBranch($id)
    {

      if($this->validateId($id))
      {
        $query = "SELECT * FROM " . $this->table_name . " WHERE fd_branch_id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['fd_branch_name'];
      }
      else {
        return "";
      }
    }
    public function validateId($id)
    {
      $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_branch_id";
      $stmt = $this->conn->prepare( $query );
      $stmt->execute();
      $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);

      foreach($rowvalues as $rowVal)
      {
        if($rowVal['fd_branch_id']==$id)
        {
          return true;
        }
      }
      return false;
    }

    public function getBranchByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE fd_branch_id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setBranchId($row['fd_branch_id']);
        $this->setBranchName($row['fd_branch_name']);
        $this->setCompanyId($row['fd_company_id']);
        $this->setAddress($row['fd_address']);
        $this->setAddress1($row['fd_address1']);
        $this->setAddress2($row['fd_address2']);
        $this->setCity($row['fd_city']);
        $this->setState($row['fd_state']);
        $this->setCountry($row['fd_country']);
        $this->setPincode($row['fd_pincode']);
        $this->setStdcode($row['fd_stdcode']);
        $this->setPhone1($row['fd_phone1']);
        $this->setPhone2($row['fd_phone2']);
        $this->setFax($row['fd_fax']);
        $this->setCPName($row['fd_cpname']);
        $this->setMobile1($row['fd_mobile1']);
        $this->setMobile2($row['fd_mobile2']);
        $this->setEmail1($row['fd_email1']);
        $this->setEmail2($row['fd_email2']);
        $this->setUrl($row['fd_url']);
        $this->setPanNo($row['fd_panno']);
        $this->setSTaxNo($row['fd_staxno']);
        $this->setPFCode($row['fd_pfcode']);
        $this->setESICode($row['fd_esicode']);
    }

	function readAllBranch()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_branch_id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      fd_branch_name = :branchname,
					            fd_company_id  = :companyid,
                      fd_address =:address,
                      fd_address1 =:address1,
                      fd_address2 =:address2,
                      fd_city =:city,
                      fd_state =:state,
                      fd_country =:country,
                      fd_pincode =:pincode,
                      fd_stdcode =:stdcode,
                      fd_phone1 =:phone1,
                      fd_phone2 =:phone2,
                      fd_fax =:fax,
                      fd_cpname =:cpname,
                      fd_mobile1 =:mobile1,
                      fd_mobile2 =:mobile2,
                      fd_email1 =:email1,
                      fd_email2 =:email2,
                      fd_url =:url,
                      fd_panno =:panno,
                      fd_staxno =:staxno,
                      fd_pfcode =:pfcode,
                      fd_esicode =:esicode
                      ";

                      // ,
                      // ,



        $stmt = $this->conn->prepare($query);

        // posted values
        $this->fd_branch_name=htmlspecialchars(strip_tags($this->getBranchName()));
        $this->fd_company_id=htmlspecialchars(strip_tags($this->getCompanyId()));
        $this->fd_address=htmlspecialchars(strip_tags($this->getAddress()));
        $this->fd_address1=htmlspecialchars(strip_tags($this->getAddress1()));
        $this->fd_address2=htmlspecialchars(strip_tags($this->getAddress2()));
        $this->fd_city=htmlspecialchars(strip_tags($this->getCity()));
        $this->fd_state=htmlspecialchars(strip_tags($this->getState()));
        $this->fd_country=htmlspecialchars(strip_tags($this->getCountry()));
        $this->fd_pincode=htmlspecialchars(strip_tags($this->getPincode()));
        $this->fd_stdcode=htmlspecialchars(strip_tags($this->getStdcode()));
        $this->fd_phone1=htmlspecialchars(strip_tags($this->getPhone1()));
        $this->fd_phone2=htmlspecialchars(strip_tags($this->getPhone2()));
        $this->fd_fax=htmlspecialchars(strip_tags($this->getFax()));
        $this->fd_cpname=htmlspecialchars(strip_tags($this->getCPName()));
        $this->fd_mobile1=htmlspecialchars(strip_tags($this->getMobile1()));
        $this->fd_mobile2=htmlspecialchars(strip_tags($this->getMobile2()));
        $this->fd_email1=htmlspecialchars(strip_tags($this->getEmail1()));
        $this->fd_email2=htmlspecialchars(strip_tags($this->getEmail2()));
        $this->fd_url=htmlspecialchars(strip_tags($this->getUrl()));
        $this->fd_panno=htmlspecialchars(strip_tags($this->getPanNO()));
        $this->fd_staxno=htmlspecialchars(strip_tags($this->getSTaxNO()));
        $this->fd_pfcode=htmlspecialchars(strip_tags($this->getPFCode()));
        $this->fd_esicode=htmlspecialchars(strip_tags($this->getESICode()));

        // bind parameters
        $stmt->bindParam(':branchname', $this->fd_branch_name);
        $stmt->bindParam(':companyid', $this->fd_company_id);
        $stmt->bindParam(':address', $this->fd_address);
        $stmt->bindParam(':address1', $this->fd_address1);
        $stmt->bindParam(':address2', $this->fd_address2);
        $stmt->bindParam(':city', $this->fd_city);
        $stmt->bindParam(':state', $this->fd_state);
        $stmt->bindParam(':country', $this->fd_country);
        $stmt->bindParam(':pincode', $this->fd_pincode);
        $stmt->bindParam(':stdcode', $this->fd_stdcode);
        $stmt->bindParam(':phone1', $this->fd_phone1);
        $stmt->bindParam(':phone2', $this->fd_phone2);
        $stmt->bindParam(':fax', $this->fd_fax);
        $stmt->bindParam(':cpname', $this->fd_cpname);
        $stmt->bindParam(':mobile1', $this->fd_mobile1);
        $stmt->bindParam(':mobile2', $this->fd_mobile2);
        $stmt->bindParam(':email1', $this->fd_email1);
        $stmt->bindParam(':email2', $this->fd_email2);
        $stmt->bindParam(':url', $this->fd_url);
        $stmt->bindParam(':panno', $this->fd_panno);
        $stmt->bindParam(':staxno', $this->fd_staxno);
        $stmt->bindParam(':pfcode', $this->fd_pfcode);
        $stmt->bindParam(':esicode', $this->fd_esicode);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      fd_branch_name = :branchname,
                      fd_company_id  = :companyid,
                      fd_address =:address,
                      fd_address1 =:address1,
                      fd_address2 =:address2,
                      fd_city =:city,
                      fd_state =:state,
                      fd_country =:country,
                      fd_pincode =:pincode,
                      fd_stdcode =:stdcode,
                      fd_phone1 =:phone1,
                      fd_phone2 =:phone2,
                      fd_fax =:fax,
                      fd_cpname =:cpname,
                      fd_mobile1 =:mobile1,
                      fd_mobile2 =:mobile2,
                      fd_email1 =:email1,
                      fd_email2 =:email2,
                      fd_url =:url,
                      fd_panno =:panno,
                      fd_staxno =:staxno,
                      fd_pfcode =:pfcode,
                      fd_esicode =:esicode,
                      updated_at =:updateTimeStamp
                WHERE
                      fd_branch_id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->fd_branch_name=htmlspecialchars(strip_tags($this->getBranchName()));
          $this->fd_company_id=htmlspecialchars(strip_tags($this->getCompanyId()));
          $this->fd_address=htmlspecialchars(strip_tags($this->getAddress()));
          $this->fd_address1=htmlspecialchars(strip_tags($this->getAddress1()));
          $this->fd_address2=htmlspecialchars(strip_tags($this->getAddress2()));
          $this->fd_city=htmlspecialchars(strip_tags($this->getCity()));
          $this->fd_state=htmlspecialchars(strip_tags($this->getState()));
          $this->fd_country=htmlspecialchars(strip_tags($this->getCountry()));
          $this->fd_pincode=htmlspecialchars(strip_tags($this->getPincode()));
          $this->fd_stdcode=htmlspecialchars(strip_tags($this->getStdcode()));
          $this->fd_phone1=htmlspecialchars(strip_tags($this->getPhone1()));
          $this->fd_phone2=htmlspecialchars(strip_tags($this->getPhone2()));
          $this->fd_fax=htmlspecialchars(strip_tags($this->getFax()));
          $this->fd_cpname=htmlspecialchars(strip_tags($this->getCPName()));
          $this->fd_mobile1=htmlspecialchars(strip_tags($this->getMobile1()));
          $this->fd_mobile2=htmlspecialchars(strip_tags($this->getMobile2()));
          $this->fd_email1=htmlspecialchars(strip_tags($this->getEmail1()));
          $this->fd_email2=htmlspecialchars(strip_tags($this->getEmail2()));
          $this->fd_url=htmlspecialchars(strip_tags($this->getUrl()));
          $this->fd_panno=htmlspecialchars(strip_tags($this->getPanNO()));
          $this->fd_staxno=htmlspecialchars(strip_tags($this->getSTaxNO()));
          $this->fd_pfcode=htmlspecialchars(strip_tags($this->getPFCode()));
          $this->fd_esicode=htmlspecialchars(strip_tags($this->getESICode()));

          // bind parameters
          $stmt->bindParam(':branchname', $this->fd_branch_name);
          $stmt->bindParam(':companyid', $this->fd_company_id);
          $stmt->bindParam(':address', $this->fd_address);
          $stmt->bindParam(':address1', $this->fd_address1);
          $stmt->bindParam(':address2', $this->fd_address2);
          $stmt->bindParam(':city', $this->fd_city);
          $stmt->bindParam(':state', $this->fd_state);
          $stmt->bindParam(':country', $this->fd_country);
          $stmt->bindParam(':pincode', $this->fd_pincode);
          $stmt->bindParam(':stdcode', $this->fd_stdcode);
          $stmt->bindParam(':phone1', $this->fd_phone1);
          $stmt->bindParam(':phone2', $this->fd_phon2);
          $stmt->bindParam(':fax', $this->fd_fax);
          $stmt->bindParam(':cpname', $this->fd_cpname);
          $stmt->bindParam(':mobile1', $this->fd_mobile1);
          $stmt->bindParam(':mobile2', $this->fd_mobile2);
          $stmt->bindParam(':email1', $this->fd_email1);
          $stmt->bindParam(':email2', $this->fd_email2);
          $stmt->bindParam(':url', $this->fd_url);
          $stmt->bindParam(':panno', $this->fd_panno);
          $stmt->bindParam(':staxno', $this->fd_staxno);
          $stmt->bindParam(':pfcode', $this->fd_pfcode);
          $stmt->bindParam(':esicode', $this->fd_esicode);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->fd_branch_id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Company
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE fd_branch_id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->fd_branch_id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
