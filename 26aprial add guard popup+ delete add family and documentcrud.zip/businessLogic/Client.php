<?php
require_once("Database.php");

class Client
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_client";

    // property declaration
    private $client_id;
    private $client_code;
    private $name;
    private $comp_code;
    private $branch_code;
    private $catgcode;
    private $person;
    private $mobile;
    private $areacode;
    private $address1;
    private $address2;
    private $address3;
    private $city;
    private $statecode;
    private $countrycode;
    private $pin;
    private $email1;
    private $email2;
    private $phone1;
    private $phone2;
    private $fax;
    private $status;
    private $created;
    private $updated;

    // method declaration
    public function getClientId()
    {
        return $this->client_id;
    }
    public function setClientId($clientid)
    {
        $this->client_id = $clientid;
    }
    public function getClientCode()
    {
        return $this->client_code;
    }
    public function setClientCode($clientcode)
    {
      $this->client_code  = $clientcode;
    }
    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
        $this->name = $name;
    }
    public function getCompCode()
    {
        return $this->comp_code;
    }
    public function setCompCode($companycode)
    {
        $this->comp_code = $companycode;
    }
    public function getBranchCode()
    {
        return $this->branch_code;
    }
    public function setBranchCode($branchcode)
    {
        $this->branch_code = $branchcode;
    }
    public function getCatgCode()
    {
        return $this->catgcode;
    }
    public function setCatgCode($catgcode)
    {
        $this->catgcode = $catgcode;
    }
    public function getPerson()
    {
        return $this->person;
    }
    public function setPerson($person)
    {
        $this->person = $person;
    }
    public function getMobile()
    {
        return $this->mobile;
    }
    public function setMobile($mobile)
    {
        $this->mobile = $mobile;
    }
    public function getAreaCode()
    {
        return $this->areacode;
    }
    public function setAreaCode($areacode)
    {
        $this->areacode = $areacode;
    }
    public function getAddress1()
    {
        return $this->address1;
    }
    public function setAddress1($address1)
    {
        $this->address1 = $address1;
    }
    public function getAddress2()
    {
        return $this->address2;
    }
    public function setAddress2($address2)
    {
        $this->address2 = $address2;
    }
    public function getAddress3()
    {
        return $this->address3;
    }
    public function setAddress3($address3)
    {
        $this->address3 = $address3;
    }
    public function getCity()
    {
        return $this->city;
    }
    public function setCity($city)
    {
        $this->city = $city;
    }
    public function getStateCode()
    {
        return $this->statecode;
    }
    public function setStateCode($statecode)
    {
        $this->statecode = $statecode;
    }
    public function getCountryCode()
    {
        return $this->countrycode;
    }
    public function setCountryCode($countrycode)
    {
        $this->countrycode = $countrycode;
    }
    public function getPin()
    {
        return $this->pin;
    }
    public function setPin($pin)
    {
        $this->pin = $pin;
    }
    public function getEmail1()
    {
        return $this->email1;
    }
    public function setEmail1($email1)
    {
        $this->email1 = $email1;
    }
    public function getEmail2()
    {
        return $this->email2;
    }
    public function setEmail2($email2)
    {
        $this->email2 = $email2;
    }
    public function getPhone1()
    {
        return $this->phone1;
    }
    public function setPhone1($phone)
    {
        $this->phone1 = $phone;
    }
    public function getPhone2()
    {
        return $this->phone2;
    }
    public function setPhone2($phone)
    {
        $this->phone2 = $phone;
    }
    public function getFax()
    {
        return $this->fax;
    }
    public function setFax($fax)
    {
        $this->fax = $fax;
    }
    public function getStatus()
    {
        return $this->status;
    }
    public function setStatus($status)
    {
        $this->status = $status;
    }
    public function getCreated()
    {
        return $this->created;
    }
    public function setCreated($created)
    {
        $this->created = $created;
    }
    public function getUpdated()
    {
        return $this->updated;
    }
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }


	  public function __construct($db){
        $this->conn = $db;
    }

    //
    // public function getCustomerGroup($id)
    // {
    //
    //   if($this->validatId($id))
    //   {
    //     $query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
    //     $stmt = $this->conn->prepare( $query );
    //     $stmt->bindParam(1, $id);
    //     $stmt->execute();
    //     $row = $stmt->fetch(PDO::FETCH_ASSOC);
    //     return $row['name'];
    //   }
    //   else {
    //     return "";
    //   }
    // }
    // public function validateId($id)
    // {
    //   $query = "SELECT * FROM " . $this->table_name . " ORDER BY id";
    //   $stmt = $this->conn->prepare( $query );
    //   $stmt->execute();
    //   $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //
    //   foreach($rowvalues as $rowVal)
    //   {
    //     if($rowVal['id']==$id)
    //     {
    //       return true;
    //     }
    //   }
    //   return false;
    //
    // }

    public function getClientByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE client_id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setClientId($row['client_id']);
        $this->setClientCode($row['client_code']);
        $this->setName($row['name']);
        $this->setCompCode($row['comp_code']);
        $this->setBranchCode($row['branch_code']);
        $this->setCatgCode($row['catgcode']);
        $this->setPerson($row['person']);
        $this->setMobile($row['mobile']);
        $this->setAreaCode($row['areacode']);
        $this->setAddress1($row['address1']);
        $this->setAddress2($row['address2']);
        $this->setAddress3($row['address3']);
        $this->setCity($row['city']);
        $this->setStateCode($row['statecode']);
        $this->setCountryCode($row['countrycode']);
        $this->setPin($row['pin']);
        $this->setEmail1($row['email1']);
        $this->setEmail2($row['email2']);
        $this->setPhone1($row['phone1']);
        $this->setPhone2($row['phone2']);
        $this->setFax($row['fax']);
        $this->setStatus($row['status']);
        $this->setCreated($row['created']);
        $this->setUpdated($row['updated']);
    }

	function readAllClient()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY client_id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      client_code=:client_code,
                      name = :name,
					            comp_code  = :comp_code,
                      branch_code =:branch_code,
                      catgcode =:catgcode,
                      person =:person,
                      mobile =:mobile,
                      areacode =:areacode,
                      address1 =:address1,
                      address2 =:address2,
                      address3 =:address3,
                      city =:city,
                      statecode =:statecode,
                      countrycode =:countrycode,
                      pin =:pin,
                      email1 =:email1,
                      email2=:email2,
                      phone1=:phone1,
                      phone2=:phone2,
                      fax=:fax
                    ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->name=htmlspecialchars(strip_tags($this->getName()));
        $this->client_code=htmlspecialchars(strip_tags($this->getClientCode()));
        $this->comp_code=htmlspecialchars(strip_tags($this->getCompCode()));
        $this->branch_code=htmlspecialchars(strip_tags($this->getBranchCode()));
        $this->catgcode=htmlspecialchars(strip_tags($this->getCatgCode()));
        $this->person=htmlspecialchars(strip_tags($this->getPerson()));
        $this->mobile=htmlspecialchars(strip_tags($this->getMobile()));
        $this->areacode=htmlspecialchars(strip_tags($this->getAreaCode()));
        $this->address1=htmlspecialchars(strip_tags($this->getAddress1()));
        $this->address2=htmlspecialchars(strip_tags($this->getAddress2()));
        $this->address3=htmlspecialchars(strip_tags($this->getAddress3()));
        $this->city=htmlspecialchars(strip_tags($this->getCity()));
        $this->statecode=htmlspecialchars(strip_tags($this->getStateCode()));
        $this->countrycode=htmlspecialchars(strip_tags($this->getCountryCode()));
        $this->pin=htmlspecialchars(strip_tags($this->getPin()));
        $this->email1=htmlspecialchars(strip_tags($this->getEmail1()));
        $this->email2=htmlspecialchars(strip_tags($this->getEmail2()));
        $this->phone1=htmlspecialchars(strip_tags($this->getPhone1()));
        $this->phone2=htmlspecialchars(strip_tags($this->getPhone2()));
        $this->fax=htmlspecialchars(strip_tags($this->getFax()));

        // bind parameters
        $stmt->bindParam(':client_code', $this->client_code);
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':comp_code', $this->comp_code);
        $stmt->bindParam(':branch_code', $this->branch_code);
        $stmt->bindParam(':catgcode', $this->catgcode);
        $stmt->bindParam(':person', $this->person);
        $stmt->bindParam(':mobile', $this->mobile);
        $stmt->bindParam(':areacode', $this->areacode);
        $stmt->bindParam(':address1', $this->address1);
        $stmt->bindParam(':address2', $this->address2);
        $stmt->bindParam(':address3', $this->address3);
        $stmt->bindParam(':city', $this->city);
        $stmt->bindParam(':statecode', $this->statecode);
        $stmt->bindParam(':countrycode', $this->countrycode);
        $stmt->bindParam(':pin', $this->pin);
        $stmt->bindParam(':email1', $this->email1);
        $stmt->bindParam(':email2', $this->email2);
        $stmt->bindParam(':phone1', $this->phone1);
        $stmt->bindParam(':phone2', $this->phone2);
        $stmt->bindParam(':fax', $this->fax);


        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      name =:name,
                      comp_code  =:comp_code,
                      branch_code =:branch_code,
                      catgcode =:catgcode,
                      person =:person,
                      mobile =:mobile,
                      areacode =:areacode,
                      address1 =:address1,
                      address2 =:address2,
                      address3 =:address3,
                      city =:city,
                      statecode =:statecode,
                      countrycode =:countrycode,
                      pin =:pin,
                      email1 =:email1,
                      email2=:email2,
                      phone1=:phone1,
                      phone2=:phone2,
                      fax=:fax,
                      updated =:updateTimeStamp
                WHERE
                      client_id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->name=htmlspecialchars(strip_tags($this->getName()));
          $this->comp_code=htmlspecialchars(strip_tags($this->getCompCode()));
          $this->branch_code=htmlspecialchars(strip_tags($this->getBranchCode()));
          $this->catgcode=htmlspecialchars(strip_tags($this->getCatgCode()));
          $this->person=htmlspecialchars(strip_tags($this->getPerson()));
          $this->mobile=htmlspecialchars(strip_tags($this->getMobile()));
          $this->areacode=htmlspecialchars(strip_tags($this->getAreaCode()));
          $this->address1=htmlspecialchars(strip_tags($this->getAddress1()));
          $this->address2=htmlspecialchars(strip_tags($this->getAddress2()));
          $this->address3=htmlspecialchars(strip_tags($this->getAddress3()));
          $this->city=htmlspecialchars(strip_tags($this->getCity()));
          $this->statecode=htmlspecialchars(strip_tags($this->getStateCode()));
          $this->countrycode=htmlspecialchars(strip_tags($this->getCountryCode()));
          $this->pin=htmlspecialchars(strip_tags($this->getPin()));
          $this->email1=htmlspecialchars(strip_tags($this->getEmail1()));
          $this->email2=htmlspecialchars(strip_tags($this->getEmail2()));
          $this->phone1=htmlspecialchars(strip_tags($this->getPhone1()));
          $this->phone2=htmlspecialchars(strip_tags($this->getPhone2()));
          $this->fax=htmlspecialchars(strip_tags($this->getFax()));

          $this->client_id = htmlspecialchars(strip_tags($this->getClientId()));

          // bind parameters
          $stmt->bindParam(':name', $this->name);
          $stmt->bindParam(':comp_code', $this->comp_code);
          $stmt->bindParam(':branch_code', $this->branch_code);
          $stmt->bindParam(':catgcode', $this->catgcode);
          $stmt->bindParam(':person', $this->person);
          $stmt->bindParam(':mobile', $this->mobile);
          $stmt->bindParam(':areacode', $this->areacode);
          $stmt->bindParam(':address1', $this->address1);
          $stmt->bindParam(':address2', $this->address2);
          $stmt->bindParam(':address3', $this->address3);
          $stmt->bindParam(':city', $this->city);
          $stmt->bindParam(':statecode', $this->statecode);
          $stmt->bindParam(':countrycode', $this->countrycode);
          $stmt->bindParam(':pin', $this->pin);
          $stmt->bindParam(':email1', $this->email1);
          $stmt->bindParam(':email2', $this->email2);
          $stmt->bindParam(':phone1', $this->phone1);
          $stmt->bindParam(':phone2', $this->phone2);
          $stmt->bindParam(':fax', $this->fax);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated);
          $stmt->bindParam(':id', $this->client_id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Client
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE client_id = ?";

  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->client_id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}

}
?>
