<?php
require_once("Settings.php");
require_once("Database.php");


class Project
{
	private $projectFName="Perfect Protection";
	private $projectLName="";
	private $projectUrl="http://localhost/pperp/";
	private $maintainenceFlag="false";



	public function getProjectFName(){

		$database = new Database();
		$db = $database->getConnection();
		$settings = new Settings($db);
		$settings->getGeneralSettings("system_name");
		if($settings->getValue()=="")
		{
				return $this->projectFName;
		}
		else {
        return $settings->getValue();
		}

	}

	public function getProjectLName(){
		return $this->projectLName;
	}

	public function getProjectUrl()
	{
		$database = new Database();
		$db = $database->getConnection();
		$settings = new Settings($db);
		$settings->getGeneralSettings("system_url");
		if($settings->getValue()=="")
		{
				return $this->projectUrl;
		}
		else {
				return $settings->getValue();
		}
	}
	public function getMaintainenceFlag()
	{
		$database = new Database();
		$db = $database->getConnection();
		$settings = new Settings($db);
		$settings->getGeneralSettings("maintainence_flag");
		if($settings->getValue()=="")
		{
				return $this->maintainenceFlag;
		}
		else {
				return $settings->getValue();
		}

	}
}
?>
