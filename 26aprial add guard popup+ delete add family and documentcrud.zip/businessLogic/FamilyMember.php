<?php
require_once("Database.php");

class FamilyMember
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_familymember";

    // property declaration
    private $id;
    private $name;
    private $age;
    private $relation;
    private $remark;

    private $status;
    private $create_date;
    private $updated_at;

    // method declaration
    public function getFamilyMemberId()
    {
        return $this->id;
    }
    public function setFamilyMemberId($id)
    {
        $this->id = $id;
    }
    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
        $this->name = $name;
    }
    public function getAge()
    {
        return $this->age;
    }
    public function setAge($age)
    {
        $this->age = $age;
    }
    public function getRelation()
    {
        return $this->relation;
    }
    public function setRelation($relation)
    {
        $this->relation = $relation;
    }
    public function getRemark()
    {
        return $this->remark;
    }
    public function setRemark($remark)
    {
        $this->remark = $remark;
    }

    public function getStatus()
    {
            return $this->status;
    }
    public function setStatus($status)
    {
            $this->status = $status;
    }

    public function getCreatedAt()
    {
        return $this->create_date;
    }
    public function setCreatedAt($create_date)
    {
        $this->create_date = $create_date;
    }
    public function getUpdatedAt()
   {
    return $this->updated_at;
   }
   public function setUpdateAt($updatedat)
   {
    $this->updated_at = $updatedat;
    }


	  public function __construct($db){
        $this->conn = $db;
    }

    public function getFamilyMemberByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setFamilyMemberId($row['id']);
        $this->setName($row['name']);
        $this->setAge($row['age']);
        $this->setRelation($row['relation']);
        $this->setRemark($row['remark']);

        $this->setStatus($row['status']);
        $this->setCreatedAt($row['create_date']);
      $this->setUpdateAt($row['updated_at']);

    }

	function readAllFamilyMember()
	{
		  //$query = "SELECT * FROM " . $this->table_name . " where remark='y' ORDER BY id DESC";
      $query = "SELECT * FROM " . $this->table_name . " ORDER BY id";
      $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}


	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET name = :name,age = :age ,relation =  :relation, remark = :remark
                ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->name=htmlspecialchars(strip_tags($this->getName()));
        $this->age=htmlspecialchars(strip_tags($this->getAge()));
        $this->relation=htmlspecialchars(strip_tags($this->getRelation()));
        $this->remark=htmlspecialchars(strip_tags($this->getRemark()));




      //  $this->summary=htmlspecialchars(strip_tags($this->getSummary()));

        // bind parameters
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':age', $this->age);
        $stmt->bindParam(':relation', $this->relation);
        $stmt->bindParam(':remark', $this->remark);

      //  $stmt->bindParam(':summary', $this->summary);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                  name = :name,age = :age,relation = :relation,remark = :remark,updated_at = :updated_at
                 WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values

          $this->name=htmlspecialchars(strip_tags($this->getName()));
          $this->age=htmlspecialchars(strip_tags($this->getAge()));
          $this->relation=htmlspecialchars(strip_tags($this->getRelation()));
          $this->remark=htmlspecialchars(strip_tags($this->getRemark()));

          // bind parameters
          $stmt->bindParam(':name', $this->name);
          $stmt->bindParam(':age', $this->age);
          $stmt->bindParam(':relation', $this->relation);
          $stmt->bindParam(':remark', $this->remark);
          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updated_at', $this->updated_at);

          $stmt->bindParam(':id', $this->id);
           if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the user
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";

  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}

}
?>
