<?php
require_once("Database.php");

class FamilyDocument
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_familydocument";

    // property declaration
    private $id;
    private $documentname;
    private $docdescription;
    private $docauthorityy;
    private $docissudate;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getDocumentId()
    {
        return $this->ff_id;
    }
    public function setDocumentId($ff_id)
    {
        $this->ff_id = $ff_id;
    }
    public function getDocumentName()
    {
        return $this->documentname;
    }
    public function setDocumentName($documentname)
    {
        $this->documentname = $documentname;
    }
    public function getDocumentDescription()
    {
        return $this->docdescription;
    }
    public function setDocumentDescription($docdescription)
    {
        $this->docdescription = $docdescription;
    }
    public function getAuthority()
    {
        return $this->docauthority;
    }
    public function setAuthority($docauthority)
    {
        $this->docauthority = $docauthority;
    }
    public function getDocumentIssudate()
    {
        return $this->docissudate;
    }
    public function setDocumentIssudate($docissudate)
    {
        $this->docissudate = $docissudate;
    }

        public function getCreatedAt()
        {
            return $this->created_at;
        }
        public function setCreatedAt($created_at)
        {
            $this->created_at = $created_at;
        }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getDocumentVal($id)
    {

      if($this->validateId($id))
      {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['documentname'];
      }
      else {
        return "";
      }
    }
    public function validateId($id)
    {
      $query = "SELECT * FROM " . $this->table_name . " ORDER BY id";
      $stmt = $this->conn->prepare( $query );
      $stmt->execute();
      $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);

      foreach($rowvalues as $rowVal)
      {
        if($rowVal['id']==$id)
        {
          return true;
        }
      }
      return false;

    }

    public function getDocumentByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setDocumentId($row['id']);
        $this->setDocumentName($row['documentname']);
        $this->setDocumentDescription($row['docdescription']);
        $this->setAuthority($row['docauthority']);
        $this->setDocumentIssudate($row['docissudate']);
        $this->setUpdateAt($row['updated_at']);
    }

	function readAllDocument()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY id";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      documentname = :documentname,docdescription =:docdescription,
                      docauthority = :docauthority,docissudate = :docissudate
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->documentname=htmlspecialchars(strip_tags($this->getDocumentName()));
        $this->docdescription=htmlspecialchars(strip_tags($this->getDocumentDescription()));
        $this->docauthority=htmlspecialchars(strip_tags($this->getAuthority()));
        $this->docissudate=htmlspecialchars(strip_tags($this->getDocumentIssudate()));
        // bind parameters
        $stmt->bindParam(':documentname', $this->documentname);
        $stmt->bindParam(':docdescription', $this->docdescription);
        $stmt->bindParam(':docauthority', $this->docauthority);
        $stmt->bindParam(':docissudate', $this->docissudate);
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      documentname = :documentname,docdescription = :docdescription,
                      docauthority = :docauthority,docissudate = :docissudate,
                      updated_at =:updated_at


                WHERE
                      id = :d_id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->documentname=htmlspecialchars(strip_tags($this->getDocumentName()));
          $this->docdescription=htmlspecialchars(strip_tags($this->getDocumentDescription()));
          $this->docauthority=htmlspecialchars(strip_tags($this->getAuthority()));
          $this->docissudate=htmlspecialchars(strip_tags($this->getDocumentIssudate()));

          // bind parameters
          $stmt->bindParam(':documentname', $this->documentname);
          $stmt->bindParam(':docdescription', $this->docdescription);
          $stmt->bindParam(':docauthority', $this->docauthority);
          $stmt->bindParam(':docissudate', $this->docissudate);
          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updated_at', $this->updated_at);
          $stmt->bindParam(':d_id', $this->ff_id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Company
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
