<?php
require_once("Database.php");

class Role
{
	// database connection and table name
    private $conn;
    private $table_name = "roles";

    // property declaration
    private $id;
    private $name;
    private $description;
    private $guard_name;
    private $is_active;
    private $created_at;
    private $updated_at;


    // method declaration
    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
      $this->name  = $name;
    }
    public function getDescription()
    {
        return $this->description;
    }
    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function getGuardName()
    {
        return $this->guard_name;
    }
    public function setGuardName($guardName)
    {
        $this->guard_name = $guardName;
    }

    public function getIsActive()
    {
        return $this->is_active;
    }
    public function setIsActive($isactive)
    {
        $this->is_active = $isactive;
    }


    public function getCreatedAt()
    {
        return $this->created_at;
    }
    public function setCreatedAt($created)
    {
        $this->created_at = $created;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdatedAt($updated)
    {
        $this->updated_at = $updated;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getRoleByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setId($row['id']);
        $this->setName($row['name']);
        $this->setDescription($row['description']);
        $this->setCreatedAt($row['created_at']);
        $this->setUpdatedAt($row['updated_at']);
    }

    public function getRole($id)
   {

     if($this->validateId($id))
     {
       $query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
       $stmt = $this->conn->prepare( $query );
       $stmt->bindParam(1, $id);
       $stmt->execute();
       $row = $stmt->fetch(PDO::FETCH_ASSOC);
       return $row['name'];
     }
     else {
       return "";
     }
   }
   public function validateId($id)
   {
     $query = "SELECT * FROM " . $this->table_name . " ORDER BY id";
     $stmt = $this->conn->prepare( $query );
     $stmt->execute();
     $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);

     foreach($rowvalues as $rowVal)
     {
       if($rowVal['id']==$id)
       {
         return true;
       }
     }
     return false;
   }


	function readAllRoles()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      name = :name,
					            description  = :description
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->name=htmlspecialchars(strip_tags($this->getName()));
        $this->description=htmlspecialchars(strip_tags($this->getDescription()));

        // bind parameters
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':description', $this->description);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      name = :name,
                      description =:description,
                      updated_at =:updated_at
                WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->name=htmlspecialchars(strip_tags($this->getName()));
          $this->description=htmlspecialchars(strip_tags($this->getDescription()));

          // bind parameters
          $stmt->bindParam(':name', $this->name);
          $stmt->bindParam(':description', $this->description);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updated_at', $this->updated_at);
          $stmt->bindParam(':id', $this->id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the role
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";

  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}

}
?>
