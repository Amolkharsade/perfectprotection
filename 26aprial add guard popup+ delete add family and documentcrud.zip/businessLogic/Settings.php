<?php
require_once("Database.php");

class Settings
{
	// database connection and table name
    private $conn;
    private $table_name = "general_settings";

    // property declaration
    private $general_settings_id;
    private $type;
    private $value;


    // method declaration
    public function getGeneralSettingsId()
    {
        return $this->general_settings_id;
    }
    public function setGeneralSettingsId($generalsettingsid)
    {
          $this->general_settings_id = $generalsettingsid;
    }
    public function getType()
    {
        return $this->type;
    }
    public function setType($type)
    {
          $this->type = $type;
    }
    public function getValue()
    {
        return $this->value;
    }
    public function setValue($value)
    {
          $this->value = $value;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

	// function readAllSocialLinks()
	// {
	// 	  $query = "SELECT * FROM " . $this->table_name . " ORDER BY city_id DESC";
	//     $stmt = $this->conn->prepare( $query );
	// 	  $stmt->execute();
  // 		return $stmt;
	// }


public function getGeneralSettings($type)
 {

     $query = "SELECT * FROM " . $this->table_name . " WHERE type = ? LIMIT 0,1";
     $stmt = $this->conn->prepare( $query );
     $stmt->bindParam(1, $type);
     $stmt->execute();
     $row = $stmt->fetch(PDO::FETCH_ASSOC);
     // $this->setGeneralSettingsId($row['general_settings_id']);
     // $this->setType($row['type']);
     // $this->setValue($row['value']);

 }


    function update(){
          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      value=:value
                WHERE
                      type =:type";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->value=htmlspecialchars(strip_tags($this->getValue()));
          $this->type=htmlspecialchars(strip_tags($this->getType()));

          // bind parameters
          $stmt->bindParam(':value', $this->value);
          $stmt->bindParam(':type', $this->type);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }
      }

}
?>
