<?php
require_once("Database.php");

class Quotation
{
	// database connection and table name
    private $conn;
    private $table_name = "quotations";

    // property declaration
    private $id;
    private $reference_no;
    private $user_id;
    private $customer_id;
    private $grand_total;
    private $quotation_status;
    private $note;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function getReferenceNo()
    {
        return $this->reference_no;
    }
    public function setReferenceNo($reference_no)
    {
        $this->reference_no = $reference_no;
    }
    public function getUserId()
    {
        return $this->user_id;
    }
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }
    public function getCustomerId()
    {
        return $this->customer_id;
    }
    public function setCustomerId($customer_id)
    {
        $this->customer_id = $customer_id;
    }
    public function getGrandTotal()
    {
        return $this->grand_total;
    }
    public function setGrandTotal($grand_total)
    {
        $this->grand_total = $grand_total;
    }
    public function getQuotationStatus()
    {
        return $this->quotation_status;
    }
    public function setQuotaionStatus($quotation_status)
    {
        $this->quotation_status = $quotation_status;
    }
    public function getNote()
    {
        return $this->note;
    }
    public function setNote($note)
    {
        $this->note = $note;
    }

    public function getCreatedAt()
    {
        return $this->created_at;
    }
    public function setCreatedAt($created_at)
    {
        $this->created_at = $created_at;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdatedAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }



    public function getQuotationByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setId($row['id']);
        $this->setReferenceNo($row['reference_no']);
        $this->setUserId($row['user_id']);
        $this->setCustomerId($row['customer_id']);
        $this->setGrandTotal($row['grand_total']);
        $this->setQuotaionStatus($row['quotation_status']);
        $this->setNote($row['note']);

    }

	function readAllQuotation()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY id DESC";
      // echo $query;
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      reference_no = :reference_no,
                      user_id =:user_id,
                      customer_id =:customer_id,
                      grand_total =:grand_total,
                      quotation_status =:quotation_status,
                      note =:note
                ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->reference_no=htmlspecialchars(strip_tags($this->getReferenceNo()));
        $this->user_id=htmlspecialchars(strip_tags($this->getUserId()));
        $this->customer_id=htmlspecialchars(strip_tags($this->getCustomerId()));
        $this->grand_total=htmlspecialchars(strip_tags($this->getGrandTotal()));
        $this->quotation_status=htmlspecialchars(strip_tags($this->getQuotationStatus()));
        $this->note=htmlspecialchars(strip_tags($this->getNote()));

        // bind parameters
        $stmt->bindParam(':reference_no', $this->reference_no);
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':customer_id', $this->customer_id);
        $stmt->bindParam(':grand_total', $this->grand_total);
        $stmt->bindParam(':quotation_status', $this->quotation_status);
        $stmt->bindParam(':note', $this->note);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      user_id =:user_id,
                      customer_id =:customer_id,
                      grand_total =:grand_total,
                      quotation_status =:quotation_status,
                      note =:note,
                      updated_at =:updateTimeStamp
                WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->user_id=htmlspecialchars(strip_tags($this->getUserId()));
          $this->customer_id=htmlspecialchars(strip_tags($this->getCustomerId()));
          $this->grand_total=htmlspecialchars(strip_tags($this->getGrandTotal()));
          $this->quotation_status=htmlspecialchars(strip_tags($this->getQuotationStatus()));
          $this->note=htmlspecialchars(strip_tags($this->getNote()));

          // bind parameters
          $stmt->bindParam(':user_id', $this->user_id);
          $stmt->bindParam(':customer_id', $this->customer_id);
          $stmt->bindParam(':grand_total', $this->grand_total);
          $stmt->bindParam(':quotation_status', $this->quotation_status);
          $stmt->bindParam(':note', $this->note);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Product
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
