<?php
require_once("Database.php");

class User
{
	// database connection and table name
    private $conn;
    private $table_name = "users";

    // property declaration
    private $id;
    private $name;
    private $email;
    private $password;
    private $phone;
    private $company_name;
    private $role_id;
    private $is_active;
    private $created_at;
    private $updated_at;


    // method declaration
    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
      $this->name  = $name;
    }
    public function getEmail()
    {
        return $this->email;
    }
    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getPassword()
    {
        return $this->password;
    }
    public function setPassword($password)
    {
        $this->password = $password;
    }
    public function getPhone()
    {
        return $this->phone;
    }
    public function setPhone($phone)
    {
        $this->phone = $phone;
    }
    public function getCompanyName()
    {
        return $this->company_name;
    }
    public function setCompanyName($companyname)
    {
        $this->company_name = $companyname;
    }
    public function getRoleId()
    {
        return $this->role_id;
    }
    public function setRoleId($role_id)
    {
        $this->role_id = $role_id;
    }
    public function getIsActive()
    {
        return $this->is_active;
    }
    public function setIsActive($isactive)
    {
        $this->is_active = $isactive;
    }


    public function getCreatedAt()
    {
        return $this->created_at;
    }
    public function setCreatedAt($created)
    {
        $this->created_at = $created;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdatedAt($updated)
    {
        $this->updated_at = $updated;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getUserByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setId($row['id']);
        $this->setName($row['name']);
        $this->setEmail($row['email']);
        $this->setPassword($row['password']);
        $this->setPhone($row['phone']);
        $this->setCompanyName($row['company_name']);
        $this->setRoleId($row['role_id']);
        $this->setIsActive($row['is_active']);
        $this->setCreatedAt($row['created_at']);
        $this->setUpdatedAt($row['updated_at']);
    }

    public function getUserByEmail($email)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE email = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $email);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setId($row['id']);
        $this->setName($row['name']);
        $this->setEmail($row['email']);
        $this->setPassword($row['password']);
        $this->setPhone($row['phone']);
        $this->setCompanyName($row['company_name']);
        $this->setRoleId($row['role_id']);
        $this->setIsActive($row['is_active']);
        $this->setCreatedAt($row['created_at']);
        $this->setUpdatedAt($row['updated_at']);
    }

	function readAllUser()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY id DESC";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

  public function checkValidEmailAddress($emailaddress)
  {
      $query = "SELECT count(*) as count FROM " . $this->table_name . " WHERE email = ?";
      $stmt = $this->conn->prepare( $query );
      $stmt->bindParam(1, $emailaddress);
      $stmt->execute();
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      $found;
      try {
          $found=  $row['count'];
      } catch (\Exception $e) {
          $found=0;
      }
      return $found;
  }

  public function emaillogin($emailaddress,$password)
  {
      $query = "SELECT count(*) as count FROM " . $this->table_name . " WHERE email = ? and password = ? LIMIT 0,1";
      $stmt = $this->conn->prepare( $query );
      $stmt->bindParam(1, $emailaddress);
      $stmt->bindParam(2, $password);
      $stmt->execute();

      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      $found=0;
      try {
          $found=  $row['count'];
      } catch (\Exception $e) {
          $found=0;
      }
      return $found;
  }



	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      name = :name,
					            email  = :email,
                      password =:password,
                      phone =:phone,
                      role_id =:role,
                      is_active =:active
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->name=htmlspecialchars(strip_tags($this->getName()));
        $this->email=htmlspecialchars(strip_tags($this->getEmail()));
        $this->password=htmlspecialchars(strip_tags($this->getPassword()));
        $this->phone=htmlspecialchars(strip_tags($this->getPhone()));
        $this->role_id=htmlspecialchars(strip_tags($this->getRoleId()));
        $this->is_active=htmlspecialchars(strip_tags($this->getIsActive()));

        // bind parameters
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':password', $this->password);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':role', $this->role_id);
        $stmt->bindParam(':active', $this->is_active);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      name = :name,
                      password =:password,
                      phone =:phone,
                      company_name =:companyname,
                      role_id =:role,
                      is_active =:active,
                      updated_at =:updated_at
                WHERE
                      id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->name=htmlspecialchars(strip_tags($this->getName()));
          $this->password=htmlspecialchars(strip_tags($this->getPassword()));
          $this->phone=htmlspecialchars(strip_tags($this->getPhone()));
          $this->company_name=htmlspecialchars(strip_tags($this->getCompanyName()));
          $this->role_id=htmlspecialchars(strip_tags($this->getRoleId()));
          $this->is_active=htmlspecialchars(strip_tags($this->getIsActive()));

          // bind parameters
          $stmt->bindParam(':name', $this->name);
          $stmt->bindParam(':password', $this->password);
          $stmt->bindParam(':phone', $this->phone);
          $stmt->bindParam(':companyname', $this->company_name);
          $stmt->bindParam(':role', $this->role_id);
          $stmt->bindParam(':active', $this->is_active);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updated_at', $this->updated_at);
          $stmt->bindParam(':id', $this->id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

      function updateOther(){

            //write query
            $query = "UPDATE
                      " . $this->table_name . "
                  SET
                        name = :name,
                        phone =:phone,
                        updated_at =:updated_at
                  WHERE
                        id = :id";

            $stmt = $this->conn->prepare($query);

            // posted values
            $this->name=htmlspecialchars(strip_tags($this->getName()));
            $this->phone=htmlspecialchars(strip_tags($this->getPhone()));

            // bind parameters
            $stmt->bindParam(':name', $this->name);
            $stmt->bindParam(':phone', $this->phone);

            date_default_timezone_set("Asia/Kolkata");
            $this->updated_at = date('Y-m-d H:i:s');
            $stmt->bindParam(':updated_at', $this->updated_at);
            $stmt->bindParam(':id', $this->id);

            if($stmt->execute()){
                return true;
            }else{
                return false;
            }

        }

        function updatePassword(){

              //write query
              $query = "UPDATE
                        " . $this->table_name . "
                    SET
                          password = :password,
                          updated_at =:updated_at
                    WHERE
                          id = :id";

              $stmt = $this->conn->prepare($query);

              // posted values
              $this->password=htmlspecialchars(strip_tags($this->getPassword()));

              // bind parameters
              $stmt->bindParam(':password', $this->password);

              date_default_timezone_set("Asia/Kolkata");
              $this->updated_at = date('Y-m-d H:i:s');
              $stmt->bindParam(':updated_at', $this->updated_at);
              $stmt->bindParam(':id', $this->id);

              if($stmt->execute()){
                  return true;
              }else{
                  return false;
              }

          }


	// delete the customer
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";

  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}

}
?>
