<?php
require_once("Database.php");

class Designation
{
	// database connection and table name
    private $conn;
    private $table_name = "tbl_designation";

    // property declaration
    private $fd_designation_id;
    private $fd_designation;
    private $fd_hsncode;
    private $created_at;
    private $updated_at;

    // method declaration
    public function getDesignationId()
    {
        return $this->fd_designation_id;
    }
    public function setDesignationId($designationId)
    {
        $this->fd_designation_id = $designationId;
    }
    public function getDesignation()
    {
        return $this->fd_designation;
    }
    public function setDesignation($designation)
    {
        $this->fd_designation = $designation;
    }
    public function getHSNCode()
    {
        return $this->fd_hsncode;
    }
    public function setHSNCode($hsncode)
    {
        $this->fd_hsncode = $hsncode;
    }

    public function getCreatedAt()
    {
        return $this->created_at;
    }
    public function setCreatedAt($created_at)
    {
        $this->created_at = $created_at;
    }
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
    public function setUpdateAt($updatedat)
    {
        $this->updated_at = $updatedat;
    }

	  public function __construct($db){
        $this->conn = $db;
    }

    public function getDesignationVal($id)
    {

      if($this->validateId($id))
      {
        $query = "SELECT * FROM " . $this->table_name . " WHERE fd_designation_id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['fd_designation'];
      }
      else {
        return "";
      }
    }
    public function validateId($id)
    {
      $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_designation_id";
      $stmt = $this->conn->prepare( $query );
      $stmt->execute();
      $rowvalues = $stmt->fetchAll(PDO::FETCH_ASSOC);

      foreach($rowvalues as $rowVal)
      {
        if($rowVal['fd_designation_id']==$id)
        {
          return true;
        }
      }
      return false;

    }

    public function getDesignationByID($id)
    {
  	    $query = "SELECT * FROM " . $this->table_name . " WHERE fd_designation_id = ?";
        $stmt = $this->conn->prepare( $query );
    		$stmt->bindParam(1, $id);
    		$stmt->execute();
    		$row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->setDesignationId($row['fd_designation_id']);
        $this->setDesignation($row['fd_designation']);
        $this->setHSNCode($row['fd_hsncode']);
    }

	function readAllDesignation()
	{
		  $query = "SELECT * FROM " . $this->table_name . " ORDER BY fd_designation";
	    $stmt = $this->conn->prepare( $query );
		  $stmt->execute();
  		return $stmt;
	}

	function create(){

        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                      fd_designation = :designation,
					            fd_hsncode  = :hsncode
                      ";

        $stmt = $this->conn->prepare($query);

        // posted values
        $this->fd_designation=htmlspecialchars(strip_tags($this->getDesignation()));
        $this->fd_hsncode=htmlspecialchars(strip_tags($this->getHSNCode()));

        // bind parameters
        $stmt->bindParam(':designation', $this->fd_designation);
        $stmt->bindParam(':hsncode', $this->fd_hsncode);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    function update(){

          //write query
          $query = "UPDATE
                    " . $this->table_name . "
                SET
                      fd_designation = :designation,
                      fd_hsncode  = :hsncode,
                      updated_at =:updateTimeStamp
                WHERE
                      fd_designation_id = :id";

          $stmt = $this->conn->prepare($query);

          // posted values
          $this->fd_designation=htmlspecialchars(strip_tags($this->getDesignation()));
          $this->fd_hsncode=htmlspecialchars(strip_tags($this->getHSNCode()));

          // bind parameters
          $stmt->bindParam(':designation', $this->fd_designation);
          $stmt->bindParam(':hsncode', $this->fd_hsncode);

          date_default_timezone_set("Asia/Kolkata");
          $this->updated_at = date('Y-m-d H:i:s');
          $stmt->bindParam(':updateTimeStamp', $this->updated_at);
          $stmt->bindParam(':id', $this->fd_designation_id);

          if($stmt->execute()){
              return true;
          }else{
              return false;
          }

      }

	// delete the Company
  	function delete(){

  		$query = "DELETE FROM " . $this->table_name . " WHERE fd_designation_id = ?";
  		$stmt = $this->conn->prepare($query);
  		$stmt->bindParam(1, $this->fd_designation_id);

  		if($result = $stmt->execute()){
  			return true;
  		}else{
  			return false;
  		}
  	}
}
?>
